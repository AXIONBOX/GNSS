#include <Arduino.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/diagnostics_engine.h"
#include "system/pins.h"

// Diagnostics UI - summary + pages, driven by diagnostics_engine.
// Désormais limité à 2 pages (Summary + Data) : les pages HC-05 et SD
// ont été déplacées sous Settings > Config.
static const int kDiagPageCount = 2;

// --- Page 1: Summary (with TEST ALL) ---------------------------------------

static void draw_page_summary(const DiagnosticsStatus& S)
{
  const DiagnosticsTestAllStatus& T = diagnostics_engine_get_test_all_status();

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("diag summary", 2, 1);

  auto drawFlag = [](int x, int y, const char* label, int state, int stateOffset) {
    // state: >0 = OK, 0 = FAIL, <0 = N/A
    canvas.setTextColor(colGray(136));
    canvas.drawString(label, x, y);
    const char* txt = "N/A";
    uint16_t col = colGray(80);
    if (state > 0) {
      txt = "OK";
      col = colGray(200);
    } else if (state == 0) {
      txt = "FAIL";
      col = colGray(80);
    }
    canvas.setTextColor(col);
    canvas.drawString(txt, x + stateOffset, y);
  };

  const int y0      = 14;
  const int x0      = 4;
  const int x1      = 88;
  const int x2      = 172;
  const int stateDx = 42;

  // Column 0: GNSS, IMU, RTC, SD
  int gnssState = S.gnss_ok ? 1 : 0;
  int imuState  = S.imu_ok  ? 1 : 0;

  drawFlag(x0, y0,      "GNSS",  gnssState,          stateDx);
  drawFlag(x0, y0 + 9,  "IMU",   imuState,           stateDx);
  drawFlag(x0, y0 + 18, "RTC",   S.rtc_ok ? 1 : 0,   stateDx);
  int sdState = -1;
  if (S.sd_present) {
    sdState = S.sd_ok ? 1 : 0;
  }
  drawFlag(x0, y0 + 27, "SD",    sdState,            stateDx);

  // Column 1: PCF, OLED, FS, HC-05
  drawFlag(x1, y0,      "PCF",   S.pcf_ok ? 1 : 0,   stateDx);
  drawFlag(x1, y0 + 9,  "OLED",  S.oled_ok ? 1 : 0,  stateDx);
  int fsState = -1;
  if (S.sd_present && S.sd_ok) {
    fsState = S.fs_ok ? 1 : 0;
  }
  drawFlag(x1, y0 + 18, "FS",    fsState,            stateDx);
  int hcState = -1;
  if (S.hc05_baud_detected != 0 || S.hc05_ok) {
    hcState = S.hc05_ok ? 1 : 0;
  }
  drawFlag(x1, y0 + 27, "HC-05", hcState,            stateDx);

  // Column 2: ELM327, BUZZER, LED, BTNS
  int elmState = -1;
  if (S.elm_ok || S.elm_vehicle_present) {
    elmState = S.elm_ok ? 1 : 0;
  }
  int buzzerState = -1;
  int ledState    = -1;
  int btnState    = -1;
  if (T.done) {
    buzzerState = T.buzzer_ok  ? 1 : 0;
    ledState    = T.led_ok     ? 1 : 0;
    btnState    = T.buttons_ok ? 1 : 0;
  }
  drawFlag(x2, y0,      "ELM327", elmState,          stateDx);
  drawFlag(x2, y0 + 9,  "BUZZER", buzzerState,       stateDx);
  drawFlag(x2, y0 + 18, "LED",    ledState,          stateDx);
  drawFlag(x2, y0 + 27, "BTNS",   btnState,          stateDx);

  // Footer: TEST ALL control (mention SELECT)
  canvas.setTextColor(colGray(160));
  const char* footer = nullptr;
  if (!T.running && !T.done) {
    footer = "SELECT: lancer DIAG complet";
  } else if (T.running && !T.done) {
    footer = "DIAG complet en cours...";
  } else {
    footer = "SELECT: relancer DIAG complet";
  }
  canvas.drawString(footer, 2, 63);
}

// --- Page 2: Data -----------------------------------------------------------

static void draw_page_data(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("diag data", 2, 1);

  char buf[64];
  canvas.setTextColor(colGray(180));
  snprintf(buf, sizeof(buf), "lat:%.6f", S.data.lat);
  canvas.drawString(buf, 2, 14);
  snprintf(buf, sizeof(buf), "lon:%.6f", S.data.lon);
  canvas.drawString(buf, 2, 23);

  snprintf(buf, sizeof(buf), "spd:%.1fkm/h hdg:%.1f",
           S.data.speed_kmh, S.data.heading_deg);
  canvas.drawString(buf, 2, 32);

  snprintf(buf, sizeof(buf), "acc[g]: %.2f %.2f %.2f",
           S.data.accel_g[0], S.data.accel_g[1], S.data.accel_g[2]);
  canvas.drawString(buf, 2, 41);

  snprintf(buf, sizeof(buf), "gyro: %.1f %.1f %.1f",
           S.data.gyro_deg[0], S.data.gyro_deg[1], S.data.gyro_deg[2]);
  canvas.drawString(buf, 2, 50);

  snprintf(buf, sizeof(buf), "fix:%d sats:%d hdop:%.2f rpm:%d",
           S.data.fix_quality,
           S.data.sats,
           S.data.hdop,
           (int)S.data.rpm);
  canvas.drawString(buf, 2, 59);
}

// --- Page 3: HC-05 config (AXION) -------------------------------------------

static void draw_page_hc05_view(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  char buf[64];
  canvas.setTextColor(colGray(180));

  const char* status = "SCAN";
  if (S.hc05_ok && S.hc05_baud_detected != 0) status = "OK";
  else if (!S.hc05_ok && S.hc05_baud_detected != 0) status = "FAIL";

  snprintf(buf, sizeof(buf), "detected: %lu baud (%s)",
           (unsigned long)S.hc05_baud_detected, status);
  canvas.drawString(buf, 2, 14);

  canvas.setTextColor(colGray(160));
  snprintf(buf, sizeof(buf), "name: %s", S.hc05_name[0] ? S.hc05_name : "(n/a)");
  canvas.drawString(buf, 2, 23);
  snprintf(buf, sizeof(buf), "addr: %s", S.hc05_addr[0] ? S.hc05_addr : "(n/a)");
  canvas.drawString(buf, 2, 32);
  snprintf(buf, sizeof(buf), "ver:  %s", S.hc05_version[0] ? S.hc05_version : "(n/a)");
  canvas.drawString(buf, 2, 41);

  canvas.setTextColor(colGray(120));
  canvas.drawString("SELECT: setup HC-05 for AXION", 2, 63-8);
}

static void draw_page_hc05_confirm(bool yesSelected)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  canvas.setTextColor(colGray(220));
  canvas.drawString("Configure HC-05 for AXION?", 2, 20);

  canvas.setTextColor(colGray(180));
  canvas.drawString("Baud: 115200, NAME: AXION_HC-05", 2, 30);

  canvas.setTextColor(colGray(200));
  const int y = 44;
  if (yesSelected) {
    canvas.drawString("[YES]  no", 2, y);
  } else {
    canvas.drawString(" yes  [NO]", 2, y);
  }

  canvas.setTextColor(colGray(120));
  canvas.drawString("LEFT/RIGHT: select   SELECT: confirm", 2, 56);
}

static void draw_page_hc05_running(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  canvas.setTextColor(colGray(220));
  canvas.drawString("Configuring HC-05 for AXION...", 2, 18);

  canvas.setTextColor(colGray(160));
  char buf[64];
  snprintf(buf, sizeof(buf), "baud: %lu", (unsigned long)S.hc05_baud_detected);
  canvas.drawString(buf, 2, 30);
  snprintf(buf, sizeof(buf), "name: %s", S.hc05_name[0] ? S.hc05_name : "(pending)");
  canvas.drawString(buf, 2, 39);
  snprintf(buf, sizeof(buf), "status: %s", S.hc05_ok ? "OK" : "working...");
  canvas.drawString(buf, 2, 48);
}

static void draw_page_hc05_done(const DiagnosticsStatus& S, bool success)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  canvas.setTextColor(success ? colGray(220) : colGray(140));
  canvas.setTextDatum(top_right);
  canvas.drawString(success ? "Setup SUCCESS" : "Setup FAILED", 255, 1);
  canvas.setTextDatum(top_left);

  canvas.setTextColor(colGray(160));
  char buf[64];
  snprintf(buf, sizeof(buf), "baud: %lu", (unsigned long)S.hc05_baud_detected);
  canvas.drawString(buf, 2, 14);
  snprintf(buf, sizeof(buf), "name: %s", S.hc05_name[0] ? S.hc05_name : "(n/a)");
  canvas.drawString(buf, 2, 23);
  snprintf(buf, sizeof(buf), "addr: %s", S.hc05_addr[0] ? S.hc05_addr : "(n/a)");
  canvas.drawString(buf, 2, 32);

  canvas.setTextColor(colGray(120));
  canvas.drawString("SELECT: back", 2, 56);
}

// --- Page 4: SD card config -------------------------------------------------

static void draw_page_sd_setup_view(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("SD card config", 2, 1);

  canvas.setTextColor(colGray(180));
  int y = 14;

  if (!S.sd_present) {
    canvas.drawString("Aucune carte SD detectee.", 2, y);
    y += 9;
    canvas.setTextColor(colGray(160));
    canvas.drawString("Inserer une carte SD pour", 2, y);
    y += 9;
    canvas.drawString("utiliser l'enregistrement AXION.", 2, y);
  } else if (S.sd_present && !S.sd_ok) {
    canvas.drawString("Carte SD presente, mais erreur.", 2, y);
    y += 9;
    canvas.setTextColor(colGray(160));
    canvas.drawString("Verifier la carte / format FAT.", 2, y);
  } else {
    // SD OK: afficher quelques stats et etat FS AXION.
    char buf[64];

    uint64_t totalMb = S.sd_total_bytes / (1024u * 1024u);
    uint64_t usedMb  = S.sd_used_bytes  / (1024u * 1024u);
    if (totalMb == 0 && S.sd_total_bytes > 0) totalMb = 1; // arrondi mini

    snprintf(buf, sizeof(buf), "carte: %llu MB  util:%llu MB",
             (unsigned long long)totalMb,
             (unsigned long long)usedMb);
    canvas.drawString(buf, 2, y);
    y += 9;

    canvas.setTextColor(colGray(160));
    const char* fsStatus = S.fs_ok ? "READY" : "NON PRET";
    snprintf(buf, sizeof(buf), "FS AXION (/AXION): %s", fsStatus);
    canvas.drawString(buf, 2, y);
    y += 9;

    if (!S.fs_ok) {
      canvas.drawString("SELECT: preparer /AXION (efface", 2, y);
      y += 9;
      canvas.drawString("uniquement le dossier /AXION)", 2, y);
    } else {
      canvas.drawString("SELECT: re-preparer FS AXION", 2, y);
    }
  }
}

static void draw_page_sd_setup_confirm(bool yesSelected)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("SD card config", 2, 1);

  canvas.setTextColor(colGray(220));
  canvas.drawString("Clear all data and", 2, 20);
  canvas.drawString("Prepare SD card for AXION?", 2, 29);

  canvas.setTextColor(colGray(200));
  const int y = 40;
  if (yesSelected) {
    canvas.drawString("[YES]  no", 2, y);
  } else {
    canvas.drawString(" yes  [NO]", 2, y);
  }

  canvas.setTextColor(colGray(120));
  canvas.drawString("LEFT/RIGHT: select   SELECT: confirm", 2, 63-8);
}

static void draw_page_sd_setup_done(const DiagnosticsStatus& S, bool success)
{
  (void)S;
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("SD card config", 2, 1);

  canvas.setTextColor(success ? colGray(220) : colGray(140));
  canvas.setTextDatum(top_right);
  canvas.drawString(success ? "Setup SUCCESS" : "Setup FAILED", 255, 1);
  canvas.setTextDatum(top_left);

  canvas.setTextColor(colGray(160));
  if (success) {
    canvas.drawString("/AXION pret pour AXION.", 2, 20);
  } else {
    canvas.drawString("Erreur pendant la preparation.", 2, 20);
    canvas.drawString("Verifier la carte SD.", 2, 29);
  }

  canvas.setTextColor(colGray(120));
  canvas.drawString("SELECT: back", 2, 56);
}

// --- Main draw --------------------------------------------------------------

void draw_diagnostics(uint32_t frame)
{
  static bool     s_inited       = false;
  static uint8_t  s_page         = 0;
  static uint8_t  s_prevBtns     = 0xFF;

  // HC-05 UI sub-state: 0=view, 1=confirm, 2=running, 3=done
  static uint8_t  s_hcUiState    = 0;
  static bool     s_hcConfirmYes = true;
  static uint32_t s_hcStartMs    = 0;
  static bool     s_hcSuccess    = false;

  // SD setup UI sub-state: 0=view, 1=confirm, 2=done
  static uint8_t  s_sdUiState    = 0;
  static bool     s_sdConfirmYes = true;
  static bool     s_sdSuccess    = false;

  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    diagnostics_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  diagnostics_engine_update(D, frame);

  const DiagnosticsStatus& S = diagnostics_engine_get_status();
  const DiagnosticsTestAllStatus& T = diagnostics_engine_get_test_all_status();

  uint8_t vBtns = S.pcf_raw;
  bool leftNow   = ((vBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
  bool rightNow  = ((vBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
  bool selNow    = ((vBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;
  bool leftPrev  = ((s_prevBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
  bool rightPrev = ((s_prevBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
  bool selPrev   = ((s_prevBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;
  bool leftEdge     = (leftNow  && !leftPrev);   // press
  bool rightEdge    = (rightNow && !rightPrev);  // press
  bool selEdge      = (selNow   && !selPrev);    // press
  bool leftRelease  = (!leftNow  && leftPrev);   // release
  bool rightRelease = (!rightNow && rightPrev);  // release
  bool selRelease   = (!selNow   && selPrev);    // release
  s_prevBtns = vBtns;

  // Page navigation (except when in HC-05/SD confirm or TEST ALL running)
  bool lockNavigation = ((s_page == 2 && (s_hcUiState == 1 || s_hcUiState == 2)) ||
                         (s_page == 3 && (s_sdUiState == 1)) ||
                         (s_page == 0 && T.running));
  if (!lockNavigation) {
    if (leftRelease) {
      if (s_page == 0) s_page = kDiagPageCount - 1;
      else             s_page--;
    }
    if (rightRelease) {
      s_page = (uint8_t)((s_page + 1) % kDiagPageCount);
    }
  }

  // TEST ALL trigger on summary page
  if (s_page == 0 && selRelease && !T.running) {
    diagnostics_engine_start_test_all();
  }

  // HC-05 UI state machine (page 3 index 2)
  if (s_page == 2) {
    uint32_t nowMs = millis();

    switch (s_hcUiState) {
      case 0: // view
        if (selRelease) {
          s_hcUiState    = 1;
          s_hcConfirmYes = true;
        }
        break;

      case 1: // confirm
        if (leftRelease || rightRelease) {
          s_hcConfirmYes = !s_hcConfirmYes;
        }
        if (selRelease) {
          if (s_hcConfirmYes) {
            diagnostics_engine_init(); // re-run full HC-05 + ELM setup
            s_hcUiState  = 2;
            s_hcStartMs  = nowMs;
            s_hcSuccess  = false;
          } else {
            s_hcUiState = 0;
          }
        }
        break;

      case 2: // running
        if (S.hc05_baud_detected == 115200 &&
            S.hc05_name[0] != '\0') {
          if (strncmp(S.hc05_name, "AXION_HC-05", 11) == 0) {
            s_hcSuccess = true;
          } else {
            s_hcSuccess = false;
          }
          s_hcUiState = 3;
        } else if ((int32_t)(nowMs - s_hcStartMs) > 10000) {
          s_hcSuccess = false;
          s_hcUiState = 3;
        }
        break;

      case 3: // done
        if (selRelease) {
          s_hcUiState = 0;
        }
        break;
    }
  } else {
    s_hcUiState = 0;
  }

  // SD card config UI state machine (page 4 index 3)
  if (s_page == 3) {
    switch (s_sdUiState) {
      case 0: // view
        if (selRelease && S.sd_present && S.sd_ok) {
          s_sdUiState    = 1;
          s_sdConfirmYes = true;
        }
        break;

      case 1: // confirm
        if (leftRelease || rightRelease) {
          s_sdConfirmYes = !s_sdConfirmYes;
        }
        if (selRelease) {
          if (s_sdConfirmYes) {
            s_sdSuccess = diagnostics_engine_sd_prepare(true);
            s_sdUiState = 2;
          } else {
            s_sdUiState = 0;
          }
        }
        break;

      case 2: // done
        if (selRelease) {
          s_sdUiState = 0;
        }
        break;
    }
  } else {
    s_sdUiState = 0;
  }

  canvas.fillScreen(colGray(0));

  switch (s_page) {
    case 0: draw_page_summary(S);       break;
    case 1: draw_page_data(S);          break;
    case 2:
      if (s_hcUiState == 0) {
        draw_page_hc05_view(S);
      } else if (s_hcUiState == 1) {
        draw_page_hc05_confirm(s_hcConfirmYes);
      } else if (s_hcUiState == 2) {
        draw_page_hc05_running(S);
      } else {
        draw_page_hc05_done(S, s_hcSuccess);
      }
      break;
    case 3:
      if (s_sdUiState == 0) {
        draw_page_sd_setup_view(S);
      } else if (s_sdUiState == 1) {
        draw_page_sd_setup_confirm(s_sdConfirmYes);
      } else {
        draw_page_sd_setup_done(S, s_sdSuccess);
      }
      break;
    default:
      s_page = 0;
      draw_page_summary(S);
      break;
  }

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(120));
  canvas.setTextDatum(bottom_right);
  char buf[8];
  snprintf(buf, sizeof(buf), "%u/%u", (unsigned)(s_page+1), (unsigned)kDiagPageCount);
  canvas.drawString(buf, 255, 63);
}

