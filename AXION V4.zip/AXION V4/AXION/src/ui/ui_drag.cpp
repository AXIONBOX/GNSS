﻿#include <Arduino.h>

#include "ui/ui_shared.h"
#include "logic_modes/drag_engine.h"

// Drag / Launch UI page (logic in drag_engine)

void drag_handle_serial(int c)
{
  drag_engine_handle_serial(c);
}

void draw_drag(uint32_t frame)
{
  (void)frame;

  static bool s_inited = false;
  if (!s_inited) {
    drag_engine_init();
    s_inited = true;
  }

  uint32_t now = millis();
  drag_engine_update(now);

  bool     dragIsLaunch     = drag_engine_is_launch();
  int      dragDistanceMode = drag_engine_get_distance_mode();
  bool     dragStaging      = drag_engine_is_staging();
  bool     dragRunning      = drag_engine_is_running();
  bool     dragCompleted    = drag_engine_is_completed();
  float    dragElapsed      = drag_engine_get_elapsed();
  float    dragProgress     = drag_engine_get_progress();
  float    bestDrag         = drag_engine_get_best_time_for_current();
  uint32_t dragStageStart   = drag_engine_get_stage_start_ms();

  canvas.fillScreen(colGray(0));

  const int CHRONO_Y_OFFSET = -3;
  const int BAR_Y_BASE      = 53;
  const int BAR_Y_OFFSET    = 7;
  const int BEST_Y_OFFSET   = -1;
  const int splitX          = 74;

  // Background tram on right side
  const uint16_t tramDot = colGray(35);
  for (int y = 0; y < 64; ++y) {
    int startX = splitX + ((y & 1) ? 0 : 1);
    for (int x = startX; x < 256; x += 2) {
      canvas.drawPixel(x, y, tramDot);
    }
  }
  canvas.drawFastVLine(splitX, 0, 64, colGray(96));

  // Title / mode
  const char* modeTitle = dragIsLaunch ? "Launch" : "Drag";
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString(modeTitle, 2, 1);

  // Distance or "Launch"
  if (!dragIsLaunch) {
    const char* distLabels[2] = {"1/4", "1/8"};
    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString(distLabels[dragDistanceMode], splitX / 2, 21);
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(180));
    canvas.drawString("mi", splitX / 2, 34);
  } else {
    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString("Launch", splitX / 2, 27);
  }

  // BEST time
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(bottom_left);
    int bestX = splitX + 3;
    int bestY = 63 + BEST_Y_OFFSET;
    canvas.setTextColor(colGray(180));
    canvas.drawString("BEST:", bestX, bestY);

    char bestStr[16];
    snprintf(bestStr, sizeof(bestStr), "%.2fs", bestDrag);
    int labelW = canvas.textWidth("BEST:");
    canvas.setTextColor(colGray(255));
    canvas.drawString(bestStr, bestX + labelW + 5, bestY);
  }

  // Central chrono
  float chronoVal = dragElapsed;
  if (!dragRunning && !dragCompleted) chronoVal = 0.00f;
  int secondsInt  = (int)chronoVal;
  int hundredths  = (int)roundf((chronoVal - secondsInt) * 100.0f);
  int tensSec     = secondsInt / 10;
  int unitsSec    = secondsInt % 10;
  int tenths      = (hundredths / 10) % 10;
  int hunds       = hundredths % 10;

  const int baseline   = 27 + CHRONO_Y_OFFSET;
  const int wDigit     = 20;
  const int spacing    = 15;
  const int dotW       = 10;
  const int centerX    = splitX + (256 - splitX) / 2 - 16;
  const int totalWidth = (wDigit * 4) + (spacing * 4) + dotW;
  const int xStart     = centerX - totalWidth / 2;

  canvas.setFont(&Race_Sport24pt7b);
  canvas.setTextColor(colGray(255));
  canvas.setTextDatum(middle_left);

  int  x      = xStart;
  char strBuf[2];
  strBuf[1] = 0;
  strBuf[0] = '0' + tensSec;  canvas.drawString(strBuf, x + 6, baseline); x += wDigit + spacing;
  strBuf[0] = '0' + unitsSec; canvas.drawString(strBuf, x + 6, baseline); x += wDigit + spacing;

  canvas.setFont(&::FreeSansBoldOblique10pt7b);
  canvas.drawString(",", x + 16, baseline + 8);
  x += dotW + spacing;

  canvas.setFont(&Race_Sport24pt7b);
  strBuf[0] = '0' + tenths; canvas.drawString(strBuf, x, baseline); x += wDigit + spacing;
  strBuf[0] = '0' + hunds;  canvas.drawString(strBuf, x, baseline);

  canvas.setFont(&::FreeSansBoldOblique10pt7b);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(middle_right);
  canvas.drawString("s", 254, baseline + 13);

  // Progress bar + LEDs
  const int barX       = splitX + 10;
  const int barY       = BAR_Y_BASE - BAR_Y_OFFSET;
  const int barW       = 160;
  const int barH       = 5;
  const int ledCount   = 8;
  const int ledSpacing = barW / ledCount;
  uint16_t  colOff     = colGray(32);
  uint16_t  colOn      = colGray(255);
  uint16_t  colMid     = colGray(120);

  if (dragStaging && dragStageStart > 0) {
    uint32_t seqElapsed = millis() - dragStageStart;
    int      active     = seqElapsed / 250;  // 250 ms per LED
    for (int i = 0; i < ledCount; i++) {
      int      lx = barX + i * ledSpacing;
      uint16_t c  = (i <= active) ? colMid : colOff;
      canvas.fillRect(lx, barY, ledSpacing - 2, barH, c);
    }
  } else if (dragRunning) {
    int lit = (int)(ledCount * dragProgress);
    for (int i = 0; i < ledCount; i++) {
      int      lx = barX + i * ledSpacing;
      uint16_t c  = (i <= lit) ? colOn : colOff;
      canvas.fillRect(lx, barY, ledSpacing - 2, barH, c);
    }
  } else if (!dragRunning && !dragCompleted) {
    float seq = fmodf((millis() / 150.0f), (float)ledCount);
    for (int i = 0; i < ledCount; i++) {
      int      lx = barX + i * ledSpacing;
      uint16_t c  = (seq >= i - 0.5f && seq < i + 0.5f) ? colMid : colOff;
      canvas.fillRect(lx, barY, ledSpacing - 2, barH, c);
    }
  }
  canvas.drawRect(barX, barY, barW, barH, colGray(64));

  // Status text
  canvas.setFont(&fonts::Font0);
  canvas.setTextDatum(bottom_left);
  if (dragCompleted) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("FINISHED", 2, 63);
  } else if (dragRunning) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("GO!", 2, 63);
  } else if (dragStaging && dragStageStart > 0) {
    canvas.setTextColor(colGray(180));
    canvas.drawString("PRE-STAGE", 2, 63);
  } else {
    canvas.setTextColor(colGray(128));
    canvas.drawString("STAGING", 2, 63);
  }
}
