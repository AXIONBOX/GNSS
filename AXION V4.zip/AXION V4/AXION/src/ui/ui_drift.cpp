﻿#include <Arduino.h>

#include "ui/ui_shared.h"
#include "logic_modes/drift_engine.h"

// Visual helpers (car rendering) kept in UI layer

static inline uint16_t TONE_BODY_HI() { return colGray(240); }
static inline uint16_t TONE_BODY()    { return colGray(200); }
static inline uint16_t TONE_SHADOW()  { return colGray(120); }
static inline uint16_t TONE_DARK()    { return colGray(60);  }

static inline void fillQuadRot(
  int cx, int cy, float ca, float sa,
  float x1,float y1, float x2,float y2, float x3,float y3, float x4,float y4,
  uint16_t col
){
  auto RX = [&](float x,float y){ return cx + (int)(x*ca - y*sa); };
  auto RY = [&](float x,float y){ return cy + (int)(x*sa + y*ca); };
  canvas.fillTriangle(RX(x1,y1),RY(x1,y1), RX(x2,y2),RY(x2,y2), RX(x3,y3),RY(x3,y3), col);
  canvas.fillTriangle(RX(x1,y1),RY(x1,y1), RX(x3,y3),RY(x3,y3), RX(x4,y4),RY(x4,y4), col);
}

static void drawCarTop4Tones(int cx, int cy, float angleDeg)
{
  float ar = angleDeg * DEG_TO_RAD;
  float ca = cosf(ar), sa = sinf(ar);
  const int halfW = 9;
  const int halfH = 19;

  const int pivotOffset = halfH - 8;
  auto RX = [&](float x,float y){
    float yShifted = y + pivotOffset;
    return cx + (int)(x*ca - yShifted*sa);
  };
  auto RY = [&](float x,float y){
    float yShifted = y + pivotOffset;
    return cy + (int)(x*sa + yShifted*ca);
  };

  uint16_t BODY   = colGray(150);
  uint16_t BODYHI = colGray(190);
  uint16_t SHADE  = colGray(90);

  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2), BODY);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2),
                      RX(-halfW+5, -halfH+2), RY(-halfW+5, -halfH+2), BODY);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(-halfW+3, -halfH+6), RY(-halfW+3, -halfH+6),
                      RX(-halfW+3, -halfH+2), RY(-halfW+3, -halfH+2), BODY);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(-halfW+3, -halfH+2), RY(-halfW+3, -halfH+2),
                      RX(-halfW+5, -halfH+2), RY(-halfW+5, -halfH+2), BODY);
  canvas.fillTriangle(RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-3, -halfH+6),  RY(halfW-3, -halfH+6),
                      RX(halfW-3, -halfH+2),  RY(halfW-3, -halfH+2), BODY);
  canvas.fillTriangle(RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-3, -halfH+2),  RY(halfW-3, -halfH+2),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2), BODY);

  canvas.fillTriangle(RX(-halfW, -halfH+6), RY(-halfW, -halfH+6),
                      RX(halfW, -halfH+6),   RY(halfW, -halfH+6),
                      RX(halfW, halfH-4),    RY(halfW, halfH-4), BODY);
  canvas.fillTriangle(RX(-halfW, -halfH+6), RY(-halfW, -halfH+6),
                      RX(halfW, halfH-4),    RY(halfW, halfH-4),
                      RX(-halfW, halfH-4),   RY(-halfW, halfH-4), BODY);

  canvas.fillTriangle(RX(-halfW+2, halfH-4), RY(-halfW+2, halfH-4),
                      RX(halfW-2, halfH-4),  RY(halfW-2, halfH-4),
                      RX(halfW-2, halfH),    RY(halfW-2, halfH), BODY);
  canvas.fillTriangle(RX(-halfW+2, halfH-4), RY(-halfW+2, halfH-4),
                      RX(halfW-2, halfH),    RY(halfW-2, halfH),
                      RX(-halfW+2, halfH),   RY(-halfW+2, halfH), BODY);

  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2), BODYHI);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2),
                      RX(-halfW+5, -halfH+2), RY(-halfW+5, -halfH+2), BODYHI);

  canvas.fillTriangle(RX(-halfW+3, -3), RY(-halfW+3, -3),
                      RX(halfW-3, -3),  RY(halfW-3, -3),
                      RX(halfW-3, 7),   RY(halfW-3, 7), SHADE);
  canvas.fillTriangle(RX(-halfW+3, -3), RY(-halfW+3, -3),
                      RX(halfW-3, 7),   RY(halfW-3, 7),
                      RX(-halfW+3, 7),  RY(-halfW+3, 7), SHADE);

  int rx1 = RX(-halfW-1, -halfH+8);
  int ry1 = RY(-halfW-1, -halfH+8);
  canvas.fillRect(rx1-1, ry1-2, 2, 5, TONE_DARK());
  canvas.drawRect(rx1-1, ry1-2, 2, 5, colGray(160));
  int rx2 = RX(halfW+1, -halfH+8);
  int ry2 = RY(halfW+1, -halfH+8);
  canvas.fillRect(rx2-1, ry2-2, 2, 5, TONE_DARK());
  canvas.drawRect(rx2-1, ry2-2, 2, 5, colGray(160));

  float wheelBackLeftX = -halfW-1;
  float wheelBackLeftY = halfH-8;
  float wheelBackRightX = halfW+1;
  float wheelBackRightY = halfH-8;

  int wx1 = RX(wheelBackLeftX-1, wheelBackLeftY-2.5f);
  int wy1 = RY(wheelBackLeftX-1, wheelBackLeftY-2.5f);
  int wx2 = RX(wheelBackLeftX+1, wheelBackLeftY-2.5f);
  int wy2 = RY(wheelBackLeftX+1, wheelBackLeftY-2.5f);
  int wx3 = RX(wheelBackLeftX+1, wheelBackLeftY+2.5f);
  int wy3 = RY(wheelBackLeftX+1, wheelBackLeftY+2.5f);
  int wx4 = RX(wheelBackLeftX-1, wheelBackLeftY+2.5f);
  int wy4 = RY(wheelBackLeftX-1, wheelBackLeftY+2.5f);
  canvas.fillTriangle(wx1, wy1, wx2, wy2, wx3, wy3, TONE_DARK());
  canvas.fillTriangle(wx1, wy1, wx3, wy3, wx4, wy4, TONE_DARK());
  canvas.drawLine(wx1, wy1, wx2, wy2, colGray(160));
  canvas.drawLine(wx2, wy2, wx3, wy3, colGray(160));
  canvas.drawLine(wx3, wy3, wx4, wy4, colGray(160));
  canvas.drawLine(wx4, wy4, wx1, wy1, colGray(160));

  int wx5 = RX(wheelBackRightX-1, wheelBackRightY-2.5f);
  int wy5 = RY(wheelBackRightX-1, wheelBackRightY-2.5f);
  int wx6 = RX(wheelBackRightX+1, wheelBackRightY-2.5f);
  int wy6 = RY(wheelBackRightX+1, wheelBackRightY-2.5f);
  int wx7 = RX(wheelBackRightX+1, wheelBackRightY+2.5f);
  int wy7 = RY(wheelBackRightX+1, wheelBackRightY+2.5f);
  int wx8 = RX(wheelBackRightX-1, wheelBackRightY+2.5f);
  int wy8 = RY(wheelBackRightX-1, wheelBackRightY+2.5f);
  canvas.fillTriangle(wx5, wy5, wx6, wy6, wx7, wy7, TONE_DARK());
  canvas.fillTriangle(wx5, wy5, wx7, wy7, wx8, wy8, TONE_DARK());
  canvas.drawLine(wx5, wy5, wx6, wy6, colGray(160));
  canvas.drawLine(wx6, wy6, wx7, wy7, colGray(160));
  canvas.drawLine(wx7, wy7, wx8, wy8, colGray(160));
  canvas.drawLine(wx8, wy8, wx5, wy5, colGray(160));

  canvas.fillCircle(RX(-halfW+4, -halfH+4), RY(-halfW+4, -halfH+4), 1, BODYHI);
  canvas.fillCircle(RX(halfW-4, -halfH+4),  RY(halfW-4, -halfH+4),  1, BODYHI);
  canvas.drawPixel(RX(-halfW+2, halfH-1), RY(-halfW+2, halfH-1), colGray(180));
  canvas.drawPixel(RX(halfW-2, halfH-1),  RY(halfW-2, halfH-1),  colGray(180));

  canvas.drawLine(RX(-halfW, -halfH+6), RY(-halfW, -halfH+6), RX(-halfW, halfH-4), RY(-halfW, halfH-4), TONE_DARK());
  canvas.drawLine(RX(halfW, -halfH+6),  RY(halfW, -halfH+6),  RX(halfW, halfH-4),  RY(halfW, halfH-4),  TONE_DARK());
  canvas.drawLine(RX(-halfW+3, -halfH+1), RY(-halfW+3, -halfH+1), RX(halfW-3, -halfH+1), RY(halfW-3, -halfH+1), TONE_DARK());
}

// UI-specific state (tire trail + fireworks)

static uint8_t  sTireTrail[256 * 64];
static bool     sTrailInit         = false;

struct Fx { int x, y; };
static bool     sFireworksActive   = false;
static const uint32_t sFireworksDuration = 2500;

// Exported for main.cpp LED macros
bool drift_state_active() { return drift_engine_is_active(); }
bool drift_state_flash_or_fire() { return drift_engine_flash_active() || sFireworksActive; }

void draw_drift(uint32_t frame)
{
  canvas.fillScreen(canvas.color565(0,0,0));

  const uint16_t dotColBg = colGray(24);
  for (int yy = 10; yy < 60; ++yy) {
    int sxL = ((yy - 10) & 1);
    for (int xx = sxL; xx < 85; xx += 2) canvas.drawPixel(xx, yy, dotColBg);
    int sxR = 175 + ((yy - 10) & 1);
    for (int xx = sxR; xx < 256; xx += 2) canvas.drawPixel(xx, yy, dotColBg);
  }

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString("Drift", 2, 1);

  // Update engine state
  drift_engine_update(frame);

  uint32_t sessionMs   = drift_engine_get_session_ms();
  int      speedKmh    = drift_engine_get_speed_kmh();
  float    latG        = drift_engine_get_lat_g();
  float    driftAngle  = drift_engine_get_angle();
  bool     driftActive = drift_engine_is_active();
  bool     flashActive = drift_engine_flash_active();
  uint32_t curScore    = drift_engine_get_current_score();
  uint32_t totalScore  = drift_engine_get_total_score();
  float    driftDur    = drift_engine_get_duration();
  float    driftMulti  = drift_engine_get_multiplier();
  int      comboCount  = drift_engine_get_combo_count();

  // Road and car position
  int roadX = 42, roadW = 54, roadY = 0, roadH = 64;
  int roadCenterX = roadX + roadW/2;
  canvas.drawFastVLine(roadX,        roadY, roadH, colGray(96));
  canvas.drawFastVLine(roadX+roadW,  roadY, roadH, colGray(96));
  int dashSpeed  = (speedKmh>0) ? ((int)((speedKmh/220.0f)*14.0f) + 1) : 0;
  int dashOffset = (dashSpeed>0) ? (int)((millis() / (45 / dashSpeed)) % 12) : 0;
  for (int dy=roadY; dy<roadY+roadH; dy+=6) {
    int segY = dy + dashOffset;
    if (segY >= roadY && segY < roadY+roadH-3)
      canvas.drawFastVLine(roadCenterX, segY, 3, colGray(128));
  }

  int   cx       = roadCenterX;
  int   cy       = 20;
  float driftDir = (latG < 0.0f) ? -driftAngle : driftAngle;
  float carAngle = constrain(driftDir, -60.0f, 60.0f);

  // Tire trail buffer scroll
  if (!sTrailInit) { memset(sTireTrail, 0, sizeof(sTireTrail)); sTrailInit = true; }

  static float trailShiftAcc = 0.0f;
  float shiftF = (speedKmh > 0) ? (speedKmh / 220.0f) : 0.0f;
  trailShiftAcc += shiftF;
  int shift = (int)trailShiftAcc;
  if (shift > 3) shift = 3;
  if (shift > 0) trailShiftAcc -= shift;

  if (shift > 0) {
    for (int y = 63; y >= shift; --y) {
      memcpy(&sTireTrail[y*256], &sTireTrail[(y-shift)*256], 256);
    }
    for (int y = 0; y < shift; ++y) {
      memset(&sTireTrail[y*256], 0, 256);
    }
  }

  // Fade tire trail intensity
  for (int i = 0; i < 256*64; ++i) {
    uint8_t v = sTireTrail[i];
    sTireTrail[i] = (v > 2) ? (uint8_t)(v - 2) : 0;
  }

  // New tire marks only when drifting enough
  if (fabsf(carAngle) > 8.0f) {
    auto worldFromLocal = [&](float x,float y,float ang,int Cx,int Cy){
      const int pivotOffset = 19 - 8;
      float ar = ang * DEG_TO_RAD, ca = cosf(ar), sa = sinf(ar);
      float ys = y + pivotOffset;
      int X = Cx + (int)(x*ca - ys*sa);
      int Y = Cy + (int)(x*sa + ys*ca);
      return std::pair<int,int>(X,Y);
    };
    const int   halfW       = 11;
    const int   halfH       = 19;
    const float yRearAxle   = halfH - 8;
    const float tireHalfLen = 2.5f;
    const float yRearEdge   = yRearAxle + tireHalfLen + 4.0f;
    const float xLeft       = -(halfW+1);
    const float xRight      =  (halfW+1);
    auto L = worldFromLocal(xLeft,  yRearEdge, carAngle, cx, cy);
    auto R = worldFromLocal(xRight, yRearEdge, carAngle, cx, cy);

    auto stampTrail = [&](int sx,int sy){
      const int trailLen = 6;
      for (int i = 0; i < trailLen; ++i) {
        int bx = sx;
        int by = sy - i;
        for (int ox = -1; ox <= 1; ++ox) {
          for (int oy = -1; oy <= 1; ++oy) {
            int px = bx + ox;
            int py = by + oy;
            if ((unsigned)px < 256 && (unsigned)py < 64) {
              uint8_t &cell = sTireTrail[py*256 + px];
              uint8_t val   = (uint8_t)(120 - i*15);
              if (val < 30) val = 30;
              if (val > cell) cell = val;
            }
          }
        }
      }
    };
    stampTrail(L.first + 3, L.second);
    stampTrail(R.first - 3, R.second);
  }

  // Render tire trail
  for (int y = 0; y < 64; ++y) {
    for (int x = 0; x < 256; ++x) {
      uint8_t v = sTireTrail[y*256 + x];
      if (v) canvas.drawPixel(x, y, colGray(v));
    }
  }

  // Car sprite
  drawCarTop4Tones(cx, cy, carAngle);

  // Angle display
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(top_left);
  canvas.drawString("ANGLE", 2, 12);
  char angleStr[16];
  snprintf(angleStr, sizeof(angleStr), "%3.0f", driftAngle);
  canvas.setFont(&fonts::Font2);
  canvas.setTextColor(colGray(255));
  canvas.drawString(angleStr, 2, 20);
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  int angleWidth = canvas.textWidth(angleStr, &fonts::Font2);
  canvas.drawString("o", 2 + angleWidth + 2, 22);

  // Multiplier
  canvas.setTextColor(colGray(160));
  canvas.drawString("MULTI", 2, 38);
  canvas.setTextColor(colGray(255));
  char multiStr[16];
  snprintf(multiStr, sizeof(multiStr), "x%.1f", driftMulti);
  canvas.drawString(multiStr, 2, 48);

  // Current score (right side)
  {
    const int scoreY = 0, scoreH = 64;
    const uint16_t dotCol = colGray(40);
    int tramStartX = 97;
    int tramEndX   = 255;
    for (int yy = scoreY; yy < scoreY + scoreH; ++yy) {
      int sx = tramStartX + ((yy - scoreY) & 1);
      for (int xx = sx; xx < tramEndX; xx += 2) {
        canvas.drawPixel(xx, yy, dotCol);
      }
    }

    canvas.setFont(&Race_Sport24pt7b);
    canvas.setTextColor(colGray(255));
    canvas.setTextDatum(top_left);

    uint32_t scoreVal = curScore;
    if (scoreVal > 99999) scoreVal = 99999;

    int d5 = scoreVal / 10000;
    int d4 = (scoreVal / 1000) % 10;
    int d3 = (scoreVal / 100) % 10;
    int d2 = (scoreVal / 10) % 10;
    int d1 = scoreVal % 10;

    int wDigit   = 20;
    int spacing  = 15;
    int centerX  = (tramStartX + tramEndX) / 2;

    auto offsetIfOne = [](int d, bool alignRight)->int {
      if (d != 1) return 0;
      return alignRight ? 6 : -6;
    };

    int numDigits = (scoreVal>=10000)?5:
                    (scoreVal>=1000)?4:
                    (scoreVal>=100)?3:
                    (scoreVal>=10)?2:1;

    int xStart = centerX - ((numDigits * (wDigit + spacing)) / 2) + (wDigit/2) - 10;
    int xPos = xStart;

    if (d5>0){
      char c[2]={(char)('0'+d5),0};
      canvas.drawString(c, xPos + offsetIfOne(d5,true), scoreY-3);
      xPos+=wDigit+spacing;
    }
    if (scoreVal>=1000){
      char c[2]={(char)('0'+d4),0};
      canvas.drawString(c, xPos + offsetIfOne(d4,true), scoreY-3);
      xPos+=wDigit+spacing;
    }
    if (scoreVal>=100){
      char c[2]={(char)('0'+d3),0};
      canvas.drawString(c, xPos + offsetIfOne(d3,true), scoreY-3);
      xPos+=wDigit+spacing;
    }
    if (scoreVal>=10){
      char c[2]={(char)('0'+d2),0};
      canvas.drawString(c, xPos + offsetIfOne(d2,true), scoreY-3);
      xPos+=wDigit+spacing;
    }
    {
      char c[2]={(char)('0'+d1),0};
      int adj = offsetIfOne(d1,false);
      if (d1==1) adj += 6;
      canvas.drawString(c, xPos+adj, scoreY-3);
    }
  }

  // Fireworks: start when flash window just ended
  static bool sPrevFlash = false;
  if (!flashActive && sPrevFlash) {
    sFireworksActive = true;
  }
  sPrevFlash = flashActive;

  if (sFireworksActive) {
    static uint32_t fwStart = 0;
    static Fx fwPos[5];
    if (fwStart == 0) {
      fwStart = millis();
      for (int i = 0; i < 5; ++i) {
        fwPos[i].x = 120 + (rand() % 40) - 20;
        fwPos[i].y = 20 + (rand() % 20) - 10;
      }
    }
    uint32_t elapsed = millis() - fwStart;
    if (elapsed < sFireworksDuration) {
      float tNorm = (float)elapsed / (float)sFireworksDuration;
      for (int i = 0; i < 5; ++i) {
        int fx = fwPos[i].x;
        int fy = fwPos[i].y;
        int radius = 4 + (int)(tNorm * 12);
        uint8_t col = (uint8_t)(255 * (1.0f - tNorm));
        for (int a = 0; a < 360; a += 15) {
          float rad = a * DEG_TO_RAD;
          int x0 = fx + (int)(cosf(rad) * radius);
          int y0 = fy + (int)(sinf(rad) * radius);
          canvas.drawPixel(x0, y0, colGray(col));
        }
      }
    } else {
      sFireworksActive = false;
      fwStart = 0;
    }
  }

  // Bottom summaries (total, time, speed, label)
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_left);
    canvas.drawString("TOTAL", 98, 54);
    canvas.setTextColor(colGray(255));
    char totalStr[12]; snprintf(totalStr, sizeof(totalStr), "%lu", (unsigned long)totalScore);
    canvas.drawString(totalStr, 102, 63);
  }
  {
    int comboW = canvas.textWidth("COMBO");
    int tramEndX = (254 - comboW) - 2;
    int minutes = (sessionMs/1000)/60;
    int seconds = (sessionMs/1000)%60;
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_right);
    canvas.drawString("TIME", tramEndX, 54);
    canvas.setTextColor(colGray(255));
    char timeStr[10]; snprintf(timeStr, sizeof(timeStr), "%d:%02d", minutes, seconds);
    canvas.drawString(timeStr, tramEndX, 63);
  }
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_right);
    canvas.drawString("km/h", 254, 54);
    canvas.setTextColor(colGray(255));
    char speedStr[8]; snprintf(speedStr, sizeof(speedStr), "%d", speedKmh);
    canvas.drawString(speedStr, 254, 63);
  }
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(bottom_center);
    int comboW = canvas.textWidth("COMBO");
    int tramEndX = (254 - comboW) - 2;
    int leftX = 102;
    int centerX = leftX + (tramEndX - leftX) / 2;

    const char* label = nullptr;
    if (driftActive) {
      if (comboCount >= 3)      label = "CHAIN!";
      else if (driftAngle > 45.0f)   label = "PERFECT";
      else if (driftDur > 3.0f) label = "LONG";
      else if (speedKmh > 150)        label = "SPEED";
    }
    if (label) {
      canvas.setTextColor(colGray(255));
      canvas.drawString(label, centerX, 63);
    }
  }
}


