﻿#include <Arduino.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/gforce_engine.h"

// Page UI : G-Forces (logic in gforce_engine, UI only)

void draw_gforces(uint32_t frame)
{
  static bool s_inited = false;
  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    gforce_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);

  gforce_engine_update(D, frame);

  float ax = gforce_engine_get_ax();
  float ay = gforce_engine_get_ay();

  canvas.fillScreen(canvas.color565(0,0,0));

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString("G-forces", 2, 1);

  const int lp_y = 6;

  const int cx = 207, cy = 31; const int R = 31;
  canvas.drawCircle(cx, cy, R,                       colGray(64));
  canvas.drawCircle(cx, cy, (int)(R*(1.0f/1.25f)),  colGray(32));
  canvas.drawCircle(cx, cy, (int)(R*(0.5f/1.25f)),  colGray(24));
  canvas.drawFastHLine(cx-R, cy, 2*R+1, colGray(48));
  canvas.drawFastVLine(cx, cy-R, 2*R+1, colGray(48));

  int px = cx + (int)(ax * (R-5) / 1.25f);
  int py = cy + (int)(ay * (R-5) / 1.25f);
  static const int TBUF = 64; static int tHead = 0; static int16_t hx[TBUF]; static int16_t hy[TBUF];
  hx[tHead] = px; hy[tHead] = py; tHead = (tHead + 1) % TBUF;

  int trailLength = 50;
  float ayNormalized = ay / 1.25f;
  int thickness;
  if (ayNormalized < -0.1f)      thickness = 3;
  else if (ayNormalized > 0.1f)  thickness = 1;
  else                           thickness = 2;

  for (int i = 2; i <= trailLength; i++) {
    int histIdx = (tHead - i + TBUF) % TBUF;
    int tpx = hx[histIdx];
    int tpy = hy[histIdx];

    int dx = tpx - cx;
    int dy = tpy - cy;
    if (dx*dx + dy*dy > (R-1)*(R-1)) continue;

    float age = (float)i / (float)trailLength;
    float fade = 1.0f - age;
    uint8_t brightness = (uint8_t)(220.0f * fade);
    if (brightness < 30) continue;

    canvas.drawPixel(tpx, tpy, colGray(brightness));
    if (thickness > 1) {
      if (thickness >= 2) {
        canvas.drawPixel(tpx+1, tpy, colGray((uint8_t)(brightness * 0.7f)));
        canvas.drawPixel(tpx-1, tpy, colGray((uint8_t)(brightness * 0.7f)));
      }
      if (thickness >= 3) {
        canvas.drawPixel(tpx, tpy+1, colGray((uint8_t)(brightness * 0.7f)));
        canvas.drawPixel(tpx, tpy-1, colGray((uint8_t)(brightness * 0.7f)));
      }
    }
  }

  canvas.fillCircle(px, py, 2, colGray(255));

  float gMaxAccel = gforce_engine_get_max_accel();
  float gMaxBrake = gforce_engine_get_max_brake();
  float gMaxLat   = gforce_engine_get_max_lat();
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_left);
    int tx0 = 2; int ty0 = 63;
    const char* prefix = "MAX "; canvas.drawString(prefix, tx0, ty0);
    int xAfter = tx0 + canvas.textWidth(prefix);
    int wA = canvas.textWidth("ACCEL");
    int wB = canvas.textWidth("BRAKE");
    int wL = canvas.textWidth("LAT");
    int slot = max(wA, max(wB, wL));
    int sel = (int)((millis()/3000)%3);
    const char* label = (sel==0?"ACCEL":(sel==1?"BRAKE":"LAT"));
    float valF = (sel==0?gMaxAccel:(sel==1?gMaxBrake:gMaxLat));
    char val[16]; snprintf(val,sizeof(val),"%0.2fG",valF);
    canvas.drawString(label, xAfter, ty0);
    canvas.drawString(val, xAfter + slot + 6, ty0);
  }

  {
    int y = lp_y + 11; int h = 12;
    canvas.setFont(&fonts::Font0); canvas.setTextColor(canvas.color565(153,153,153)); canvas.setTextDatum(middle_left);
    const char* L1 = "LONG"; int lblX=2; int lblY=y+h/2; int lblW=canvas.textWidth(L1); canvas.drawString(L1,lblX,lblY);
    int x = lblX + lblW + 4; int rightLimit=168; int w = rightLimit - x; if (w<10) w=10; int mid = x + w/2;
    char vtxt[16]; snprintf(vtxt,sizeof(vtxt),"%0.2fG",fabsf(ay)); canvas.setFont(&fonts::Font2);
    int spacing=2; int txtW=0; {int n=(int)strlen(vtxt); for(int i=0;i<n;i++){ char t[2]={vtxt[i],'\0'}; txtW+=canvas.textWidth(t); if(i<n-1) txtW+=spacing; }}
    int gap = txtW + 6; if (gap<36) gap=36; if (gap>w-4) gap=w-4; int gapHalf=gap/2;
    int leftW=(mid-gapHalf)-x; if(leftW<0) leftW=0; int rightX=mid+gapHalf; int rightW=(x+w)-rightX; if(rightW<0) rightW=0;
    if (leftW > 0)  canvas.fillRect(x, y, leftW,  h, canvas.color565(34,34,34));
    if (rightW > 0) canvas.fillRect(rightX, y, rightW, h, canvas.color565(34,34,34));
    int halfMax=(w/2)-gapHalf; if(halfMax<0) halfMax=0; int cw=(int)((ay/1.25f)*halfMax);
    if(cw>=0){ if(cw>rightW) cw=rightW; if(cw>0) canvas.fillRect(rightX,y,cw,h,colGray(255)); }
    else { int cwa=-cw; if(cwa>leftW) cwa=leftW; if(cwa>0) canvas.fillRect((mid-gapHalf)-cwa,y,cwa,h,colGray(255)); }
    if (leftW > 0)  canvas.drawRect(x, y, leftW,  h, colGray(48));
    if (rightW > 0) canvas.drawRect(rightX, y, rightW, h, colGray(48));
    canvas.setTextDatum(middle_left); canvas.setTextColor(colGray(224));
    int xStart=mid-(txtW/2); int xd=xStart; int yd=y+h/2; {int n=(int)strlen(vtxt); for(int i=0;i<n;i++){ char t[2]={vtxt[i],'\0'}; canvas.drawString(t,xd,yd); int cw=canvas.textWidth(t); xd+=cw+spacing; }}
    xd=xStart+1; {int n=(int)strlen(vtxt); for(int i=0;i<n;i++){ char t[2]={vtxt[i],'\0'}; canvas.drawString(t,xd,yd); int cw=canvas.textWidth(t); xd+=cw+spacing; }}
    canvas.setFont(&fonts::Font0); canvas.setTextColor(canvas.color565(153,153,153));
  }

  {
    int y = lp_y + 29; int h = 12;
    canvas.setFont(&fonts::Font0); canvas.setTextColor(canvas.color565(153,153,153)); canvas.setTextDatum(middle_left);
    const char* L2 = "LAT"; int lblX=2; int lblY=y+h/2; canvas.drawString(L2,lblX,lblY);
    int x = lblX + canvas.textWidth("LONG") + 4; int rightLimit=168; int w = rightLimit - x; if (w<10) w=10; int mid = x + w/2;
    char vtxt[16]; snprintf(vtxt,sizeof(vtxt),"%0.2fG",fabsf(ax)); canvas.setFont(&fonts::Font2);
    int spacing=2; int txtW=0; {int n=(int)strlen(vtxt); for(int i=0;i<n;i++){ char t[2]={vtxt[i],'\0'}; txtW+=canvas.textWidth(t); if(i<n-1) txtW+=spacing; }}
    int gap = txtW + 6; if (gap<36) gap=36; if (gap>w-4) gap=w-4; int gapHalf=gap/2;
    int leftW=(mid-gapHalf)-x; if(leftW<0) leftW=0; int rightX=mid+gapHalf; int rightW=(x+w)-rightX; if(rightW<0) rightW=0;
    if (leftW > 0)  canvas.fillRect(x, y, leftW,  h, canvas.color565(34,34,34));
    if (rightW > 0) canvas.fillRect(rightX, y, rightW, h, canvas.color565(34,34,34));
    int halfMax=(w/2)-gapHalf; if(halfMax<0) halfMax=0; int cw=(int)((ax/1.25f)*halfMax);
    if(cw>=0){ if(cw>rightW) cw=rightW; if(cw>0) canvas.fillRect(rightX,y,cw,h,colGray(255)); }
    else { int cwa=-cw; if(cwa>leftW) cwa=leftW; if(cwa>0) canvas.fillRect((mid-gapHalf)-cwa,y,cwa,h,colGray(255)); }
    if (leftW > 0)  canvas.drawRect(x, y, leftW,  h, colGray(48));
    if (rightW > 0) canvas.drawRect(rightX, y, rightW, h, colGray(48));
    canvas.setTextDatum(middle_left); canvas.setTextColor(colGray(224));
    int xStart=mid-(txtW/2); int xd=xStart; int yd=y+h/2; {int n=(int)strlen(vtxt); for(int i=0;i<n;i++){ char t[2]={vtxt[i],'\0'}; canvas.drawString(t,xd,yd); int cw=canvas.textWidth(t); xd+=cw+spacing; }}
    xd=xStart+1; {int n=(int)strlen(vtxt); for(int i=0;i<n;i++){ char t[2]={vtxt[i],'\0'}; canvas.drawString(t,xd,yd); int cw=canvas.textWidth(t); xd+=cw+spacing; }}
    canvas.setFont(&fonts::Font0); canvas.setTextColor(canvas.color565(153,153,153));
  }

  int speedKmhDisplay = (int)(D.speed_kmh + 0.5f);
  if (speedKmhDisplay < 0) speedKmhDisplay = 0;
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(bottom_right);
  canvas.drawString("km/h", 254, 54);
  canvas.setTextColor(colGray(255));
  char speedText[16];
  snprintf(speedText, sizeof(speedText), "%d", speedKmhDisplay);
  canvas.drawString(speedText, 254, 63);
}
