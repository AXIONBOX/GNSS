﻿#include <Arduino.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/accel_engine.h"

// Page UI : Accel / Brake 0-X km/h (logique déplacée dans accel_engine)

void accel_handle_serial(int c)
{
  accel_engine_handle_serial(c);
}

void draw_accel(uint32_t frame)
{
  (void)frame;

  static bool s_inited = false;
  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    accel_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  uint32_t now = millis();
  accel_engine_update(D, now);

  bool  accelIsBrake      = accel_engine_is_brake();
  int   accelTarget       = accel_engine_get_target();
  bool  accelRunning      = accel_engine_is_running();
  bool  accelCompleted    = accel_engine_is_completed();
  float accelElapsed      = accel_engine_get_elapsed();
  float accelSpeedKmh     = accel_engine_get_speed_kmh();
  uint32_t lastModeChange = accel_engine_get_last_mode_change_ms();
  int   accelModeChangeDir= accel_engine_get_mode_change_dir();

  canvas.fillScreen(colGray(0));

  const int CHRONO_Y_OFFSET = -3;
  const int BAR_Y_BASE      = 53;
  const int BAR_Y_OFFSET    = 7;
  const int BEST_Y_OFFSET   = -1;
  const int splitX          = 74;

  // Tramage de fond côté droit
  const uint16_t tramDot = colGray(35);
  for (int y = 0; y < 64; ++y) {
    int startX = splitX + ((y & 1) ? 0 : 1);
    for (int x = startX; x < 256; x += 2) {
      canvas.drawPixel(x, y, tramDot);
    }
  }
  canvas.drawFastVLine(splitX, 0, 64, colGray(96));

  // Titre / mode
  const char* modeTitle = accelIsBrake ? "Brake" : "Accel";
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString(modeTitle, 2, 1);

  // Flèches gauche/droite qui flashent à la sélection
  static uint8_t flashLeft = 0, flashRight = 0;
  if (now - lastModeChange < 150) {
    flashLeft  = (accelModeChangeDir < 0);
    flashRight = (accelModeChangeDir > 0);
  } else {
    flashLeft  = 0;
    flashRight = 0;
  }

  uint8_t arrowLeftCol  = flashLeft  ? 255 : 120;
  uint8_t arrowRightCol = flashRight ? 255 : 120;

  int arrowY = 26;
  canvas.setFont(&fonts::Font0);
  canvas.setTextDatum(middle_left);
  canvas.setTextColor(colGray(arrowLeftCol));
  canvas.drawString("<", 2, arrowY);
  canvas.setTextDatum(middle_right);
  canvas.setTextColor(colGray(arrowRightCol));
  canvas.drawString(">", splitX - 2, arrowY);

  // Affichage du mode cible (0-X ou X-0)
  canvas.setFont(&::FreeSansBoldOblique10pt7b);
  canvas.setTextDatum(middle_center);
  canvas.setTextColor(colGray(255));
  char modeStr[16];
  if (!accelIsBrake) {
    snprintf(modeStr, sizeof(modeStr), "0-%d", accelTarget);
  } else {
    snprintf(modeStr, sizeof(modeStr), "%d-0", accelTarget);
  }
  canvas.drawString(modeStr, splitX / 2, 21);

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(180));
  canvas.drawString("km/h", splitX / 2, 34);

  // BEST time
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(bottom_left);
    int bestX = splitX + 3;
    int bestY = 63 + BEST_Y_OFFSET;
    canvas.setTextColor(colGray(180));
    canvas.drawString("BEST:", bestX, bestY);

    char bestStr[16];
    int  idx = accelIsBrake ? 1 : 0;
    float best = accel_engine_get_best_time_for_index(idx);
    if (best > 0.0f) {
      snprintf(bestStr, sizeof(bestStr), "%.2fs", best);
    } else {
      snprintf(bestStr, sizeof(bestStr), "---");
    }

    int labelW = canvas.textWidth("BEST:");
    canvas.setTextColor(colGray(255));
    canvas.drawString(bestStr, bestX + labelW + 5, bestY);
  }

  // Chronomètre central
  {
    float chronoVal = accelElapsed;
    if (!accelRunning && !accelCompleted) chronoVal = 0.00f;

    int secondsInt = (int)chronoVal;
    if (secondsInt > 99) secondsInt = 99;
    int tensSec = secondsInt / 10;
    int unitsSec = secondsInt % 10;
    int hundredths = (int)roundf((chronoVal - secondsInt) * 100.0f);
    if (hundredths > 99) hundredths = 99;
    int tenths = (hundredths / 10) % 10;
    int hunds  = hundredths % 10;

    const int baseline   = 27 + CHRONO_Y_OFFSET;
    const int wDigit     = 20;
    const int spacing    = 15;
    const int dotW       = 10;
    const int centerX    = splitX + (256 - splitX) / 2 + 14 - 30;
    const int totalWidth = (wDigit * 4) + (spacing * 4) + dotW;
    const int xStart     = centerX - totalWidth / 2;

    auto adjOne = [](int d, bool alignRight)->int {
      return (d == 1) ? (alignRight ? 18 : -6) : 0;
    };

    canvas.setFont(&Race_Sport24pt7b);
    canvas.setTextColor(colGray(255));
    canvas.setTextDatum(middle_left);

    int x = xStart;

    {
      char c[2] = {(char)('0' + tensSec), 0};
      int  adj  = adjOne(tensSec, true);
      canvas.drawString(c, x + 10 + adj + 6, baseline);
      x += wDigit + spacing;
    }
    {
      char c[2] = {(char)('0' + unitsSec), 0};
      int  adj  = adjOne(unitsSec, true);
      canvas.drawString(c, x + 10 + adj + 6, baseline);
      x += wDigit + spacing;
    }

    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextColor(colGray(255));
    canvas.setTextDatum(middle_left);
    const int COMMA_DX = 16;
    const int COMMA_DY = 8;
    canvas.drawString(",", x + COMMA_DX,     baseline + COMMA_DY);
    canvas.drawString(",", x + COMMA_DX + 1, baseline + COMMA_DY);
    x += dotW + spacing;

    canvas.setFont(&Race_Sport24pt7b);
    canvas.setTextColor(colGray(255));
    canvas.setTextDatum(middle_left);

    {
      char c[2] = {(char)('0' + tenths), 0};
      int  adj  = adjOne(tenths, true);
      canvas.drawString(c, x + adj, baseline);
      x += wDigit + spacing;
    }
    {
      char c[2] = {(char)('0' + hunds), 0};
      int  adj  = adjOne(hunds, false);
      if (hunds == 1) adj += 6;
      canvas.drawString(c, x + adj, baseline);
      x += wDigit;
    }

    const int S_DX = 15;
    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextColor(colGray(200));
    canvas.setTextDatum(top_left);
    canvas.drawString("s", x + S_DX, baseline + 3);
  }

  // Barre de progression
  {
    int barX = splitX + 10;
    int barY = BAR_Y_BASE - BAR_Y_OFFSET;
    int barW = 160;
    int barH = 5;

    float ratio  = accelRunning ? min(1.0f, accelSpeedKmh / (float)accelTarget) : 0.0f;
    int   filled = (int)(barW * ratio);
    canvas.drawRect(barX, barY, barW, barH, colGray(64));
    if (filled > 0) {
      canvas.fillRect(barX, barY, filled, barH, colGray(255));
    }
  }

  // Texte de statut en bas à gauche
  canvas.setTextDatum(bottom_left);
  canvas.setFont(&::FreeSansBoldOblique10pt7b);

  if (accelCompleted) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("DONE", 2, 63);
  } else if (accelRunning) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("RUN", 2, 63);
  } else {
    canvas.setTextColor(colGray(128));
    canvas.drawString("READY", 2, 63);
  }
}



