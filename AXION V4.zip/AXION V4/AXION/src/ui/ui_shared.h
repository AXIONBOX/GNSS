﻿#pragma once

#include <LovyanGFX.hpp>

// Fonts utilisées par les écrans UI (mêmes includes que dans main.cpp)
#include "Fonts/Rajdhani_Bold28pt7b.h"
#include "Fonts/Race_Sport26pt7b.h"
#include "Fonts/Race_Sport24pt7b.h"
#include "Fonts/capitolcity10pt7b.h"
#include "Fonts/FreeSansBoldOblique12pt7b.h"
#include "Fonts/FreeSansBoldOblique10pt7b.h"

// Canvas global utilisé par toutes les pages UI.
extern LGFX_Sprite canvas;

// Couleur en niveaux de gris.
uint16_t colGray(uint8_t g);

// Table trig utilisée par certaines animations.
extern int16_t sinLUT[256];
void buildSinTable();

