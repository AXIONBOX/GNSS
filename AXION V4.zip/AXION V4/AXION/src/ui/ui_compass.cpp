﻿#include <Arduino.h>
#include <math.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/compass_engine.h"

// Page UI : Compass (version complte, sans DEL)

void draw_compass_ui(uint32_t frame)
{
  static bool s_inited = false;
  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    compass_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  compass_engine_update(D, frame);

  float heading   = compass_engine_get_heading_deg();
  float elevation = compass_engine_get_elevation_deg();
  float lat       = compass_engine_get_lat();
  float lon       = compass_engine_get_lon();

  canvas.fillScreen(canvas.color565(0,0,0));

  // Titre
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString("Compass", 2, 1);

  const int compassY = 11;
  const int compassH = 22;
  const int compassCenterX = 128;

  canvas.fillRect(0, compassY, 256, compassH, colGray(20));
  const uint16_t dotCol = colGray(32);
  for (int yy = compassY; yy < compassY + compassH; ++yy) {
    int startX = ((yy - compassY) & 1);
    for (int xx = startX; xx < 256; xx += 2) {
      canvas.drawPixel(xx, yy, dotCol);
    }
  }

  canvas.drawFastHLine(0, compassY, 256, colGray(128));

  int cardinalAngles[8] = {0, 45, 90, 135, 180, 225, 270, 315};
  for (int i = 0; i < 8; i++) {
    float angleDiff = (float)cardinalAngles[i] - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 5 && offsetX <= 251) {
        bool isCardinal = (i % 2 == 0);
        uint16_t tickCol = isCardinal ? colGray(255) : colGray(192);
        canvas.drawFastVLine(offsetX+1, compassY + 1, 8, colGray(64));
        canvas.drawFastVLine(offsetX,   compassY + 1, 8, tickCol);
      }
    }
  }

  for (int deg = 0; deg < 360; deg += 30) {
    bool skip = false;
    for (int i = 0; i < 8; i++) {
      if (deg == cardinalAngles[i]) { skip = true; break; }
    }
    if (skip) continue;

    float angleDiff = (float)deg - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 5 && offsetX <= 251) {
        canvas.drawFastVLine(offsetX+1, compassY + 1, 6, colGray(48));
        canvas.drawFastVLine(offsetX,   compassY + 1, 6, colGray(128));
      }
    }
  }

  for (int deg = 0; deg < 360; deg += 10) {
    if (deg % 30 == 0) continue;
    float angleDiff = (float)deg - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 5 && offsetX <= 251) {
        canvas.drawFastVLine(offsetX, compassY + 1, 4, colGray(96));
      }
    }
  }

  const char* cardinalLabels[8] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
  for (int i = 0; i < 8; i++) {
    float angleDiff = (float)cardinalAngles[i] - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 15 && offsetX <= 241) {
        bool isCardinal = (i % 2 == 0);
        if (isCardinal) {
          canvas.setFont(&fonts::Font2);
          canvas.setTextDatum(top_center);
          canvas.setTextColor(colGray(48));
          canvas.drawString(cardinalLabels[i], offsetX+1, compassY + 11);
          canvas.setTextColor(colGray(255));
          canvas.drawString(cardinalLabels[i], offsetX,   compassY + 10);
          canvas.drawString(cardinalLabels[i], offsetX+1, compassY + 10);
          canvas.drawString(cardinalLabels[i], offsetX,   compassY + 11);
        } else {
          canvas.setFont(&fonts::Font0);
          canvas.setTextDatum(top_center);
          canvas.setTextColor(colGray(48));
          canvas.drawString(cardinalLabels[i], offsetX+1, compassY + 11);
          canvas.setTextColor(colGray(192));
          canvas.drawString(cardinalLabels[i], offsetX,   compassY + 10);
        }
      }
    }
  }

  int triY = compassY - 6;
  canvas.fillTriangle(compassCenterX, triY + 6,
                      compassCenterX - 5, triY,
                      compassCenterX + 5, triY,
                      colGray(255));
  canvas.drawTriangle(compassCenterX, triY + 6,
                      compassCenterX - 5, triY,
                      compassCenterX + 5, triY,
                      colGray(192));

  char headStr[8];
  snprintf(headStr, sizeof(headStr), "%03d", (int)heading);
  canvas.setFont(&fonts::Font2);
  canvas.setTextDatum(middle_center);
  canvas.setTextColor(colGray(64));
  canvas.drawString(headStr, 129, 45);
  canvas.setTextColor(colGray(255));
  canvas.drawString(headStr, 128, 44);
  canvas.drawString(headStr, 129, 44);
  canvas.drawString(headStr, 128, 45);
  canvas.drawString(headStr, 129, 45);
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.drawString("o", 148, 42);

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(bottom_left);
  canvas.drawString("ELEV", 4, 54);
  canvas.setTextColor(colGray(255));
  char elevStr[8];
  snprintf(elevStr, sizeof(elevStr), "%+.1f", elevation);
  canvas.drawString(elevStr, 4, 63);
  canvas.setTextColor(colGray(160));
  canvas.drawString("o", 4 + canvas.textWidth(elevStr), 63);

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(bottom_right);
  canvas.drawString("GPS", 252, 54);
  canvas.setTextColor(colGray(192));
  char coordStr[24];
  snprintf(coordStr, sizeof(coordStr), "%.4fN %.4fW", lat, fabsf(lon));
  canvas.drawString(coordStr, 252, 63);
}
