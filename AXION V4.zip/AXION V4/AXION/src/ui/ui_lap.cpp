﻿#include <Arduino.h>

#include "ui/ui_shared.h"

#include "data/data_source.h"
#include "logic_modes/lap_engine.h"

// CORE_Project – Lap Timer UI using Lap V11 logic via lap_engine + data_source.
// Fournit la simulation de circuit (via data_source_sim) + carte + tableau des tours.

// --- Helpers for time formatting -------------------------------------------------

static void format_time_mmss_ms(float t, char* buf, size_t n)
{
  if (t <= 0.0f || !isfinite(t)) {
    snprintf(buf, n, "--:--.---");
    return;
  }
  int total_ms = (int)(t * 1000.0f + 0.5f);
  int minutes  = total_ms / 60000;
  int ms_rem   = total_ms % 60000;
  int seconds  = ms_rem / 1000;
  int millis   = ms_rem % 1000;
  snprintf(buf, n, "%d:%02d.%03d", minutes, seconds, millis);
}

// --- Lap history (last 3 laps) --------------------------------------------------

struct LapEntry {
  int   index;
  float time;
};

static LapEntry s_laps[3];
static int      s_lapCount   = 0;
static int      s_totalLaps  = 0;
static float    s_prevLast   = 0.0f;

static void update_lap_history()
{
  float last = lap_engine_get_last_time();
  if (last > 0.0f && last != s_prevLast) {
    s_prevLast = last;
    s_totalLaps++;
    for (int i = 2; i > 0; --i) {
      s_laps[i] = s_laps[i-1];
    }
    s_laps[0].index = s_totalLaps;
    s_laps[0].time  = last;
    if (s_lapCount < 3) s_lapCount++;
  }
}

// --- Circuit mini-map -----------------------------------------------------------

static void draw_track_map(int x0, int y0, int w, int h)
{
  int n = lap_engine_get_track_count();
  if (n <= 1) return;

  float minx = 1e9f, miny = 1e9f, maxx = -1e9f, maxy = -1e9f;
  float px, py;
  for (int i = 0; i < n; ++i) {
    if (!lap_engine_get_track_point(i, px, py)) break;
    if (px < minx) minx = px;
    if (px > maxx) maxx = px;
    if (py < miny) miny = py;
    if (py > maxy) maxy = py;
  }
  if (maxx <= minx || maxy <= miny) return;

  float sx = (float)(w - 4) / (maxx - minx);
  float sy = (float)(h - 4) / (maxy - miny);
  float s  = (sx < sy) ? sx : sy;
  if (s <= 0.0f) return;

  float cx = 0.5f * (minx + maxx);
  float cy = 0.5f * (miny + maxy);

  canvas.drawRect(x0, y0, w, h, colGray(60));

  int  prevX   = 0;
  int  prevY   = 0;
  bool hasPrev = false;
  for (int i = 0; i < n; ++i) {
    if (!lap_engine_get_track_point(i, px, py)) break;
    int sxp = x0 + w/2 + (int)((px - cx) * s);
    int syp = y0 + h/2 - (int)((py - cy) * s);
    if (sxp < x0+1)    sxp = x0+1;
    if (sxp > x0+w-2)  sxp = x0+w-2;
    if (syp < y0+1)    syp = y0+1;
    if (syp > y0+h-2)  syp = y0+h-2;
    if (hasPrev) {
      canvas.drawLine(prevX, prevY, sxp, syp, colGray(160));
    }
    prevX = sxp;
    prevY = syp;
    hasPrev = true;
  }

  // Draw S/F line if available
  float ax, ay, nx, ny;
  if (lap_engine_get_sf_line(ax, ay, nx, ny)) {
    int sAx = x0 + w/2 + (int)((ax - cx) * s);
    int sAy = y0 + h/2 - (int)((ay - cy) * s);
    int len = 6;
    int lx1 = sAx + (int)(-ny * len);
    int ly1 = sAy + (int)( nx * len);
    int lx2 = sAx + (int)( ny * len);
    int ly2 = sAy + (int)(-nx * len);
    canvas.drawLine(lx1, ly1, lx2, ly2, colGray(255));
  }

  // Draw current car position as a small dot
  float cxCur, cyCur;
  if (lap_engine_get_current_xy(cxCur, cyCur)) {
    int sxCar = x0 + w/2 + (int)((cxCur - cx) * s);
    int syCar = y0 + h/2 - (int)((cyCur - cy) * s);
    if (sxCar < x0+1)   sxCar = x0+1;
    if (sxCar > x0+w-2) sxCar = x0+w-2;
    if (syCar < y0+1)   syCar = y0+1;
    if (syCar > y0+h-2) syCar = y0+h-2;
    canvas.fillCircle(sxCar, syCar, 2, colGray(255));
  }
}

// --- Main draw ------------------------------------------------------------------

void draw_lap(uint32_t frame)
{
  (void)frame;

  static bool s_inited = false;
  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    lap_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  lap_engine_update(D);
  update_lap_history();

  canvas.fillScreen(colGray(0));

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(180));
  canvas.setTextDatum(top_left);
  canvas.drawString("lap timer", 2, 1);

  bool track     = lap_engine_track_detected();
  bool running   = lap_engine_is_running();
  bool suspended = lap_engine_is_suspended();

  const char* status = "DETECTING";
  uint16_t statusCol = colGray(120);

  if (!track) {
    status    = "DETECTING";
    statusCol = colGray(120);
  } else if (suspended) {
    status    = "SUSPEND";
    statusCol = colGray(90);
  } else if (running) {
    status    = "LAP";
    statusCol = colGray(255);
  } else {
    status    = "READY";
    statusCol = colGray(200);
  }

  canvas.setTextColor(statusCol);
  canvas.drawString(status, 2, 14);

  float cur   = lap_engine_get_current_time();
  float best  = lap_engine_get_best_time();
  float dBest = lap_engine_get_delta_vs_best();

  if (!running) cur = 0.0f;

  // Current lap time (smaller than before)
  canvas.setFont(&fonts::Font2);
  canvas.setTextDatum(top_left);
  char buf[32];
  snprintf(buf, sizeof(buf), "%.2fs", cur);
  canvas.setTextColor(colGray(255));
  canvas.drawString(buf, 4, 24);

  // Circuit map: full right quarter of screen
  draw_track_map(192, 0, 64, 64);

  // Lap list (left, under timer)
  canvas.setFont(&fonts::Font0);
  canvas.setTextDatum(top_left);
  int   listX   = 8;
  int   listY   = 40;
  float bestLap = best;
  for (int i = 0; i < s_lapCount; ++i) {
    const LapEntry& e = s_laps[i];
    char tbuf[24];
    format_time_mmss_ms(e.time, tbuf, sizeof(tbuf));
    float d = (bestLap > 0.0f) ? (e.time - bestLap) : 0.0f;
    char dbuf[16];
    if (bestLap <= 0.0f) {
      snprintf(dbuf, sizeof(dbuf), "   ");
    } else {
      snprintf(dbuf, sizeof(dbuf), "%+0.3f", d);
    }
    bool     isBest = (bestLap > 0.0f && fabsf(e.time - bestLap) < 1e-3f);
    uint16_t col    = isBest ? colGray(255) : colGray(180);
    canvas.setTextColor(col);
    char line[48];
    snprintf(line, sizeof(line), "L%2d %s %s", e.index, tbuf, dbuf);
    canvas.drawString(line, listX, listY + i*9);
  }

  // Best summary
  canvas.setTextColor(colGray(160));
  char btime[24];
  format_time_mmss_ms(bestLap, btime, sizeof(btime));
  char bline[32];
  snprintf(bline, sizeof(bline), "Best %s", btime);
  canvas.drawString(bline, listX, listY + 3*9);

  // Single delta vs best display (kept for compatibility)
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  if (bestLap > 0.0f) {
    char dline[32];
    snprintf(dline, sizeof(dline), "dT last %+0.3fs", dBest);
    canvas.drawString(dline, 2, 52);
  }
}
