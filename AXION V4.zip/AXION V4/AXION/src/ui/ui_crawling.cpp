﻿#include <Arduino.h>
#include <math.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/crawling_engine.h"

// ========= Crawling mode =========
// - One dynamic square tilt-map (pitch/roll) on the right
// - Text block on the left: Altitude, Pitch, Roll
// - Pmax/Rmax editable via buttons (SELECT / LEFT / RIGHT)
// - Bicolor LED driven from normalized tilt: green / yellow / red

void draw_crawling(uint32_t frame)
{
  (void)frame;

  static bool s_inited = false;
  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    crawling_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  crawling_engine_update(D, frame);

  float pitchDeg = crawling_engine_get_pitch_deg();
  float rollDeg  = crawling_engine_get_roll_deg();
  float speedKmh = crawling_engine_get_speed_kmh();
  float altM     = crawling_engine_get_alt_m();
  float tiltNorm = crawling_get_tilt_now();
  float warnTh   = crawling_get_warnTilt();
  float dangTh   = crawling_get_dangerTilt();
  uint8_t paramSel = crawling_engine_get_param_sel();
  float pitchMax = crawling_engine_get_pitch_max();
  float rollMax  = crawling_engine_get_roll_max();

  canvas.fillScreen(canvas.color565(0,0,0));

  // ===== HEADER =====
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString("Crawling", 2, 1);

  // Grade info
  float grade = 0.0f;
  {
    float rad = pitchDeg * DEG_TO_RAD;
    grade = tanf(rad) * 100.0f;
    if (!isfinite(grade)) grade = 0.0f;
    grade = constrain(grade, -100.0f, 100.0f);
  }

  // ===== BIG SQUARE TILT MAP (right) =====
  {
    const int sqS = 60;                 // square size
    const int sqX = 256 - sqS - 2;      // flush to right
    const int sqY = 2;                  // small top margin
    const int cx  = sqX + sqS/2;
    const int cy  = sqY + sqS/2;

    canvas.drawRect(sqX, sqY, sqS, sqS, colGray(72));
    canvas.drawFastHLine(sqX, cy,  sqS, colGray(56));
    canvas.drawFastVLine(cx,  sqY, sqS, colGray(56));

    float maxViewPitch = (pitchMax > 1.0f) ? pitchMax : 30.0f;
    float maxViewRoll  = (rollMax  > 1.0f) ? rollMax  : 30.0f;
    float xNorm = rollDeg  / maxViewRoll;
    float yNorm = pitchDeg / maxViewPitch;
    if (xNorm < -1.0f) xNorm = -1.0f;
    if (xNorm >  1.0f) xNorm =  1.0f;
    if (yNorm < -1.0f) yNorm = -1.0f;
    if (yNorm >  1.0f) yNorm =  1.0f;

    static const int TBUF = 40;
    static int tHead = 0;
    static int16_t hx[TBUF], hy[TBUF];

    int span = (sqS/2) - 3;
    int px = cx + (int)(xNorm * span);
    int py = cy - (int)(yNorm * span);
    hx[tHead] = px;
    hy[tHead] = py;
    tHead = (tHead + 1) % TBUF;

    for (int i = 1; i < TBUF; ++i) {
      int idx = (tHead - i + TBUF) % TBUF;
      int tx = hx[idx];
      int ty = hy[idx];
      if (tx < sqX+1 || tx > sqX+sqS-2 || ty < sqY+1 || ty > sqY+sqS-2) continue;
      float age = (float)i / (float)TBUF;
      uint8_t g = (uint8_t)(200.0f * (1.0f - age));
      if (g < 30) continue;
      canvas.drawPixel(tx, ty, colGray(g));
    }

    bool warn   = (tiltNorm >= warnTh   && tiltNorm < dangTh);
    bool danger = (tiltNorm >= dangTh);
    uint16_t dotCol = danger ? colGray(((frame/6)&1)?255:120)
                             : (warn ? colGray(255) : colGray(220));
    canvas.fillCircle(px, py, 2, dotCol);
  }

  // ===== LEFT TEXT BLOCK: Altitude + Pitch/Roll =====
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(top_left);

    char buf[32];
    snprintf(buf, sizeof(buf), "Altitude %4.0fm", altM);
    canvas.drawString(buf, 2, 14);

    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(140));
    int pitchLabelY = 28;
    int rollLabelY  = 44;
    canvas.drawString("Pitch", 2, pitchLabelY);
    canvas.drawString("Roll",  2, rollLabelY);

    bool editingPitch = (paramSel == 1);
    bool editingRoll  = (paramSel == 2);
    bool blinkOn      = ((frame / 8) & 1) == 0;

    float pitchValue = editingPitch ? pitchMax : pitchDeg;
    float rollValue  = editingRoll  ? rollMax  : rollDeg;

    int xValBase = 2 + canvas.textWidth("Pitch ") + 2;

    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextColor(colGray(230));
    canvas.setTextDatum(top_left);

    if (!editingPitch || blinkOn) {
      char pbuf[24];
      snprintf(pbuf, sizeof(pbuf), "%+3.0fo", pitchValue);
      canvas.drawString(pbuf, xValBase, pitchLabelY - 4);
    }

    if (!editingRoll || blinkOn) {
      char rbuf[24];
      snprintf(rbuf, sizeof(rbuf), "%+3.0fo", rollValue);
      canvas.drawString(rbuf, xValBase, rollLabelY - 4);
    }

    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(120));
    snprintf(buf, sizeof(buf), "Grade %+.0f%%", grade);
    canvas.drawString(buf, 2, 56);
  }

  // ===== SPEED (bottom-right label, kept simple) =====
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_right);
    canvas.drawString("km/h", 254, 54);

    char sbuf[8];
    int v = (int)(speedKmh + 0.5f);
    if (v < 0) v = 0;
    if (v > 999) v = 999;
    snprintf(sbuf, sizeof(sbuf), "%d", v);

    canvas.setTextColor(colGray(255));
    canvas.drawString(sbuf, 254, 63);
  }
}
