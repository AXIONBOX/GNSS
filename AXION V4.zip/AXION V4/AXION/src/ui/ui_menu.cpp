#include <Arduino.h>

#include "ui/ui_shared.h"

// Redéclaration minimale pour utiliser les infos de mode définies dans main.cpp
enum ModeID {
  MODE_MENU = 0,
  MODE_DASHBOARD = 1,
  MODE_GFORCES = 2,
  MODE_ACCEL = 3,
  MODE_DRAG = 4,
  MODE_LAP = 5,
  MODE_CRAWLING = 6,
  MODE_DRIFT = 7,
  MODE_COMPASS = 8,
  MODE_DIAGNOSTICS = 9,
  MODE_SETTINGS = 10,
  MODE_DYNO = 11,
  MODE_BENCH = 12,
  MODE_COUNT = 13
};

struct ModeInfo {
  const char* name;
  const char* fullName;
  const char* category;
  bool implemented;
};

extern ModeInfo gModes[MODE_COUNT];
extern int gCurrentMode;
extern int gMenuSelection;
extern int menu_prev_mode(int mode);
extern int menu_next_mode(int mode);
extern int menu_index_from_mode(int mode);

// Nombre d'entrées visibles dans le menu principal (ordre défini dans main.cpp)
static const int kMainMenuCountLocal = 9;

// Page UI : Menu principal (carrousel de tuiles)

void draw_menu(uint32_t frame)
{
  (void)frame;

  canvas.fillScreen(colGray(0));

  const int baseW   = 128;
  const int baseH   = 64;
  const int centerY = 32;
  const int spacing = -70;

  static float    scrollOffset = 0.0f;
  static int      lastSel      = gMenuSelection;
  static uint32_t zoomStart    = 0;
  static bool     zooming      = false;

  // Animation de scroll basée sur l'index logique dans le menu principal
  int currIdx = menu_index_from_mode(gMenuSelection);
  int lastIdx = menu_index_from_mode(lastSel);
  if (gMenuSelection != lastSel) {
    int delta = currIdx - lastIdx;
    if (delta >  (kMainMenuCountLocal / 2)) delta -= kMainMenuCountLocal;
    if (delta < -(kMainMenuCountLocal / 2)) delta += kMainMenuCountLocal;
    scrollOffset += (float)delta;
    lastSel   = gMenuSelection;
    zoomStart = millis();
    zooming   = true;
  }

  // Relaxation du scroll vers 0 (smooth)
  scrollOffset += 0.15f * (0.0f - scrollOffset);

  // Zoom léger sur la tuile active au changement
  float zoomScale = 1.0f;
  if (zooming) {
    uint32_t elapsed = millis() - zoomStart;
    if (elapsed < 200u) {
      float t = (float)elapsed / 200.0f;
      zoomScale = 1.0f + 0.1f * sinf(t * PI);
    } else {
      zooming = false;
    }
  }

  // Tramage de fond dans un rectangle arrondi
  auto fillTrammage = [&](int x0, int y0, int w, int h, int r, uint16_t colDot) {
    int x1 = x0 + w - 1;
    int y1 = y0 + h - 1;
    for (int yy = y0 + 1; yy < y1; ++yy) {
      int startX = ((yy & 1) ? 1 : 0) + x0 + 1;
      for (int xx = startX; xx < x1; xx += 2) {
        bool inside = true;
        if (xx < x0 + r && yy < y0 + r) {
          int dx = xx - (x0 + r);
          int dy = yy - (y0 + r);
          if (dx * dx + dy * dy > r * r) inside = false;
        }
        if (xx > x1 - r && yy < y0 + r) {
          int dx = xx - (x1 - r);
          int dy = yy - (y0 + r);
          if (dx * dx + dy * dy > r * r) inside = false;
        }
        if (xx < x0 + r && yy > y1 - r) {
          int dx = xx - (x0 + r);
          int dy = yy - (y1 - r);
          if (dx * dx + dy * dy > r * r) inside = false;
        }
        if (xx > x1 - r && yy > y1 - r) {
          int dx = xx - (x1 - r);
          int dy = yy - (y1 - r);
          if (dx * dx + dy * dy > r * r) inside = false;
        }
        if (inside) {
          canvas.drawPixel(xx, yy, colDot);
        }
      }
    }
  };

  // Dessine une tuile de menu pour un ModeID donné
  auto drawTile = [&](int mode,
                      int rel,
                      float scale,
                      uint8_t brightness,
                      uint16_t dotShade,
                      int offsetAdjust,
                      int verticalShift,
                      int extraH) {
    if (mode <= MODE_MENU || mode >= MODE_COUNT) return;

    float xOffset = (rel + scrollOffset) * (baseW + spacing) * offsetAdjust / 100.0f;
    int   xCenter = 128 + (int)xOffset;

    int tileW = (int)(baseW * scale);
    int tileH = (int)(baseH * scale * 0.85f) - extraH;
    int yPos  = centerY + verticalShift;
    int r     = 10;

    uint16_t fillCol   = colGray(18 + (int)(scale * 10));
    uint16_t borderCol = colGray(brightness - 50);

    canvas.fillRoundRect(xCenter - tileW / 2, yPos - tileH / 2,
                         tileW, tileH, r, fillCol);
    fillTrammage(xCenter - tileW / 2, yPos - tileH / 2,
                 tileW, tileH, r, dotShade);
    canvas.drawRoundRect(xCenter - tileW / 2, yPos - tileH / 2,
                         tileW, tileH, r, borderCol);

    canvas.setFont(&capitolcity10pt7b);
    canvas.setTextColor(colGray(brightness));

    const char* label = gModes[mode].name;
    if (abs(rel) == 1) {
      if (rel < 0) {
        canvas.setTextDatum(middle_left);
        int leftEdge = xCenter - tileW / 2;
        canvas.drawString(label, leftEdge + 3, yPos);
      } else {
        canvas.setTextDatum(middle_right);
        int rightEdge = xCenter + tileW / 2;
        canvas.drawString(label, rightEdge - 3, yPos);
      }
    } else {
      canvas.setTextDatum(middle_center);
      canvas.drawString(label, xCenter, yPos);
    }
  };

  // Calcule les modes voisins dans l'ordre principal
  int center = gMenuSelection;
  int left1  = menu_prev_mode(center);
  int left2  = menu_prev_mode(left1);
  int right1 = menu_next_mode(center);
  int right2 = menu_next_mode(right1);

  // Tuiles arrière-plan (±2)
  drawTile(left2,  -2, 0.80f, 90,  colGray(32), 100, +6, 5);
  drawTile(right2, +2, 0.80f, 90,  colGray(32), 100, +6, 5);

  // Voisins immédiats (±1)
  drawTile(left1,  -1, 0.93f, 150, colGray(38), 85,  +3, 0);
  drawTile(right1, +1, 0.93f, 150, colGray(38), 85,  +3, 0);

  // Tuile centrale (focus) avec ombre
  {
    float scale = 1.0f * zoomScale;
    int   tileW = (int)(baseW * scale);
    int   tileH = baseH - 1;
    int   xCenter = 128;
    int   yPos    = 31;
    int   r       = 12;

    uint16_t fillCol   = colGray(26);
    uint16_t borderCol = colGray(128);

    for (int s = 1; s <= 3; ++s) {
      uint16_t shadowCol = colGray(16 + s * 3);
      canvas.drawRoundRect(xCenter - tileW / 2, yPos - tileH / 2 + s,
                           tileW, tileH, r, shadowCol);
    }

    canvas.fillRoundRect(xCenter - tileW / 2, yPos - tileH / 2,
                         tileW, tileH, r, fillCol);
    fillTrammage(xCenter - tileW / 2, yPos - tileH / 2,
                 tileW, tileH, r, colGray(46));
    canvas.drawRoundRect(xCenter - tileW / 2, yPos - tileH / 2,
                         tileW, tileH, r, borderCol);

    canvas.setFont(&capitolcity10pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString(gModes[gMenuSelection].name, xCenter, yPos);
  }
}

