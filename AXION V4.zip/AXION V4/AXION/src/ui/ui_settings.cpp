#include <Arduino.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/diagnostics_engine.h"
#include "system/pins.h"

// Redéclaration minimale pour rester indépendante de main.cpp
enum ModeID {
  MODE_MENU = 0,
  MODE_DASHBOARD = 1,
  MODE_GFORCES = 2,
  MODE_ACCEL = 3,
  MODE_DRAG = 4,
  MODE_LAP = 5,
  MODE_CRAWLING = 6,
  MODE_DRIFT = 7,
  MODE_COMPASS = 8,
  MODE_DIAGNOSTICS = 9,
  MODE_SETTINGS = 10,
  MODE_DYNO = 11,
  MODE_BENCH = 12,
  MODE_COUNT = 13
};

extern int  gSettingsSelection;   // 0=Config,1=Diag,2=Bench,3=Prefs
extern bool gSettingsInConfig;    // true => affichage des pages Config (HC-05 / SD)

// --- Réutilisation des pages HC-05 / SD (copie de ui_diagnostics) ----------

struct DiagnosticsStatus;

static void draw_page_hc05_view(const DiagnosticsStatus& S);
static void draw_page_hc05_confirm(bool yesSelected);
static void draw_page_hc05_running(const DiagnosticsStatus& S);
static void draw_page_hc05_done(const DiagnosticsStatus& S, bool success);

static void draw_page_sd_setup_view(const DiagnosticsStatus& S);
static void draw_page_sd_setup_confirm(bool yesSelected);
static void draw_page_sd_setup_done(const DiagnosticsStatus& S, bool success);

// --- État interne Config (HC-05 / SD) --------------------------------------

static bool     s_cfgInited      = false;
static uint8_t  s_cfgPage        = 0;    // 0 = HC-05, 1 = SD
static uint8_t  s_cfgPrevBtns    = 0xFF;

static uint8_t  s_hcUiState      = 0;    // 0=view,1=confirm,2=running,3=done
static bool     s_hcConfirmYes   = true;
static uint32_t s_hcStartMs      = 0;
static bool     s_hcSuccess      = false;

static uint8_t  s_sdUiState      = 0;    // 0=view,1=confirm,2=done
static bool     s_sdConfirmYes   = true;
static bool     s_sdSuccess      = false;

// --- Vue Config (HC-05 + SD), appelé depuis Settings -----------------------

static void draw_settings_config(uint32_t frame)
{
  (void)frame;

  if (!s_cfgInited) {
    data_source_init(DataSourceMode::Real);
    diagnostics_engine_init();
    s_cfgInited   = true;
    s_cfgPage     = 0;
    s_cfgPrevBtns = 0xFF;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  diagnostics_engine_update(D, frame);

  const DiagnosticsStatus& S = diagnostics_engine_get_status();

  uint8_t vBtns = S.pcf_raw;
  bool leftNow   = ((vBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
  bool rightNow  = ((vBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
  bool selNow    = ((vBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;
  bool leftPrev  = ((s_cfgPrevBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
  bool rightPrev = ((s_cfgPrevBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
  bool selPrev   = ((s_cfgPrevBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;
  bool leftRelease  = (!leftNow  && leftPrev);
  bool rightRelease = (!rightNow && rightPrev);
  bool selRelease   = (!selNow   && selPrev);
  s_cfgPrevBtns = vBtns;

  // Navigation entre HC-05 et SD seulement quand aucune action en cours
  bool lockNav = (s_hcUiState != 0) || (s_sdUiState != 0);
  if (!lockNav) {
    if (leftRelease || rightRelease) {
      s_cfgPage = (uint8_t)((s_cfgPage + 1) % 2);
    }
  }

  canvas.fillScreen(colGray(0));

  if (s_cfgPage == 0) {
    // ---- HC-05 config ----
    uint32_t nowMs = millis();

    switch (s_hcUiState) {
      case 0: // view
        if (selRelease) {
          s_hcUiState    = 1;
          s_hcConfirmYes = true;
        }
        break;

      case 1: // confirm
        if (leftRelease || rightRelease) {
          s_hcConfirmYes = !s_hcConfirmYes;
        }
        if (selRelease) {
          if (s_hcConfirmYes) {
            diagnostics_engine_init(); // re-run full HC-05 + ELM setup
            s_hcUiState  = 2;
            s_hcStartMs  = nowMs;
            s_hcSuccess  = false;
          } else {
            s_hcUiState = 0;
          }
        }
        break;

      case 2: // running
        if (S.hc05_baud_detected == 115200 &&
            S.hc05_name[0] != '\0') {
          if (strncmp(S.hc05_name, "AXION_HC-05", 11) == 0) {
            s_hcSuccess = true;
          } else {
            s_hcSuccess = false;
          }
          s_hcUiState = 3;
        } else if ((int32_t)(nowMs - s_hcStartMs) > 10000) {
          s_hcSuccess = false;
          s_hcUiState = 3;
        }
        break;

      case 3: // done
        if (selRelease) {
          s_hcUiState = 0;
        }
        break;
    }

    if (s_hcUiState == 0) {
      draw_page_hc05_view(S);
    } else if (s_hcUiState == 1) {
      draw_page_hc05_confirm(s_hcConfirmYes);
    } else if (s_hcUiState == 2) {
      draw_page_hc05_running(S);
    } else {
      draw_page_hc05_done(S, s_hcSuccess);
    }
  } else {
    // ---- SD card config ----
    switch (s_sdUiState) {
      case 0: // view
        if (selRelease && S.sd_present && S.sd_ok) {
          s_sdUiState    = 1;
          s_sdConfirmYes = true;
        }
        break;

      case 1: // confirm
        if (leftRelease || rightRelease) {
          s_sdConfirmYes = !s_sdConfirmYes;
        }
        if (selRelease) {
          if (s_sdConfirmYes) {
            s_sdSuccess = diagnostics_engine_sd_prepare(true);
            s_sdUiState = 2;
          } else {
            s_sdUiState = 0;
          }
        }
        break;

      case 2: // done
        if (selRelease) {
          s_sdUiState = 0;
        }
        break;
    }

    if (s_sdUiState == 0) {
      draw_page_sd_setup_view(S);
    } else if (s_sdUiState == 1) {
      draw_page_sd_setup_confirm(s_sdConfirmYes);
    } else {
      draw_page_sd_setup_done(S, s_sdSuccess);
    }
  }
}

// --- Vue tuiles Settings ---------------------------------------------------

static void draw_settings_tiles()
{
  canvas.fillScreen(colGray(0));

  const char* labels[4] = {"Config", "Diag", "Bench", "Prefs"};

  int centerIndex = gSettingsSelection;
  if (centerIndex < 0) centerIndex = 0;
  if (centerIndex > 3) centerIndex = 3;

  int xCenters[4] = {48, 104, 160, 216};

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(180));
  canvas.setTextDatum(top_left);
  canvas.drawString("Settings", 2, 1);

  for (int i = 0; i < 4; ++i) {
    int xCenter = xCenters[i];
    int yCenter = 30;
    int w = 70;
    int h = 26;
    int r = 6;

    bool selected = (i == centerIndex);

    uint16_t fillCol   = colGray(20);
    uint16_t borderCol = colGray(100);
    uint16_t textCol   = colGray(180);

    canvas.fillRoundRect(xCenter - w/2, yCenter - h/2, w, h, r, fillCol);
    canvas.drawRoundRect(xCenter - w/2, yCenter - h/2, w, h, r, borderCol);

    canvas.setFont(&capitolcity10pt7b);
    canvas.setTextColor(textCol);
    canvas.setTextDatum(middle_center);
    canvas.drawString(labels[i], xCenter, yCenter);

    if (selected) {
      int hw = w + 4;
      int hh = h + 4;
      int sr = r + 2;
      uint16_t selFill   = colGray(32);
      uint16_t selBorder = colGray(220);
      uint16_t selText   = colGray(255);

      canvas.fillRoundRect(xCenter - hw/2, yCenter - hh/2, hw, hh, sr, selFill);
      canvas.drawRoundRect(xCenter - hw/2, yCenter - hh/2, hw, hh, sr, selBorder);

      canvas.setFont(&capitolcity10pt7b);
      canvas.setTextColor(selText);
      canvas.setTextDatum(middle_center);
      canvas.drawString(labels[i], xCenter, yCenter);
    }
  }

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(140));
  canvas.setTextDatum(bottom_left);
  canvas.drawString("LEFT/RIGHT: select  SELECT: enter", 2, 63);
}

// --- Entrée principale Settings --------------------------------------------

void draw_settings(uint32_t frame)
{
  if (gSettingsInConfig) {
    draw_settings_config(frame);
  } else {
    draw_settings_tiles();
  }
}

// --- Copie des pages HC-05 / SD depuis ui_diagnostics ----------------------

static void draw_page_hc05_view(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  char buf[64];
  canvas.setTextColor(colGray(180));

  const char* status = "SCAN";
  if (S.hc05_ok && S.hc05_baud_detected != 0) status = "OK";
  else if (!S.hc05_ok && S.hc05_baud_detected != 0) status = "FAIL";

  snprintf(buf, sizeof(buf), "detected: %lu baud (%s)",
           (unsigned long)S.hc05_baud_detected, status);
  canvas.drawString(buf, 2, 14);

  canvas.setTextColor(colGray(160));
  snprintf(buf, sizeof(buf), "name: %s", S.hc05_name[0] ? S.hc05_name : "(n/a)");
  canvas.drawString(buf, 2, 23);
  snprintf(buf, sizeof(buf), "addr: %s", S.hc05_addr[0] ? S.hc05_addr : "(n/a)");
  canvas.drawString(buf, 2, 32);
  snprintf(buf, sizeof(buf), "ver:  %s", S.hc05_version[0] ? S.hc05_version : "(n/a)");
  canvas.drawString(buf, 2, 41);

  canvas.setTextColor(colGray(120));
  canvas.drawString("SELECT: setup HC-05 for AXION", 2, 63-8);
}

static void draw_page_hc05_confirm(bool yesSelected)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  canvas.setTextColor(colGray(220));
  canvas.drawString("Configure HC-05 for AXION?", 2, 20);

  canvas.setTextColor(colGray(180));
  canvas.drawString("Baud: 115200, NAME: AXION_HC-05", 2, 30);

  canvas.setTextColor(colGray(200));
  const int y = 44;
  if (yesSelected) {
    canvas.drawString("[YES]  no", 2, y);
  } else {
    canvas.drawString(" yes  [NO]", 2, y);
  }

  canvas.setTextColor(colGray(120));
  canvas.drawString("LEFT/RIGHT: select   SELECT: confirm", 2, 56);
}

static void draw_page_hc05_running(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  canvas.setTextColor(colGray(220));
  canvas.drawString("Configuring HC-05 for AXION...", 2, 18);

  canvas.setTextColor(colGray(160));
  char buf[64];
  snprintf(buf, sizeof(buf), "baud: %lu", (unsigned long)S.hc05_baud_detected);
  canvas.drawString(buf, 2, 30);
  snprintf(buf, sizeof(buf), "name: %s", S.hc05_name[0] ? S.hc05_name : "(pending)");
  canvas.drawString(buf, 2, 39);
  snprintf(buf, sizeof(buf), "status: %s", S.hc05_ok ? "OK" : "working...");
  canvas.drawString(buf, 2, 48);
}

static void draw_page_hc05_done(const DiagnosticsStatus& S, bool success)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("HC-05 config", 2, 1);

  canvas.setTextColor(success ? colGray(220) : colGray(140));
  canvas.setTextDatum(top_right);
  canvas.drawString(success ? "Setup SUCCESS" : "Setup FAILED", 255, 1);
  canvas.setTextDatum(top_left);

  canvas.setTextColor(colGray(160));
  char buf[64];
  snprintf(buf, sizeof(buf), "baud: %lu", (unsigned long)S.hc05_baud_detected);
  canvas.drawString(buf, 2, 14);
  snprintf(buf, sizeof(buf), "name: %s", S.hc05_name[0] ? S.hc05_name : "(n/a)");
  canvas.drawString(buf, 2, 23);
  snprintf(buf, sizeof(buf), "addr: %s", S.hc05_addr[0] ? S.hc05_addr : "(n/a)");
  canvas.drawString(buf, 2, 32);

  canvas.setTextColor(colGray(120));
  canvas.drawString("SELECT: back", 2, 56);
}

static void draw_page_sd_setup_view(const DiagnosticsStatus& S)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("SD card config", 2, 1);

  canvas.setTextColor(colGray(180));
  int y = 14;

  if (!S.sd_present) {
    canvas.drawString("Aucune carte SD detectee.", 2, y);
    y += 9;
    canvas.setTextColor(colGray(160));
    canvas.drawString("Inserer une carte SD pour", 2, y);
    y += 9;
    canvas.drawString("utiliser l'enregistrement AXION.", 2, y);
  } else if (S.sd_present && !S.sd_ok) {
    canvas.drawString("Carte SD presente, mais erreur.", 2, y);
    y += 9;
    canvas.setTextColor(colGray(160));
    canvas.drawString("Verifier la carte / format FAT.", 2, y);
  } else {
    char buf[64];

    uint64_t totalMb = S.sd_total_bytes / (1024u * 1024u);
    uint64_t usedMb  = S.sd_used_bytes  / (1024u * 1024u);
    if (totalMb == 0 && S.sd_total_bytes > 0) totalMb = 1;

    snprintf(buf, sizeof(buf), "carte: %llu MB  util:%llu MB",
             (unsigned long long)totalMb,
             (unsigned long long)usedMb);
    canvas.drawString(buf, 2, y);
    y += 9;

    canvas.setTextColor(colGray(160));
    const char* fsStatus = S.fs_ok ? "READY" : "NON PRET";
    snprintf(buf, sizeof(buf), "FS AXION (/AXION): %s", fsStatus);
    canvas.drawString(buf, 2, y);
    y += 9;

    if (!S.fs_ok) {
      canvas.drawString("SELECT: preparer /AXION (efface", 2, y);
      y += 9;
      canvas.drawString("uniquement le dossier /AXION)", 2, y);
    } else {
      canvas.drawString("SELECT: re-preparer FS AXION", 2, y);
    }
  }
}

static void draw_page_sd_setup_confirm(bool yesSelected)
{
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("SD card config", 2, 1);

  canvas.setTextColor(colGray(220));
  canvas.drawString("Clear all data and", 2, 20);
  canvas.drawString("Prepare SD card for AXION?", 2, 29);

  canvas.setTextColor(colGray(200));
  const int y = 40;
  if (yesSelected) {
    canvas.drawString("[YES]  no", 2, y);
  } else {
    canvas.drawString(" yes  [NO]", 2, y);
  }

  canvas.setTextColor(colGray(120));
  canvas.drawString("LEFT/RIGHT: select   SELECT: confirm", 2, 63-8);
}

static void draw_page_sd_setup_done(const DiagnosticsStatus& S, bool success)
{
  (void)S;
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(200));
  canvas.setTextDatum(top_left);
  canvas.drawString("SD card config", 2, 1);

  canvas.setTextColor(success ? colGray(220) : colGray(140));
  canvas.setTextDatum(top_right);
  canvas.drawString(success ? "Setup SUCCESS" : "Setup FAILED", 255, 1);
  canvas.setTextDatum(top_left);

  canvas.setTextColor(colGray(160));
  if (success) {
    canvas.drawString("/AXION pret pour AXION.", 2, 20);
  } else {
    canvas.drawString("Erreur pendant la preparation.", 2, 20);
    canvas.drawString("Verifier la carte SD.", 2, 29);
  }

  canvas.setTextColor(colGray(120));
  canvas.drawString("SELECT: back", 2, 56);
}
