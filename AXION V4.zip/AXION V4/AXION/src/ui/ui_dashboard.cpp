﻿#include <Arduino.h>

#include "ui/ui_shared.h"
#include "data/data_source.h"
#include "logic_modes/dashboard_engine.h"

// Page UI : Dashboard+

void draw_dashboard(uint32_t frame)
{
  static bool s_inited = false;
  if (!s_inited) {
    data_source_init(DataSourceMode::Real);
    dashboard_engine_init();
    s_inited = true;
  }

  data_source_update();
  AxionData D{};
  data_source_snapshot(D);
  dashboard_engine_update(D, frame);

  float throttle = dashboard_engine_get_throttle();
  float lat      = dashboard_engine_get_lat_g();
  int   engineTemp = dashboard_engine_get_engine_temp_c();
  int   speedInt   = dashboard_engine_get_speed_kmh();
  int   rpm        = dashboard_engine_get_rpm();

  canvas.fillScreen(canvas.color565(0, 0, 0));

  canvas.fillRoundRect(74, 0, 108, 63, 10, canvas.color565(0, 0, 0));
  canvas.drawRoundRect(74, 0, 108, 63, 10, colGray(64));
  const int rcx = 75, rcy = 1, rcw = 106, rch = 62, rr = 9;
  const uint16_t dotCol = colGray(40);
  for (int yy = rcy; yy < rcy + rch; ++yy) {
    int startX = rcx + ((yy - rcy) & 1);
    int endX = rcx + rcw - 1;
    for (int xx = startX; xx <= endX; xx += 2) {
      int x2 = rcx + rcw - 1;
      int y2 = rcy + rch - 1;
      bool inside = true;
      if (xx < rcx || xx > x2 || yy < rcy || yy > y2) inside = false;
      if (inside) {
        bool straight = ((xx >= rcx + rr && xx <= x2 - rr) || (yy >= rcy + rr && yy <= y2 - rr));
        if (!straight) {
          int cx = (xx < rcx + rr) ? rcx + rr : x2 - rr;
          int cy = (yy < rcy + rr) ? rcy + rr : y2 - rr;
          int dx = xx - cx; int dy = yy - cy;
          inside = (dx*dx + dy*dy) <= rr*rr;
        }
      }
      if (inside) canvas.drawPixel(xx, yy, dotCol);
    }
  }

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(top_left);
  canvas.drawString("dashboard", 2, 1);

  canvas.setTextDatum(top_left);
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(canvas.color565(153, 153, 153));
  canvas.drawString("LAT G", 5, 17);

  int gaugeX = 5, gaugeY = 28, gaugeW = 65, gaugeH = 6;
  canvas.fillRect(gaugeX, gaugeY, gaugeW, gaugeH, canvas.color565(34, 34, 34));
  {
    int mid = gaugeX + gaugeW/2;
    int cw = (int)((lat/1.5f) * (gaugeW/2));
    if (cw>=0) canvas.fillRect(mid, gaugeY, cw, gaugeH, canvas.color565(255,255,255));
    else       canvas.fillRect(mid+cw, gaugeY, -cw, gaugeH, canvas.color565(255,255,255));
    canvas.drawRect(gaugeX, gaugeY, gaugeW, gaugeH, canvas.color565(34, 34, 34));
  }
  canvas.drawFastHLine(5, 41, 65, canvas.color565(68, 68, 68));
  canvas.setTextColor(canvas.color565(153, 153, 153));
  canvas.drawString("ENGINE", 5, 44);

  canvas.setTextColor(canvas.color565(255, 255, 255));
  canvas.setFont(&fonts::Font2);
  char tempStr[8]; snprintf(tempStr, sizeof(tempStr), "%d", engineTemp);
  canvas.drawString(tempStr, 5, 50);
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(canvas.color565(136, 136, 136));
  int tempWidth = canvas.textWidth(tempStr, &fonts::Font2);
  canvas.drawString("C", 5 + tempWidth + 2, 52);

  {
    int vx = 186, vy = 12, vw = 8, vh = 52;
    int vval = (int)(vh * constrain(throttle/100.0f, 0.0f, 1.0f));
    canvas.fillRect(vx, vy, vw, vh, canvas.color565(34,34,34));
    if (vval > 0) canvas.fillRect(vx+1, vy + (vh - vval), vw-2, vval, canvas.color565(255,255,255));
    canvas.drawRect(vx, vy, vw, vh, canvas.color565(34,34,34));
    canvas.setTextDatum(top_left);
    canvas.setTextColor(canvas.color565(153,153,153));
    canvas.drawString("THR", vx-2, vy-9);
  }

  canvas.setTextColor(canvas.color565(255, 255, 255));
  bool highSpeed = (speedInt >= 200);
  canvas.setFont(highSpeed ? &Race_Sport24pt7b : &Race_Sport26pt7b);
  int hundreds = speedInt / 100;
  int tens     = (speedInt / 10) % 10;
  int ones     = speedInt % 10;
  int wDigit   = highSpeed ? 20 : 22;
  int spacing  = 15;
  int centerX  = highSpeed ? 121 : 114;
  auto offsetIfOne = [](int digit, bool alignRight) {
    if (digit == 1) return alignRight ? 18 : -4;
    return 0;
  };
  int xTens = centerX - (wDigit / 2);
  int baselineRef = 56;
  int fontH = canvas.fontHeight();
  int drawY = baselineRef - fontH;
  if (hundreds > 0) {
    char c[2] = { (char)('0' + hundreds), '\0' };
    int adj = offsetIfOne(hundreds, true);
    canvas.drawString(c, xTens - (wDigit + spacing) + adj, drawY);
  }
  {
    char cT[2] = { (char)('0' + tens), '\0' };
    int adjT = offsetIfOne(tens, true);
    canvas.drawString(cT, xTens + adjT, drawY);
  }
  {
    char cO[2] = { (char)('0' + ones), '\0' };
    int adjO = offsetIfOne(ones, false);
    if (ones == 1) adjO += 6;
    canvas.drawString(cO, xTens + (wDigit + spacing) + adjO, drawY);
  }

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(canvas.color565(136,136,136));
  canvas.setTextDatum(bottom_right);
  int unitX = 180 - 7;
  int unitY = (63 - 6) + 10 - 6;
  canvas.drawString("km/h", unitX, unitY);

  int16_t cx = 226, cy = 36, radius = 27;
  canvas.fillCircle(cx, cy, radius - 2, canvas.color565(17, 17, 17));
  for (int i = 0; i <= 8; i++) {
    float angle = 90.0f + (i * 33.75f);
    int16_t x1 = (int16_t)(cx + cosf(angle * DEG_TO_RAD) * (radius - 5));
    int16_t y1 = (int16_t)(cy + sinf(angle * DEG_TO_RAD) * (radius - 5));
    int16_t x2 = (int16_t)(cx + cosf(angle * DEG_TO_RAD) * (radius - 1));
    int16_t y2 = (int16_t)(cy + sinf(angle * DEG_TO_RAD) * (radius - 1));
    canvas.drawLine(x1, y1, x2, y2, colGray(24));
  }
  int redStartAngle = (int)(90 + (7000.0f / 8000.0f * 270.0f));
  for (float a = 90.0f; a <= 360.0f; a += 0.5f) {
    float ar = a * DEG_TO_RAD;
    int16_t x = (int16_t)(cx + cosf(ar) * (radius));
    int16_t y = (int16_t)(cy + sinf(ar) * (radius));
    canvas.drawPixel(x, y, colGray(96));
  }
  int startAngle = redStartAngle; if (startAngle < 90) startAngle = 90;
  for (float af = (float)startAngle; af <= 360.0f; af += 0.5f) {
    float ar = af * DEG_TO_RAD;
    for (int k = 0; k < 5; ++k) {
      int16_t xr = (int16_t)(cx + cosf(ar) * (radius - k));
      int16_t yr = (int16_t)(cy + sinf(ar) * (radius - k));
      canvas.drawPixel(xr, yr, colGray(16));
    }
  }
  float rpmNormalized = constrain(rpm, 0, 8000) / 8000.0f;
  float targetAngleF = 90.0f + (rpmNormalized * 270.0f);
  {
    int a0 = 90;
    int a1 = (int)targetAngleF;
    if (a1 < a0) a1 = a0;
    int limit1 = a1;
    if (limit1 >= redStartAngle) limit1 = redStartAngle - 1;
    for (int a = a0; a <= limit1; ++a) {
      float ar = a * DEG_TO_RAD;
      int16_t xr1 = (int16_t)(cx + cosf(ar) * (radius));
      int16_t yr1 = (int16_t)(cy + sinf(ar) * (radius));
      int16_t xr2 = (int16_t)(cx + cosf(ar) * (radius-1));
      int16_t yr2 = (int16_t)(cy + sinf(ar) * (radius-1));
      int16_t xr3 = (int16_t)(cx + cosf(ar) * (radius-2));
      int16_t yr3 = (int16_t)(cy + sinf(ar) * (radius-2));
      uint16_t arcCol = colGray(255);
      canvas.drawPixel(xr1, yr1, arcCol);
      canvas.drawPixel(xr2, yr2, arcCol);
      canvas.drawPixel(xr3, yr3, arcCol);
    }
  }
  for (int angle = redStartAngle; angle <= 360; angle += 2) {
    float ar = angle * DEG_TO_RAD;
    int16_t x0 = (int16_t)(cx + cosf(ar) * radius);
    int16_t y0 = (int16_t)(cy + sinf(ar) * radius);
    int16_t x1 = (int16_t)(cx + cosf(ar) * (radius-1));
    int16_t y1 = (int16_t)(cy + sinf(ar) * (radius-1));
    int16_t x2 = (int16_t)(cx + cosf(ar) * (radius-2));
    int16_t y2 = (int16_t)(cy + sinf(ar) * (radius-2));
    uint16_t g = canvas.color565(68, 68, 68);
    canvas.drawPixel(x0, y0, g);
    canvas.drawPixel(x1, y1, g);
    canvas.drawPixel(x2, y2, g);
  }
  {
    int a1 = (int)targetAngleF;
    if (a1 >= redStartAngle) {
      bool blinkOn = ((millis() / 200) & 1) == 0;
      if (blinkOn) {
        for (int a = redStartAngle; a <= a1; ++a) {
          float ar = a * DEG_TO_RAD;
          int16_t xr1 = (int16_t)(cx + cosf(ar) * (radius));
          int16_t yr1 = (int16_t)(cy + sinf(ar) * (radius));
          int16_t xr2 = (int16_t)(cx + cosf(ar) * (radius-1));
          int16_t yr2 = (int16_t)(cy + sinf(ar) * (radius-1));
          int16_t xr3 = (int16_t)(cx + cosf(ar) * (radius-2));
          int16_t yr3 = (int16_t)(cy + sinf(ar) * (radius-2));
          uint16_t arcCol = colGray(255);
          canvas.drawPixel(xr1, yr1, arcCol);
          canvas.drawPixel(xr2, yr2, arcCol);
          canvas.drawPixel(xr3, yr3, arcCol);
        }
      }
    }
  }
  {
    int16_t needleX = (int16_t)(cx + cosf(targetAngleF * DEG_TO_RAD) * (radius - 2));
    int16_t needleY = (int16_t)(cy + sinf(targetAngleF * DEG_TO_RAD) * (radius - 2));
    canvas.drawLine(cx, cy, needleX, needleY, canvas.color565(255, 255, 255));
    canvas.drawLine(cx - 1, cy, needleX - 1, needleY, canvas.color565(255, 255, 255));
    canvas.fillCircle(cx, cy, 3, canvas.color565(255, 255, 255));
    canvas.fillCircle(cx, cy, 1, canvas.color565(34, 34, 34));
  }

  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(canvas.color565(153, 153, 153));
  canvas.setTextDatum(middle_center);
  canvas.drawString("RPM", cx + 1, cy - 10);
  canvas.setTextColor(canvas.color565(255, 255, 255));
  canvas.setFont(&fonts::Font2);
  canvas.setTextDatum(top_right);
  char rpmStr[12]; snprintf(rpmStr, sizeof(rpmStr), "%d", rpm);
  canvas.drawString(rpmStr, 256, 41);
}
