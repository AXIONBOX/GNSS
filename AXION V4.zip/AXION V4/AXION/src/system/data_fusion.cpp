#include <Arduino.h>

#include "data_fusion.h"
#include "system/timebase.h"
#include "system/gnss.h"
#include "system/imu.h"
#include "system/obd.h"

namespace {

  AxionData s_latest{};
  bool      s_haveData      = false;
  uint32_t  s_lastFusionUs  = 0;
  const uint32_t kFusionPeriodUs = 40000u; // ~25 Hz

} // namespace

void data_fusion_init()
{
  timebase_init();
  AXION_GNSS.begin();
  imu_begin();

  s_latest       = AxionData{};
  s_haveData     = false;
  s_lastFusionUs = (uint32_t)(timebase_now_us() & 0xFFFFFFFFu);
}

void data_fusion_update()
{
  AXION_GNSS.update();
  imu_update();

  uint32_t nowUs = (uint32_t)(timebase_now_us() & 0xFFFFFFFFu);
  int32_t  dt    = (int32_t)(nowUs - s_lastFusionUs);
  if (dt < 0 || (uint32_t)dt < kFusionPeriodUs) {
    return;
  }

  s_lastFusionUs = nowUs;

  AxionData D{};
  D.timestamp_us = nowUs;

  GnssFix fix{};
  AXION_GNSS.getFix(fix);
  if (fix.valid) {
    D.lat          = fix.lat;
    D.lon          = fix.lon;
    D.alt          = fix.alt;
    D.sats         = fix.sats;
    D.hdop         = fix.hdop;
    D.fix_quality  = fix.fix_quality;
    D.speed_kmh    = fix.speed_kmh;
    D.heading_deg  = fix.heading_deg;
    D.gnss_valid   = true;
  } else {
    D.gnss_valid   = false;
  }

  ImuSample imu{};
  imu_get_latest(imu);
  if (imu.valid) {
    D.accel_g[0] = imu.accel_g[0];
    D.accel_g[1] = imu.accel_g[1];
    D.accel_g[2] = imu.accel_g[2];
    D.gyro_deg[0] = imu.gyro_deg[0];
    D.gyro_deg[1] = imu.gyro_deg[1];
    D.gyro_deg[2] = imu.gyro_deg[2];
    D.imu_valid   = true;
  } else {
    D.imu_valid   = false;
  }

  // Intégration OBD : RPM / throttle / coolant (speed OBD utilisé uniquement au besoin).
  OBDStatus obd{};
  obd_get_latest(obd);
  if (obd.vehicle_present) {
    D.obd_valid = true;
    if (obd.has_rpm) {
      D.rpm = obd.rpm;
    }
    if (obd.has_throttle) {
      D.throttle = obd.throttle_pct;
    }
    if (obd.has_coolant_temp) {
      D.coolant_temp_c = obd.coolant_temp_c;
    }
    // On peut utiliser la vitesse OBD comme back-up si besoin,
    // mais on garde pour l'instant speed_kmh basé GNSS.
  } else {
    D.obd_valid = false;
  }

  s_latest   = D;
  s_haveData = true;
}

void data_fusion_snapshot(AxionData& out)
{
  if (!s_haveData) {
    out = AxionData{};
  } else {
    out = s_latest;
  }
}
