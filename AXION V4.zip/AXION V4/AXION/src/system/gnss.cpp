#include <Arduino.h>

#include "system/gnss.h"
#include "system/pins.h"
#include "system/timebase.h"

AxionGnss AXION_GNSS;

namespace {

  HardwareSerial& gnssSerial = Serial2;

  bool parse_lat_lon(const char* latStr, const char* nsStr,
                     const char* lonStr, const char* ewStr,
                     float& latDeg, float& lonDeg)
  {
    if (!latStr || !lonStr || !latStr[0] || !lonStr[0]) return false;

    double latVal = atof(latStr);
    double lonVal = atof(lonStr);

    int latDegInt = (int)(latVal / 100.0);
    double latMin = latVal - latDegInt * 100.0;
    double latD   = latDegInt + latMin / 60.0;

    int lonDegInt = (int)(lonVal / 100.0);
    double lonMin = lonVal - lonDegInt * 100.0;
    double lonD   = lonDegInt + lonMin / 60.0;

    if (nsStr && (*nsStr == 'S' || *nsStr == 's')) latD = -latD;
    if (ewStr && (*ewStr == 'W' || *ewStr == 'w')) lonD = -lonD;

    latDeg = (float)latD;
    lonDeg = (float)lonD;
    return true;
  }

} // namespace

bool AxionGnss::begin()
{
  if (m_started) return true;

  gnssSerial.begin(115200, SERIAL_8N1, PIN_GNSS_RX, PIN_GNSS_TX);
  gnssSerial.flush();
  // Par défaut : cadence GNSS 20 Hz (mode nominal AXION).
  m_rateMode = GnssRateMode::Rate20Hz;
  applyRateConfig();
  m_started   = true;
  m_lineLen   = 0;
  m_lastFix   = GnssFix{};
  m_speedSmooth   = 0.0f;
  m_headingSmooth = 0.0f;
  return true;
}

void AxionGnss::update()
{
  if (!m_started) return;

  while (gnssSerial.available() > 0) {
    int c = gnssSerial.read();
    if (c < 0) break;
    handleChar((char)c);
  }
}

void AxionGnss::handleChar(char c)
{
  if (c == '\r') {
    return;
  }

  if (c == '\n') {
    if (m_lineLen > 0) {
      m_lineBuf[m_lineLen] = '\0';
      parseSentence(m_lineBuf);
    }
    m_lineLen = 0;
    return;
  }

  if (m_lineLen == 0 && c != '$') {
    return;
  }

  if (m_lineLen < kLineBufSize - 1) {
    m_lineBuf[m_lineLen++] = c;
  } else {
    m_lineLen = 0;
  }
}

void AxionGnss::parseSentence(char* sentence)
{
  if (sentence[0] != '$') return;

  if (strncmp(sentence + 3, "GGA", 3) == 0) {
    parseGGA(sentence);
  } else if (strncmp(sentence + 3, "RMC", 3) == 0) {
    parseRMC(sentence);
  }
}

void AxionGnss::parseGGA(char* sentence)
{
  char* saveptr = nullptr;
  char* token   = strtok_r(sentence, ",", &saveptr);

  int field = 0;
  const char* timeStr = nullptr;
  const char* latStr  = nullptr;
  const char* nsStr   = nullptr;
  const char* lonStr  = nullptr;
  const char* ewStr   = nullptr;
  int   fixQuality    = 0;
  int   numSats       = 0;
  float hdop          = 0.0f;
  float alt           = 0.0f;

  while (token) {
    switch (field) {
      case 1: timeStr = token; break;
      case 2: latStr  = token; break;
      case 3: nsStr   = token; break;
      case 4: lonStr  = token; break;
      case 5: ewStr   = token; break;
      case 6: fixQuality = atoi(token); break;
      case 7: numSats    = atoi(token); break;
      case 8: hdop       = (float)atof(token); break;
      case 9: alt        = (float)atof(token); break;
    }
    token = strtok_r(nullptr, ",", &saveptr);
    ++field;
  }

  float latDeg = 0.0f;
  float lonDeg = 0.0f;
  if (!parse_lat_lon(latStr, nsStr, lonStr, ewStr, latDeg, lonDeg)) {
    return;
  }

  GnssFix fix = m_lastFix;
  fix.lat         = latDeg;
  fix.lon         = lonDeg;
  fix.alt         = alt;
  fix.fix_quality = (uint8_t)fixQuality;
  fix.sats        = (uint8_t)numSats;
  fix.hdop        = hdop;
  fix.valid       = true;

  uint64_t nowUs64 = timebase_now_us();
  fix.timestamp_us = (uint32_t)(nowUs64 & 0xFFFFFFFFu);

  bool goodFix = (fix.fix_quality >= 1 && fix.sats >= 4 && fix.hdop > 0.0f && fix.hdop < 3.0f);
  fix.has_fix = goodFix;

  m_lastFix = fix;
}

void AxionGnss::parseRMC(char* sentence)
{
  char* saveptr = nullptr;
  char* token   = strtok_r(sentence, ",", &saveptr);

  int field = 0;
  const char* statusStr = nullptr;
  const char* latStr    = nullptr;
  const char* nsStr     = nullptr;
  const char* lonStr    = nullptr;
  const char* ewStr     = nullptr;
  float speedKnots      = 0.0f;
  float courseDeg       = 0.0f;

  while (token) {
    switch (field) {
      case 2: statusStr  = token; break;
      case 3: latStr     = token; break;
      case 4: nsStr      = token; break;
      case 5: lonStr     = token; break;
      case 6: ewStr      = token; break;
      case 7: speedKnots = (float)atof(token); break;
      case 8: courseDeg  = (float)atof(token); break;
    }
    token = strtok_r(nullptr, ",", &saveptr);
    ++field;
  }

  if (!statusStr || (*statusStr != 'A' && *statusStr != 'a')) {
    return;
  }

  float latDeg = 0.0f;
  float lonDeg = 0.0f;
  bool haveLatLon = parse_lat_lon(latStr, nsStr, lonStr, ewStr, latDeg, lonDeg);

  float speedKmh = speedKnots * 1.852f;
  float heading  = courseDeg;

  const float alpha = 0.25f;
  if (speedKmh >= 0.2f) {
    m_speedSmooth += alpha * (speedKmh - m_speedSmooth);
  } else {
    m_speedSmooth = speedKmh;
  }

  float hPrev = m_headingSmooth;
  float diff  = heading - hPrev;
  while (diff > 180.0f) diff -= 360.0f;
  while (diff < -180.0f) diff += 360.0f;
  m_headingSmooth = hPrev + alpha * diff;
  if (m_headingSmooth < 0.0f)   m_headingSmooth += 360.0f;
  if (m_headingSmooth >= 360.0f) m_headingSmooth -= 360.0f;

  GnssFix fix = m_lastFix;
  if (haveLatLon) {
    fix.lat = latDeg;
    fix.lon = lonDeg;
  }
  fix.speed_kmh   = m_speedSmooth;
  fix.heading_deg = m_headingSmooth;
  fix.valid       = true;

  uint64_t nowUs64 = timebase_now_us();
  fix.timestamp_us = (uint32_t)(nowUs64 & 0xFFFFFFFFu);

  bool goodFix = fix.has_fix || (fix.sats >= 4 && fix.hdop > 0.0f && fix.hdop < 3.0f);
  fix.has_fix = goodFix;

  m_lastFix = fix;
}

void AxionGnss::getFix(GnssFix& out) const
{
  out = m_lastFix;
}

bool AxionGnss::hasFix() const
{
  return m_lastFix.has_fix;
}

void AxionGnss::setRateMode(GnssRateMode mode)
{
  m_rateMode = mode;
  if (m_started) {
    applyRateConfig();
  }
}

void AxionGnss::applyRateConfig()
{
  // TODO: envoyer ici les commandes de configuration spécifiques
  // au Quectel LC29H-EA pour fixer la cadence NMEA à:
  //  - 20 Hz quand m_rateMode == GnssRateMode::Rate20Hz
  //  - 25 Hz quand m_rateMode == GnssRateMode::Rate25Hz (mode test futur)
  //
  // Exemple d'emplacement:
  //   const char* cmd20 = "...";
  //   gnssSerial.print(cmd20);
  //
  // Pour l'instant, on suppose que le module est déjà configuré à 20 Hz
  // ou qu'il tourne à une cadence compatible; le logger reste fixé à 25 Hz
  // côté data_fusion.
}
