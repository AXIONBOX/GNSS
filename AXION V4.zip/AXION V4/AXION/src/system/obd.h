#pragma once

#include <stdint.h>

// Statut OBD2/ELM327 courant, maintenu par la task Core 0.
struct OBDStatus {
  bool     vehicle_present   = false;
  bool     has_rpm           = false;
  bool     has_speed         = false;
  bool     has_throttle      = false;
  bool     has_coolant_temp  = false;

  float    rpm               = 0.0f;
  float    speed_kmh         = 0.0f;
  float    throttle_pct      = 0.0f;    // 0..100
  float    coolant_temp_c    = 0.0f;

  // Timestamp interne (us) dans la timebase commune.
  uint32_t timestamp_us      = 0;
};

// Initialisation du lien HC-05 -> ELM327 (UART1).
void obd_init();

// Avance la machine d'état OBD2 de manière non bloquante.
// À appeler fréquemment depuis Core 0 (task_data_core).
void obd_update();

// Snapshot atomique du dernier statut OBD connu.
void obd_get_latest(OBDStatus& out);

