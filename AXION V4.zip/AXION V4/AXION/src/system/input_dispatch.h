#pragma once

#include <stdint.h>

// Identifiants logiques de boutons.
enum class ButtonID : uint8_t {
  Left,
  Right,
  Select
};

struct InputState {
  // États instantanés (après inversion active-LOW).
  bool left_pressed   = false;
  bool right_pressed  = false;
  bool select_pressed = false;

  // Événements sur ce tick.
  bool left_edge_press    = false;
  bool right_edge_press   = false;
  bool select_edge_press  = false;
  bool left_release       = false;
  bool right_release      = false;
  bool select_release     = false;

  // Auto-repeat.
  bool left_repeat        = false;
  bool right_repeat       = false;

  // Long press / combos.
  bool select_long_to_menu = false;
  bool both_lr_long        = false;

  // Triple hold (L+R+SEL > 1500 ms).
  bool triple_reinit_event = false;
};

void input_init();
void input_update();
void input_get_snapshot(InputState& out);

