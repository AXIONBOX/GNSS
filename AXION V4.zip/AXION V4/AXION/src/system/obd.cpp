#include <Arduino.h>

#include "system/obd.h"
#include "system/pins.h"
#include "system/timebase.h"

// Pipeline OBD2 minimal non bloquant basé sur HC-05 + ELM327.
// Hypothèse: HC-05 déjà configuré à 115200 bauds via les outils
// Diagnostics/Settings (HC-05 config).

namespace {

  HardwareSerial s_btSerial(1);

  enum class ObdState : uint8_t {
    NotStarted = 0,
    SendReset,
    WaitReset,
    SendInit,
    Idle,
    WaitResponse,
  };

  ObdState  s_state          = ObdState::NotStarted;
  uint32_t  s_stateDeadline  = 0;
  uint8_t   s_pidIndex       = 0;   // 0=RPM,1=Coolant,2=Throttle,3=Speed

  char      s_buf[192];
  size_t    s_len            = 0;

  OBDStatus s_latest{};

  void buf_clear()
  {
    s_len = 0;
    s_buf[0] = '\0';
  }

  void buf_collect()
  {
    while (s_btSerial.available() && s_len < sizeof(s_buf) - 1) {
      int c = s_btSerial.read();
      if (c < 0) break;
      s_buf[s_len++] = (char)c;
    }
    s_buf[s_len] = '\0';
  }

  static bool buf_contains(const char* token)
  {
    return strstr(s_buf, token) != nullptr;
  }

  // Parsing helpers pour quelques PIDs standard.
  bool parse_pid_010C_rpm(const char* line, float& rpmOut)
  {
    const char* p = strstr(line, "41 0C");
    if (!p) return false;
    int A = 0, B = 0;
    if (sscanf(p, "41 0C %x %x", &A, &B) == 2) {
      rpmOut = ((float)(A * 256 + B)) / 4.0f;
      return true;
    }
    return false;
  }

  bool parse_pid_010D_speed(const char* line, float& speedOut)
  {
    const char* p = strstr(line, "41 0D");
    if (!p) return false;
    int A = 0;
    if (sscanf(p, "41 0D %x", &A) == 1) {
      speedOut = (float)A;
      return true;
    }
    return false;
  }

  bool parse_pid_0105_coolant(const char* line, float& tempOut)
  {
    const char* p = strstr(line, "41 05");
    if (!p) return false;
    int A = 0;
    if (sscanf(p, "41 05 %x", &A) == 1) {
      tempOut = (float)A - 40.0f;
      return true;
    }
    return false;
  }

  bool parse_pid_0111_throttle(const char* line, float& thrOut)
  {
    const char* p = strstr(line, "41 11");
    if (!p) return false;
    int A = 0;
    if (sscanf(p, "41 11 %x", &A) == 1) {
      thrOut = (float)A * (100.0f / 255.0f);
      return true;
    }
    return false;
  }

  void schedule_next_pid(uint32_t nowMs)
  {
    // Cycle simple: RPM -> coolant -> throttle -> speed -> ...
    const char* cmd = nullptr;
    switch (s_pidIndex) {
      case 0: cmd = "010C\r\n"; break; // RPM
      case 1: cmd = "0105\r\n"; break; // Coolant
      case 2: cmd = "0111\r\n"; break; // Throttle
      default:
      case 3: cmd = "010D\r\n"; break; // Speed
    }
    s_pidIndex = (uint8_t)((s_pidIndex + 1) & 3u);

    buf_clear();
    if (cmd) {
      s_btSerial.print(cmd);
      s_state       = ObdState::WaitResponse;
      s_stateDeadline = nowMs + 200; // fenêtre de réponse typique
    } else {
      s_state       = ObdState::Idle;
      s_stateDeadline = nowMs + 100;
    }
  }

  void handle_response_for_last_pid()
  {
    // Marque la présence véhicule dès qu'on voit une réponse valide.
    float v = 0.0f;
    bool  ok = false;

    switch ((uint8_t)((s_pidIndex + 3) & 3u)) {
      case 0: // RPM
        ok = parse_pid_010C_rpm(s_buf, v);
        if (ok) {
          s_latest.rpm      = v;
          s_latest.has_rpm  = true;
        }
        break;
      case 1: // Coolant
        ok = parse_pid_0105_coolant(s_buf, v);
        if (ok) {
          s_latest.coolant_temp_c   = v;
          s_latest.has_coolant_temp = true;
        }
        break;
      case 2: // Throttle
        ok = parse_pid_0111_throttle(s_buf, v);
        if (ok) {
          s_latest.throttle_pct = v;
          s_latest.has_throttle = true;
        }
        break;
      case 3: // Speed
        ok = parse_pid_010D_speed(s_buf, v);
        if (ok) {
          s_latest.speed_kmh  = v;
          s_latest.has_speed  = true;
        }
        break;
    }

    if (ok) {
      s_latest.vehicle_present = true;
      s_latest.timestamp_us    = (uint32_t)(timebase_now_us() & 0xFFFFFFFFu);
    }
  }

} // namespace


void obd_init()
{
  // HC-05 en mode DATA (KEY LOW)
  pinMode(PIN_BT_KEY, OUTPUT);
  digitalWrite(PIN_BT_KEY, LOW);

  s_btSerial.end();
  s_btSerial.begin(115200, SERIAL_8N1, PIN_BT_RX, PIN_BT_TX);
  while (s_btSerial.available()) s_btSerial.read();

  s_latest = OBDStatus{};
  s_state  = ObdState::SendReset;
  s_stateDeadline = millis();
  buf_clear();
}

void obd_update()
{
  uint32_t nowMs = millis();

  buf_collect();

  switch (s_state) {
    case ObdState::NotStarted:
      // Pas encore initialisé : on ne fait rien.
      break;

    case ObdState::SendReset:
      buf_clear();
      s_btSerial.print("ATZ\r\n");
      s_state        = ObdState::WaitReset;
      s_stateDeadline = nowMs + 1500;
      break;

    case ObdState::WaitReset:
      // On considère le reset terminé dès qu'on voit "ELM" ou '>'
      if (buf_contains("ELM") || buf_contains(">") ||
          (int32_t)(nowMs - s_stateDeadline) >= 0) {
        buf_clear();
        s_state        = ObdState::SendInit;
        s_stateDeadline = nowMs;
      }
      break;

    case ObdState::SendInit:
      // Configuration minimale : echo off, pas d'espaces/headers, protocole auto.
      buf_clear();
      s_btSerial.print("ATE0\r\nATL0\r\nATS0\r\nATH0\r\nATSP0\r\n");
      s_state        = ObdState::Idle;
      s_stateDeadline = nowMs + 500;
      break;

    case ObdState::Idle:
      if ((int32_t)(nowMs - s_stateDeadline) >= 0) {
        schedule_next_pid(nowMs);
      }
      break;

    case ObdState::WaitResponse:
      if (buf_contains(">") ||
          buf_contains("NO DATA") ||
          buf_contains("?") ||
          (int32_t)(nowMs - s_stateDeadline) >= 0) {
        handle_response_for_last_pid();
        buf_clear();
        s_state        = ObdState::Idle;
        s_stateDeadline = nowMs + 80;
      }
      break;
  }
}

void obd_get_latest(OBDStatus& out)
{
  out = s_latest;
}

