#pragma once

#include <stdint.h>

struct GnssFix {
  bool     valid        = false;
  bool     has_fix      = false;
  uint8_t  fix_quality  = 0;
  float    lat          = 0.0f;
  float    lon          = 0.0f;
  float    alt          = 0.0f;
  float    speed_kmh    = 0.0f;
  float    heading_deg  = 0.0f;
  uint8_t  sats         = 0;
  float    hdop         = 0.0f;
  uint32_t timestamp_us = 0;
};

enum class GnssRateMode : uint8_t {
  Rate20Hz = 0,
  Rate25Hz = 1,
};

class AxionGnss {
public:
  bool begin();
  void update();
  void getFix(GnssFix& out) const;
  bool hasFix() const;

  // Prévu pour le futur : basculer GNSS en mode test 25 Hz.
  void setRateMode(GnssRateMode mode);

private:
  void handleChar(char c);
  void parseSentence(char* sentence);
  void parseGGA(char* sentence);
  void parseRMC(char* sentence);
  void applyRateConfig();

  bool    m_started     = false;
  GnssRateMode m_rateMode = GnssRateMode::Rate20Hz;
  GnssFix m_lastFix{};

  static constexpr int kLineBufSize = 128;
  char   m_lineBuf[kLineBufSize];
  int    m_lineLen    = 0;

  float  m_speedSmooth   = 0.0f;
  float  m_headingSmooth = 0.0f;
};

extern AxionGnss AXION_GNSS;
