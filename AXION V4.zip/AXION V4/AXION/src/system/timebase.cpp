#include <Arduino.h>
#include <Wire.h>

#include "system/timebase.h"
#include "system/pins.h"

namespace {

  constexpr uint8_t RTC_ADDR_DS3231 = 0x68;

  volatile uint32_t s_lastPpsMicros = 0;
  volatile uint32_t s_ppsCount      = 0;
  volatile bool     s_ppsSeen       = false;

  bool     s_rtcPresent     = false;
  uint32_t s_rtcLastSeconds = 0;
  uint32_t s_rtcLastReadMs  = 0;

  uint8_t bcd_to_bin(uint8_t v)
  {
    return (uint8_t)((v >> 4) * 10u + (v & 0x0Fu));
  }

  uint32_t ymd_to_days(int year, int month, int day)
  {
    if (month <= 2) {
      year  -= 1;
      month += 12;
    }
    int era  = year / 400;
    int yoe  = year - era * 400;
    int doy  = (153 * (month - 3) + 2) / 5 + day - 1;
    int doe  = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return (uint32_t)(era * 146097 + doe);
  }

  bool rtc_read_seconds(uint32_t& outSeconds)
  {
    Wire.beginTransmission(RTC_ADDR_DS3231);
    Wire.write(0x00);
    if (Wire.endTransmission(false) != 0) {
      return false;
    }
    if (Wire.requestFrom((int)RTC_ADDR_DS3231, 7) != 7) {
      return false;
    }
    uint8_t sec_bcd  = Wire.read();
    uint8_t min_bcd  = Wire.read();
    uint8_t hour_bcd = Wire.read();
    Wire.read();
    uint8_t date_bcd  = Wire.read();
    uint8_t month_bcd = Wire.read();
    uint8_t year_bcd  = Wire.read();

    int sec   = bcd_to_bin(sec_bcd  & 0x7Fu);
    int min   = bcd_to_bin(min_bcd  & 0x7Fu);
    int hour  = bcd_to_bin(hour_bcd & 0x3Fu);
    int day   = bcd_to_bin(date_bcd & 0x3Fu);
    int month = bcd_to_bin(month_bcd & 0x1Fu);
    int year  = 2000 + bcd_to_bin(year_bcd);

    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return false;
    }

    uint32_t days2000 = ymd_to_days(year, month, day) - ymd_to_days(2000, 1, 1);
    outSeconds = days2000 * 86400u + (uint32_t)hour * 3600u + (uint32_t)min * 60u + (uint32_t)sec;
    return true;
  }

  uint64_t rtc_now_us()
  {
    uint32_t nowMs = millis();
    if (!s_rtcPresent || (nowMs - s_rtcLastReadMs) > 2000u) {
      uint32_t sec = 0;
      if (rtc_read_seconds(sec)) {
        s_rtcPresent     = true;
        s_rtcLastSeconds = sec;
        s_rtcLastReadMs  = nowMs;
      } else {
        s_rtcPresent = false;
      }
    }

    if (!s_rtcPresent) {
      return (uint64_t)micros();
    }

    uint32_t msSinceRead = millis() - s_rtcLastReadMs;
    uint32_t secOffset   = msSinceRead / 1000u;
    uint32_t msRemainder = msSinceRead % 1000u;
    uint64_t seconds     = (uint64_t)(s_rtcLastSeconds + secOffset);
    uint64_t us          = seconds * 1000000ull + (uint64_t)msRemainder * 1000ull;
    return us;
  }

  void IRAM_ATTR pps_isr()
  {
    s_lastPpsMicros = micros();
    ++s_ppsCount;
    s_ppsSeen = true;
  }

} // namespace

void timebase_init()
{
  pinMode(PIN_GNSS_PPS, INPUT);
  attachInterrupt(digitalPinToInterrupt(PIN_GNSS_PPS), pps_isr, RISING);

  uint32_t sec = 0;
  if (rtc_read_seconds(sec)) {
    s_rtcPresent     = true;
    s_rtcLastSeconds = sec;
    s_rtcLastReadMs  = millis();
  } else {
    s_rtcPresent = false;
  }
}

uint64_t timebase_now_us()
{
  uint32_t nowMicros = micros();

  bool     havePps   = s_ppsSeen;
  uint32_t lastPps   = 0;
  uint32_t ppsCount  = 0;
  if (havePps) {
    noInterrupts();
    lastPps  = s_lastPpsMicros;
    ppsCount = s_ppsCount;
    interrupts();
  }

  if (havePps) {
    uint32_t dt = nowMicros - lastPps;
    if (dt > 1000000u) {
      dt = 1000000u;
    }
    uint64_t base = rtc_now_us();
    uint64_t secondsFromPps = (uint64_t)ppsCount * 1000000ull;
    uint64_t us = (base & ~0xFFFFFFFFull) + secondsFromPps + (uint64_t)dt;
    return us;
  }

  return rtc_now_us();
}

bool timebase_has_pps_lock()
{
  if (!s_ppsSeen) return false;
  uint32_t lastPps = 0;
  noInterrupts();
  lastPps = s_lastPpsMicros;
  interrupts();
  uint32_t now = micros();
  uint32_t dt  = now - lastPps;
  return dt < 1500000u;
}

