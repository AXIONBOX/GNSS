﻿// AXION CORE_Project - Pin and address mapping (from AXION_BenchTest)
#pragma once

#include <Arduino.h>

// I2C bus
static constexpr uint8_t PIN_I2C_SDA = 21;  // GPIO21
static constexpr uint8_t PIN_I2C_SCL = 16;  // GPIO16

// -----------------------------------------------------------------------------
// PCF8574 bit mapping (P0..P7)
// -----------------------------------------------------------------------------
// This section centralises the mapping between PCF8574 bits and functions so
// that future PCB revisions can be adapted by editing ONLY these constants.
//
// Current mapping (requested layout):
//   P0 = LED red    (LOW = ON)
//   P1 = BTN_LEFT   (active LOW)
//   P2 = BTN_RIGHT  (active LOW)
//   P3 = BTN_SELECT (active LOW)
//   P4 = LED green  (LOW = ON)
//   P5 = OLED RESET / RS (active LOW)
//   P6 = OLED DC    (1 = Data, 0 = Command)
//   P7 = reserved / unused
// -----------------------------------------------------------------------------
static constexpr uint8_t I2C_ADDR_PCF8574   = 0x20;

static constexpr uint8_t PCF_BIT_LED_RED    = 0;
static constexpr uint8_t PCF_BIT_BTN_LEFT   = 1;
static constexpr uint8_t PCF_BIT_BTN_RIGHT  = 2;
static constexpr uint8_t PCF_BIT_BTN_SELECT = 3;
static constexpr uint8_t PCF_BIT_LED_GREEN  = 4;
static constexpr uint8_t PCF_BIT_OLED_RST   = 5;
static constexpr uint8_t PCF_BIT_OLED_DC    = 6;
// P7 left unassigned for now.


// OLED SSD1322 on dedicated SPI bus
static constexpr uint8_t PIN_OLED_SCLK = 18;
static constexpr uint8_t PIN_OLED_MOSI = 38;
static constexpr uint8_t PIN_OLED_CS   = 5;  // Active LOW

// micro-SD on dedicated SPI bus (FSPI)
static constexpr uint8_t PIN_SD_MISO = 12;
static constexpr uint8_t PIN_SD_MOSI = 13;
static constexpr uint8_t PIN_SD_SCK  = 14;
static constexpr uint8_t PIN_SD_CS   = 15;

// UARTs
// UART1: HC-05
static constexpr uint8_t PIN_BT_TX   = 35; // To HC-05 RX
static constexpr uint8_t PIN_BT_RX   = 36; // From HC-05 TX
static constexpr uint8_t PIN_BT_KEY  = 7;  // HC-05 KEY (HIGH for AT)
// UART2: GNSS LC29H-EA
static constexpr uint8_t PIN_GNSS_TX = 10;
static constexpr uint8_t PIN_GNSS_RX = 9;

// IMU ICM-20948
static constexpr uint8_t PIN_IMU_INT   = 4;
static constexpr uint8_t PIN_IMU_FSYNC = 11;

// Buzzer
static constexpr uint8_t PIN_BUZZER = 47;

#define PIN_GNSS_PPS 17


