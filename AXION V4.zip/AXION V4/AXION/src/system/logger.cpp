#include <Arduino.h>
#include <SPI.h>
#include <SD.h>

#include "system/logger.h"
#include "system/timebase.h"
#include "system/pins.h"

namespace {

  bool s_sdSpiInited  = false;
  bool s_loggerReady  = false;
  File s_logFile;

  void ensure_sd()
  {
    if (!s_sdSpiInited) {
      SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
      s_sdSpiInited = true;
    }
    if (!SD.begin(PIN_SD_CS)) {
      s_loggerReady = false;
      return;
    }
    s_loggerReady = true;
  }

  void open_log_file_if_needed()
  {
    if (!s_loggerReady) return;
    if (s_logFile) return;

    if (!SD.exists("/AXION")) {
      SD.mkdir("/AXION");
    }

    s_logFile = SD.open("/AXION/AXION_LOG.CSV", FILE_APPEND);
    if (!s_logFile) {
      s_loggerReady = false;
      return;
    }

    if (s_logFile.size() == 0) {
      s_logFile.println(
        "timestamp_us,"
        "gnss_valid,imu_valid,obd_valid,"
        "lat,lon,alt,sats,hdop,fix_quality,"
        "speed_kmh,accel_x_g,accel_y_g,accel_z_g,"
        "gyro_x_deg_s,gyro_y_deg_s,gyro_z_deg_s,heading_deg,"
        "rpm,throttle_pct,coolant_temp_c,"
        "obd_speed_kmh"
      );
      s_logFile.flush();
    }
  }

} // namespace

void logger_init()
{
  ensure_sd();
  open_log_file_if_needed();
}

void logger_update(const AxionData& data)
{
  if (!s_loggerReady) {
    logger_init();
    if (!s_loggerReady) return;
  }

  open_log_file_if_needed();
  if (!s_logFile) return;

  uint64_t ts = timebase_now_us();

  // On récupère éventuellement la vitesse OBD via le module OBD.
  // Pour ne pas coupler logger et OBD, on loggue simplement speed_kmh
  // côté fusion, et la vitesse OBD sera ajoutée plus tard si besoin.
  float obd_speed_kmh = 0.0f;

  // Format CSV compact, une ligne par tick 25 Hz.
  s_logFile.print((unsigned long long)ts);
  s_logFile.print(',');
  s_logFile.print(data.gnss_valid ? 1 : 0);
  s_logFile.print(',');
  s_logFile.print(data.imu_valid ? 1 : 0);
  s_logFile.print(',');
  s_logFile.print(data.obd_valid ? 1 : 0);
  s_logFile.print(',');

  s_logFile.print(data.lat, 7);          s_logFile.print(',');
  s_logFile.print(data.lon, 7);          s_logFile.print(',');
  s_logFile.print(data.alt, 2);          s_logFile.print(',');
  s_logFile.print((unsigned)data.sats);  s_logFile.print(',');
  s_logFile.print(data.hdop, 2);         s_logFile.print(',');
  s_logFile.print((unsigned)data.fix_quality); s_logFile.print(',');

  s_logFile.print(data.speed_kmh, 2);    s_logFile.print(',');
  s_logFile.print(data.accel_g[0], 3);   s_logFile.print(',');
  s_logFile.print(data.accel_g[1], 3);   s_logFile.print(',');
  s_logFile.print(data.accel_g[2], 3);   s_logFile.print(',');

  s_logFile.print(data.gyro_deg[0], 2);  s_logFile.print(',');
  s_logFile.print(data.gyro_deg[1], 2);  s_logFile.print(',');
  s_logFile.print(data.gyro_deg[2], 2);  s_logFile.print(',');
  s_logFile.print(data.heading_deg, 2);  s_logFile.print(',');

  s_logFile.print(data.rpm, 1);          s_logFile.print(',');
  s_logFile.print(data.throttle, 1);     s_logFile.print(',');
  s_logFile.print(data.coolant_temp_c, 1); s_logFile.print(',');

  s_logFile.print(obd_speed_kmh, 2);
  s_logFile.println();

  // Flush léger pour limiter les pertes; on pourrait le faire
  // une fois toutes les N lignes si besoin.
  s_logFile.flush();
}

