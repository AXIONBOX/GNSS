#pragma once

#include <stdint.h>

struct ImuSample {
  bool     valid        = false;
  float    accel_g[3]   = {0.0f, 0.0f, 0.0f};
  float    gyro_deg[3]  = {0.0f, 0.0f, 0.0f};
  uint32_t timestamp_us = 0;
};

bool imu_begin();
void imu_update();
void imu_get_latest(ImuSample& out);
bool imu_is_present();

