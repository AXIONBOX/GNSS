#include <Arduino.h>
#include <math.h>

#include "data_fusion.h"
#include "../include/lap_v11.h"

// AXION V11 – Automatic Lap Manager (Option C)
// Lightweight GNSS+IMU lap timing with automatic track detection.

namespace {

// Local XY projection around an origin (lat0, lon0) in meters.
static void latlon_to_xy(double lat0, double lon0,
                         double lat,  double lon,
                         float& x, float& y)
{
  static constexpr double DEG2RAD = 3.14159265358979323846 / 180.0;
  double dlat = (lat - lat0) * 111320.0;  // rough meters per degree latitude
  double cosLat = cos(lat0 * DEG2RAD);
  double dlon = (lon - lon0) * (40075000.0 * cosLat / 360.0); // rough meters per degree longitude
  x = (float)dlon;
  y = (float)dlat;
}

static float wrap_deg(float a)
{
  while (a > 180.0f) a -= 360.0f;
  while (a < -180.0f) a += 360.0f;
  return a;
}

struct LapStateV11 {
  // Track build / detection
  enum class Phase : uint8_t { Idle, Building, TrackLocked };
  Phase phase = Phase::Idle;

  // Origin for local XY
  bool   haveOrigin = false;
  double originLat = 0.0;
  double originLon = 0.0;

  static constexpr int MAX_PTS = 256;
  int     nPts = 0;
  float   px[MAX_PTS];
  float   py[MAX_PTS];
  float   pHeading[MAX_PTS];
  float   pSpeed[MAX_PTS];
  uint32_t pTsMs[MAX_PTS];

  // Virtual start/finish line (in XY, meters)
  bool   lineValid = false;
  float  lineAx = 0.0f, lineAy = 0.0f; // anchor point
  float  lineNx = 0.0f, lineNy = 0.0f; // outward normal (defines side)
  float  dirTx = 0.0f, dirTy = 0.0f;   // along-track direction near start/finish

  // Last side of line
  bool   haveSide = false;
  float  lastSide = 0.0f;

  // Lap timing (based on AxionData timestamp_us when available)
  bool    lapRunning = false;
  bool    trackDetected = false;
  bool    suspended = false;
  uint64_t lapStartTsUs = 0;   // last S/F crossing
  uint64_t lastUpdateTsUs = 0; // last valid update

  float currentLap = 0.0f;
  float lastLap    = 0.0f;
  float bestLap    = 0.0f;
  float deltaBest  = 0.0f;

  // For closure & noise rejection
  uint64_t lastCrossTsUs = 0;

  // Current XY position (for visualization)
  float curX = 0.0f;
  float curY = 0.0f;
};

static LapStateV11 s;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static bool gnss_good(const AxionData& D)
{
  if (D.fix_quality == 0) return false;
  if (D.sats < 6) return false;
  if (D.hdop > 2.0f && D.hdop > 0.0f) return false;
  return true;
}

// Append a point to the track buffer (with basic spacing).
static void add_track_point(const AxionData& D, float x, float y)
{
  uint32_t nowMs = millis();

  if (s.nPts > 0) {
    float dx = x - s.px[s.nPts - 1];
    float dy = y - s.py[s.nPts - 1];
    float d2 = dx*dx + dy*dy;
    // Bench: garder ~20 m entre les points stockés
    if (d2 < 400.0f) { // < 20 m^2 : trop proche, on saute
      return;
    }
  }

  if (s.nPts < LapStateV11::MAX_PTS) {
    s.px[s.nPts]       = x;
    s.py[s.nPts]       = y;
    s.pHeading[s.nPts] = D.heading_deg;
    s.pSpeed[s.nPts]   = D.speed_kmh;
    s.pTsMs[s.nPts]    = nowMs;
    ++s.nPts;
  } else {
    // Simple ring buffer: drop the oldest, shift left.
    for (int i = 1; i < LapStateV11::MAX_PTS; ++i) {
      s.px[i-1]       = s.px[i];
      s.py[i-1]       = s.py[i];
      s.pHeading[i-1] = s.pHeading[i];
      s.pSpeed[i-1]   = s.pSpeed[i];
      s.pTsMs[i-1]    = s.pTsMs[i];
    }
    s.px[s.nPts-1]       = x;
    s.py[s.nPts-1]       = y;
    s.pHeading[s.nPts-1] = D.heading_deg;
    s.pSpeed[s.nPts-1]   = D.speed_kmh;
    s.pTsMs[s.nPts-1]    = nowMs;
  }
}

// Build start/finish line around track point idx.
static void lock_start_line(int idx)
{
  if (s.nPts < 4) return;

  int i0 = idx;
  int i1 = (idx + 1 < s.nPts) ? idx + 1 : idx; // avoid out of range

  float vx = s.px[i1] - s.px[i0];
  float vy = s.py[i1] - s.py[i0];
  float len = sqrtf(vx*vx + vy*vy);
  if (len < 1.0f) {
    // Too short; try a bit further.
    int i2 = (idx + 2 < s.nPts) ? idx + 2 : idx;
    vx = s.px[i2] - s.px[i0];
    vy = s.py[i2] - s.py[i0];
    len = sqrtf(vx*vx + vy*vy);
  }
  if (len < 1.0f) return;

  vx /= len; vy /= len;         // along-track direction
  float nx = -vy, ny = vx;      // perpendicular (normal)

  s.lineAx = s.px[i0];
  s.lineAy = s.py[i0];
  s.dirTx  = vx;
  s.dirTy  = vy;
  s.lineNx = nx;
  s.lineNy = ny;

  // Initialize side with current point if available
  s.haveSide = false;
  s.lineValid = true;
  s.trackDetected = true;
}

// Check if current point closes the loop.
static void check_loop_closure(const AxionData& D, float x, float y)
{
  if (s.phase != LapStateV11::Phase::Building) return;
  if (s.nPts < 30) return; // need some history (bench-friendly)

  // Require some minimum distance travelled / time before closing
  uint32_t nowMs = millis();
  if (nowMs - s.pTsMs[0] < 5000u) return; // < 5s => too soon (bench)

  float minDist2 = 40.0f * 40.0f; // 40 m radius (bench)
  int bestIdx = -1;

  // Do not consider the last few seconds to avoid self-close at start.
  uint32_t tailMs = nowMs - 2000u;

  for (int i = 0; i < s.nPts - 10; ++i) {
    if (s.pTsMs[i] > tailMs) continue;

    float dx = x - s.px[i];
    float dy = y - s.py[i];
    float d2 = dx*dx + dy*dy;
    if (d2 > minDist2) continue;

    float dHeading = wrap_deg(D.heading_deg - s.pHeading[i]);
    if (fabsf(dHeading) > 25.0f) continue;

    float dSpeed = fabsf(D.speed_kmh - s.pSpeed[i]);
    if (dSpeed > 25.0f) continue;

    bestIdx = i;
    break;
  }

  if (bestIdx >= 0) {
    lock_start_line(bestIdx);
    if (s.lineValid) {
      s.phase = LapStateV11::Phase::TrackLocked;
      s.haveSide = false;
    }
  }
}

// Compute signed distance to start/finish line.
static float line_side(float x, float y)
{
  float dx = x - s.lineAx;
  float dy = y - s.lineAy;
  return dx * s.lineNx + dy * s.lineNy;
}

// Use timestamp_us when available; fallback to micros().
static uint64_t ts_now_us(const AxionData& D)
{
  if (D.timestamp_us != 0) return (uint64_t)D.timestamp_us;
  return (uint64_t)micros();
}

} // namespace

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

void lap_reset()
{
  s = LapStateV11{};
}

void lap_update(const AxionData& D)
{
  uint64_t nowUs = ts_now_us(D);
  s.lastUpdateTsUs = nowUs;

  // GNSS validity
  bool okGnss = gnss_good(D);
  if (!okGnss || D.speed_kmh < 1.0f) {
    // Suspend timing if GNSS poor / stopped
    s.suspended = true;
    s.lapRunning = false;
    s.currentLap = 0.0f;
    return;
  }

  s.suspended = false;

  // Initialize local origin
  if (!s.haveOrigin) {
    s.originLat = D.lat;
    s.originLon = D.lon;
    s.haveOrigin = true;
  }

  float x = 0.0f, y = 0.0f;
  latlon_to_xy(s.originLat, s.originLon, D.lat, D.lon, x, y);

  // Store current XY for visualization (mini-map car dot)
  s.curX = x;
  s.curY = y;

  // State machine
  if (s.phase == LapStateV11::Phase::Idle) {
    if (D.speed_kmh > 15.0f) {
      s.phase = LapStateV11::Phase::Building;
      s.nPts = 0;
      add_track_point(D, x, y);
    }
  } else if (s.phase == LapStateV11::Phase::Building) {
    if (D.speed_kmh < 5.0f) {
      // Too slow for a while: drop back to Idle
      static uint32_t slowSince = 0;
      uint32_t ms = millis();
      if (!slowSince) slowSince = ms;
      if (ms - slowSince > 10000u) { // 10s slow
        lap_reset();
        return;
      }
    }
    add_track_point(D, x, y);
    check_loop_closure(D, x, y);
  } else if (s.phase == LapStateV11::Phase::TrackLocked) {
    // Track already detected, do nothing special with points for now.
  }

  if (!(s.phase == LapStateV11::Phase::TrackLocked && s.lineValid)) {
    // No start/finish yet: no laps.
    s.lapRunning = false;
    s.currentLap = 0.0f;
    return;
  }

  // Start/finish crossing detection
  float side = line_side(x, y);

  if (!s.haveSide) {
    s.lastSide  = side;
    s.haveSide  = true;
    s.lapRunning = false;
    s.currentLap = 0.0f;
    return;
  }

  // Check for side change (crossing).
  // En bench, on accepte le changement de signe dans les deux sens
  // (les filtres vitesse / heading / dt nettoient ensuite).
  bool crossedLine = (s.lastSide <= 0.0f && side >= 0.0f) ||
                     (s.lastSide >= 0.0f && side <= 0.0f);

  // Fallback pour la simu: très proche de la ligne => crossing aussi.
  if (!crossedLine && fabsf(side) < 2.0f) {
    crossedLine = true;
  }

  s.lastSide = side;

  if (!crossedLine) {
    // If a lap is running, update current lap time
    if (s.lapRunning && s.lapStartTsUs != 0) {
      s.currentLap = (float)((nowUs - s.lapStartTsUs) * 1e-6);
    } else {
      s.currentLap = 0.0f;
    }
    return;
  }

  // Additional gates for crossing validity
  if (D.speed_kmh < 5.0f) return;                  // too slow (bench)
  if (!okGnss) return;

  // Directionality check (heading vs track dir)
  float hdgRad = D.heading_deg * (float)M_PI / 180.0f;
  float vx = cosf(hdgRad);
  float vy = sinf(hdgRad);
  float dotDir = vx * s.dirTx + vy * s.dirTy;
  if (dotDir < 0.0f) return;                       // going backwards

  // Reject too-frequent crossings (noise)
  if (s.lastCrossTsUs != 0) {
    float dtCross = (float)((nowUs - s.lastCrossTsUs) * 1e-6);
    if (dtCross < 5.0f) { // < 5 s => likely noise (bench)
      return;
    }
  }

  s.lastCrossTsUs = nowUs;

  if (!s.lapRunning || s.lapStartTsUs == 0) {
    // First valid crossing: start lap
    s.lapStartTsUs = nowUs;
    s.lapRunning   = true;
    s.currentLap   = 0.0f;
    return;
  }

  // Complete lap
  float lapTime = (float)((nowUs - s.lapStartTsUs) * 1e-6);
  s.lapStartTsUs = nowUs;
  s.lapRunning   = true;
  s.currentLap   = 0.0f;

  s.lastLap = lapTime;
  if (s.bestLap <= 0.0f || lapTime < s.bestLap) {
    s.bestLap = lapTime;
    s.deltaBest = 0.0f;
  } else {
    s.deltaBest = lapTime - s.bestLap;
  }
}

// ---------------------------------------------------------------------------
// Getters
// ---------------------------------------------------------------------------

float lap_get_current_time() { return s.currentLap; }
float lap_get_last_time()    { return s.lastLap; }
float lap_get_best_time()    { return s.bestLap; }
float lap_get_delta_vs_best(){ return s.deltaBest; }

bool lap_track_detected()    { return s.trackDetected && s.lineValid; }
bool lap_is_running()        { return s.lapRunning; }
bool lap_is_suspended()      { return s.suspended; }

int lap_get_track_count()
{
  return s.nPts;
}

bool lap_get_track_point(int idx, float& x, float& y)
{
  if (idx < 0 || idx >= s.nPts) return false;
  x = s.px[idx];
  y = s.py[idx];
  return true;
}

bool lap_get_sf_line(float& ax, float& ay, float& nx, float& ny)
{
  if (!s.lineValid) return false;
  ax = s.lineAx;
  ay = s.lineAy;
  nx = s.lineNx;
  ny = s.lineNy;
  return true;
}

// Current XY position of the car (for mini-map).
bool lap_get_current_xy(float& x, float& y)
{
  if (!s.haveOrigin) return false;
  x = s.curX;
  y = s.curY;
  return true;
}

