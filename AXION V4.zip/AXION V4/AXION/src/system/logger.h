#pragma once

#include "data_fusion.h"

// Initialisation paresseuse du logger (microSD).
// Peut être appelée explicitement au démarrage; sinon logger_update
// tentera une init à la première utilisation.
void logger_init();

// Enregistre une trame AxionData à ~25 Hz (Core 0).
// Non bloquant dans la mesure du possible : si la carte SD
// n'est pas prête, la fonction retourne simplement.
void logger_update(const AxionData& data);

