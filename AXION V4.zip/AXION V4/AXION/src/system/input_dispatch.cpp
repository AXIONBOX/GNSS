#include <Arduino.h>

#include "system/input_dispatch.h"
#include "system/pins.h"
#include "system/pcf.h"

namespace {

  bool     gTripleBtnActive   = false;
  uint32_t gTripleBtnStartMs  = 0;

  uint8_t  s_prevBtns         = 0xFF;
  uint32_t s_selHoldStart     = 0;
  bool     s_selLongHandled   = false;
  uint32_t s_lrHoldStart      = 0;
  bool     s_lrLongHandled    = false;
  uint32_t s_leftHoldStart    = 0;
  uint32_t s_rightHoldStart   = 0;
  uint32_t s_leftLastRep      = 0;
  uint32_t s_rightLastRep     = 0;

  InputState s_state{};

} // namespace

void input_init()
{
  gTripleBtnActive  = false;
  gTripleBtnStartMs = 0;

  s_prevBtns        = 0xFF;
  s_selHoldStart    = 0;
  s_selLongHandled  = false;
  s_lrHoldStart     = 0;
  s_lrLongHandled   = false;
  s_leftHoldStart   = 0;
  s_rightHoldStart  = 0;
  s_leftLastRep     = 0;
  s_rightLastRep    = 0;

  s_state = InputState{};
}

void input_update()
{
  InputState st{};

  uint8_t v = 0xFF;
  if (!pcf::read_byte(I2C_ADDR_PCF8574, v)) {
    s_state = InputState{};
    return;
  }

  bool left   = ((v >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
  bool right  = ((v >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
  bool sel    = ((v >> PCF_BIT_BTN_SELECT) & 1u) == 0;

  bool leftPrev   = ((s_prevBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
  bool rightPrev  = ((s_prevBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
  bool selPrev    = ((s_prevBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;

  st.left_pressed   = left;
  st.right_pressed  = right;
  st.select_pressed = sel;

  st.left_edge_press    = left  && !leftPrev;
  st.right_edge_press   = right && !rightPrev;
  st.select_edge_press  = sel   && !selPrev;
  st.left_release       = !left  && leftPrev;
  st.right_release      = !right && rightPrev;
  st.select_release     = !sel   && selPrev;

  uint32_t now = millis();

  // Triple hold (L+R+SEL).
  bool triple = left && right && sel;
  if (triple) {
    if (!gTripleBtnActive) {
      gTripleBtnActive  = true;
      gTripleBtnStartMs = now;
    } else if ((now - gTripleBtnStartMs) > 1500u) {
      st.triple_reinit_event = true;
      gTripleBtnActive       = false;
    }
  } else {
    gTripleBtnActive = false;
  }

  // Long press SELECT seul -> MENU.
  if (sel && !left && !right) {
    if (!selPrev) {
      s_selHoldStart   = now;
      s_selLongHandled = false;
    } else if (!s_selLongHandled && (now - s_selHoldStart) > 1200u) {
      st.select_long_to_menu = true;
      s_selLongHandled       = true;
    }
  }

  bool bothLR = left && right && !sel;
  if (bothLR) {
    if (!s_lrHoldStart) {
      s_lrHoldStart   = now;
      s_lrLongHandled = false;
    } else if (!s_lrLongHandled && (now - s_lrHoldStart) > 800u) {
      st.both_lr_long = true;
      s_lrLongHandled = true;
    }
  } else {
    s_lrHoldStart   = 0;
    s_lrLongHandled = false;
  }

  const uint32_t REPEAT_DELAY    = 800u;
  const uint32_t REPEAT_INTERVAL = 120u;

  // Auto-repeat LEFT
  if (left) {
    if (!leftPrev) {
      s_leftHoldStart = now;
      s_leftLastRep   = now;
    } else if ((now - s_leftHoldStart) >= REPEAT_DELAY &&
               (now - s_leftLastRep)   >= REPEAT_INTERVAL) {
      st.left_repeat  = true;
      s_leftLastRep   = now;
    }
  } else {
    s_leftHoldStart = 0;
  }

  // Auto-repeat RIGHT
  if (right) {
    if (!rightPrev) {
      s_rightHoldStart = now;
      s_rightLastRep   = now;
    } else if ((now - s_rightHoldStart) >= REPEAT_DELAY &&
               (now - s_rightLastRep)   >= REPEAT_INTERVAL) {
      st.right_repeat = true;
      s_rightLastRep  = now;
    }
  } else {
    s_rightHoldStart = 0;
  }

  s_prevBtns = v;
  s_state    = st;
}

void input_get_snapshot(InputState& out)
{
  out = s_state;
}

