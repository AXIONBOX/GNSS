#include <Arduino.h>
#include <Wire.h>

#include "system/imu.h"
#include "system/pins.h"
#include "system/timebase.h"

namespace {

  constexpr uint8_t ICM_ADDR = 0x69;

  bool     s_present        = false;
  ImuSample s_lastSample{};
  uint32_t s_lastReadMs     = 0;

  bool imu_read_regs(uint8_t startReg, uint8_t* buf, size_t len)
  {
    Wire.beginTransmission(ICM_ADDR);
    Wire.write(startReg);
    if (Wire.endTransmission(false) != 0) {
      return false;
    }
    size_t n = Wire.requestFrom((int)ICM_ADDR, (int)len);
    if (n != len) {
      return false;
    }
    for (size_t i = 0; i < len; ++i) {
      buf[i] = (uint8_t)Wire.read();
    }
    return true;
  }

  bool imu_read_whoami(uint8_t& outVal)
  {
    uint8_t v = 0;
    if (!imu_read_regs(0x00, &v, 1)) {
      return false;
    }
    outVal = v;
    return true;
  }

  bool imu_read_raw(int16_t accel[3], int16_t gyro[3])
  {
    uint8_t buf[12];
    if (!imu_read_regs(0x2D, buf, sizeof(buf))) {
      return false;
    }

    accel[0] = (int16_t)((buf[0] << 8) | buf[1]);
    accel[1] = (int16_t)((buf[2] << 8) | buf[3]);
    accel[2] = (int16_t)((buf[4] << 8) | buf[5]);
    gyro[0]  = (int16_t)((buf[6] << 8) | buf[7]);
    gyro[1]  = (int16_t)((buf[8] << 8) | buf[9]);
    gyro[2]  = (int16_t)((buf[10] << 8) | buf[11]);
    return true;
  }

} // namespace

bool imu_begin()
{
  pinMode(PIN_IMU_INT, INPUT);
  pinMode(PIN_IMU_FSYNC, INPUT);

  uint8_t who = 0;
  if (!imu_read_whoami(who)) {
    s_present = false;
    return false;
  }

  s_present    = true;
  s_lastSample = ImuSample{};
  s_lastReadMs = 0;

  return true;
}

void imu_update()
{
  if (!s_present) return;

  uint32_t nowMs = millis();
  if ((nowMs - s_lastReadMs) < 10u) {
    return;
  }
  s_lastReadMs = nowMs;

  int16_t accelRaw[3] = {0,0,0};
  int16_t gyroRaw[3]  = {0,0,0};
  if (!imu_read_raw(accelRaw, gyroRaw)) {
    return;
  }

  ImuSample sample{};

  const float accelScale = 16.0f / 32768.0f;
  const float gyroScale  = 2000.0f / 32768.0f;

  sample.accel_g[0] = accelRaw[0] * accelScale;
  sample.accel_g[1] = accelRaw[1] * accelScale;
  sample.accel_g[2] = accelRaw[2] * accelScale;

  sample.gyro_deg[0] = gyroRaw[0] * gyroScale;
  sample.gyro_deg[1] = gyroRaw[1] * gyroScale;
  sample.gyro_deg[2] = gyroRaw[2] * gyroScale;

  uint64_t nowUs64    = timebase_now_us();
  sample.timestamp_us = (uint32_t)(nowUs64 & 0xFFFFFFFFu);
  sample.valid        = true;

  s_lastSample = sample;
}

void imu_get_latest(ImuSample& out)
{
  out = s_lastSample;
}

bool imu_is_present()
{
  return s_present;
}

