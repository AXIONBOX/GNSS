#pragma once

#include <stdint.h>

// AXION V11 timebase:
// horloge commune (microsecondes) basée sur PPS GNSS,
// avec repli sur DS3231 puis micros() si nécessaire.

void timebase_init();

// Horloge globale en microsecondes.
uint64_t timebase_now_us();

// Indique si un PPS valide a été vu récemment.
bool timebase_has_pps_lock();

