#include <Arduino.h>

#include "data/data_source.h"
#include "data_fusion.h"

// Declarations des helpers simulation (implementes dans data_source_sim.cpp)
void data_source_sim_init();
void data_source_sim_update();
void data_source_sim_snapshot(AxionData& out);

static DataSourceMode s_mode = DataSourceMode::Simulation;

void data_source_init(DataSourceMode mode)
{
  s_mode = mode;

  switch (s_mode) {
  case DataSourceMode::Simulation:
    data_source_sim_init();
    break;
  case DataSourceMode::Real:
    // Le mode réel s'appuie désormais sur la pipeline
    // globale (task_data_core sur Core 0). Rien à faire ici.
    break;
  }
}

void data_source_update()
{
  switch (s_mode) {
  case DataSourceMode::Simulation:
    data_source_sim_update();
    break;
  case DataSourceMode::Real:
    // La mise à jour temps réel est effectuée sur Core 0
    // par task_data_core (data_fusion_update à 25 Hz).
    break;
  }
}

void data_source_snapshot(AxionData& out)
{
  switch (s_mode) {
  case DataSourceMode::Simulation:
    data_source_sim_snapshot(out);
    break;
  case DataSourceMode::Real:
    data_fusion_snapshot(out);
    break;
  }
}
