﻿#pragma once

#include "data_fusion.h"

// CORE_Project data source abstraction.
// Fournit un AxionData unique aux moteurs (Lap, etc.),
// en provenance soit de la simulation, soit de la vraie fusion.

enum class DataSourceMode {
  Real,
  Simulation,
};

// Initialisation de la source de données (mode réel ou simulation).
void data_source_init(DataSourceMode mode);

// Mise à jour de la source (à appeler dans loop ou par page UI).
void data_source_update();

// Snapshot atomique des données courantes.
void data_source_snapshot(AxionData& out);
