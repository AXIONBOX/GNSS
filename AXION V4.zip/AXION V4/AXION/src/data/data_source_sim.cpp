﻿#include <Arduino.h>
#include <math.h>

#include "data_fusion.h"

// Simulation interne (bench) : trajectoire type Grand Valley.
// Génère un AxionData synthétique.

struct SimNode {
  float x;
  float y;
  float vKmh; // target speed at this node
};

static const SimNode kSimTrack[] = {
  // Strongly non-circular layout, inspired by a Grand Valley-style track
  {   0.0f,    0.0f, 160.0f }, // start of main straight
  { 180.0f,    0.0f, 180.0f },
  { 260.0f,  -10.0f, 180.0f }, // end of main straight, slight kink
  { 320.0f,  -60.0f, 150.0f }, // fast right
  { 360.0f, -130.0f, 130.0f }, // downhill right
  { 340.0f, -200.0f, 110.0f }, // heavy braking
  { 280.0f, -250.0f, 100.0f }, // tight hairpin bottom
  { 190.0f, -270.0f, 110.0f },
  { 100.0f, -260.0f, 130.0f }, // exit hairpin
  {  20.0f, -230.0f, 140.0f },
  { -40.0f, -190.0f, 130.0f }, // fast left sweep
  { -90.0f, -130.0f, 110.0f },
  { -120.0f, -60.0f, 100.0f }, // climb back up
  { -110.0f,  10.0f,  90.0f },
  {  -80.0f,  70.0f, 100.0f }, // infield section
  {  -20.0f, 110.0f, 110.0f },
  {   60.0f, 130.0f, 130.0f },
  {  150.0f, 120.0f, 140.0f },
  {  220.0f,  80.0f, 150.0f }, // flowing esses
  {  260.0f,  30.0f, 160.0f },
  {  220.0f,   0.0f, 170.0f }, // back toward main
  {   0.0f,   0.0f, 160.0f }   // close loop at start
};

static const int kSimTrackCount = (int)(sizeof(kSimTrack) / sizeof(kSimTrack[0]));

static bool      s_init      = false;
static double    s_lat0      = 45.000000;
static double    s_lon0      = -73.000000;
static uint32_t  s_lastUs    = 0;
static float     s_trackLen  = 0.0f;
static float     s_segAccum[kSimTrackCount];
static float     s_dist      = 0.0f;   // distance along track (m)
static float     s_speedKmh  = 80.0f;  // simulated speed
static AxionData s_simData{};          // dernier état simulé

void data_source_sim_init()
{
  s_init     = false;
  s_lastUs   = 0;
  s_trackLen = 0.0f;
  s_dist     = 0.0f;
  s_speedKmh = 80.0f;
  s_simData = AxionData{};
}

void data_source_sim_update()
{
  uint32_t nowUs = micros();
  float dt = 0.02f;
  if (s_lastUs != 0) {
    dt = (nowUs - s_lastUs) * 1e-6f;
    if (dt < 0.005f) dt = 0.005f;
    if (dt > 0.1f)   dt = 0.1f;
  }
  s_lastUs = nowUs;

  if (!s_init) {
    // Precompute segment lengths and cumulative distances
    s_segAccum[0] = 0.0f;
    float acc = 0.0f;
    for (int i = 0; i < kSimTrackCount - 1; ++i) {
      float dx = kSimTrack[i+1].x - kSimTrack[i].x;
      float dy = kSimTrack[i+1].y - kSimTrack[i].y;
      float len = sqrtf(dx*dx + dy*dy);
      acc += len;
      s_segAccum[i+1] = acc;
    }
    s_trackLen = acc;
    if (s_trackLen <= 0.0f) s_trackLen = 1.0f;
    s_init = true;
  }

  // Determine local target speed depending on position along track
  float targetV = 90.0f;
  float d = fmodf(s_dist, s_trackLen);
  if (d < 0.0f) d += s_trackLen;
  int seg = 0;
  for (int i = 0; i < kSimTrackCount - 1; ++i) {
    if (d >= s_segAccum[i] && d <= s_segAccum[i+1]) { seg = i; break; }
  }
  const SimNode& n0 = kSimTrack[seg];
  const SimNode& n1 = kSimTrack[seg+1];
  float segLen = s_segAccum[seg+1] - s_segAccum[seg];
  float t = (segLen > 0.0f) ? ((d - s_segAccum[seg]) / segLen) : 0.0f;
  if (t < 0.0f) t = 0.0f;
  if (t > 1.0f) t = 1.0f;
  targetV = n0.vKmh + (n1.vKmh - n0.vKmh) * t;

  // Smoothly move current speed toward target
  float alpha = 2.0f * dt; // convergence factor
  if (alpha > 1.0f) alpha = 1.0f;
  s_speedKmh += (targetV - s_speedKmh) * alpha;
  if (s_speedKmh < 30.0f) s_speedKmh = 30.0f;

  // Advance distance along track
  float v_mps = s_speedKmh / 3.6f;
  s_dist += v_mps * dt;
  if (s_dist > s_trackLen) s_dist -= s_trackLen;

  // Recompute segment and interpolation for current position
  d = fmodf(s_dist, s_trackLen);
  if (d < 0.0f) d += s_trackLen;
  seg = 0;
  for (int i = 0; i < kSimTrackCount - 1; ++i) {
    if (d >= s_segAccum[i] && d <= s_segAccum[i+1]) { seg = i; break; }
  }
  const SimNode& p0 = kSimTrack[seg];
  const SimNode& p1 = kSimTrack[seg+1];
  segLen = s_segAccum[seg+1] - s_segAccum[seg];
  t = (segLen > 0.0f) ? ((d - s_segAccum[seg]) / segLen) : 0.0f;
  if (t < 0.0f) t = 0.0f;
  if (t > 1.0f) t = 1.0f;

  float x = p0.x + (p1.x - p0.x) * t;
  float y = p0.y + (p1.y - p0.y) * t;

  // Heading from segment direction (in degrees)
  float dx = p1.x - p0.x;
  float dy = p1.y - p0.y;
  float hdgRad = atan2f(dy, dx); // radians
  float hdgDeg = hdgRad * 180.0f / 3.14159265f;
  if (hdgDeg < 0.0f) hdgDeg += 360.0f;

  // Convert local XY back to lat/lon approximately
  double lat = s_lat0 + (double)y / 111320.0;
  double lon = s_lon0 + (double)x / (40075000.0 * cos(s_lat0 * 3.14159265358979323846 / 180.0) / 360.0);

  AxionData D{};
  D.lat          = (float)lat;
  D.lon          = (float)lon;
  D.alt          = 0.0f;
  D.speed_kmh    = s_speedKmh;
  D.heading_deg  = hdgDeg;
  D.sats         = 12;
  D.hdop         = 0.7f;
  D.fix_quality  = 1;
  D.timestamp_us = nowUs;

  s_simData = D;
}

void data_source_sim_snapshot(AxionData& out)
{
  out = s_simData;
}

