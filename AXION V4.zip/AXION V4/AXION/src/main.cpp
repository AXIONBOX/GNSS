﻿
#include <Arduino.h>
#include <LovyanGFX.hpp>
#include <SPI.h>
#include <Wire.h>
#include "system/pins.h"
#include "system/pcf.h"
#include "ui/ui_shared.h"
#include "logic_modes/diagnostics_engine.h"
#include "hardware/display_ssd1322.h"
#include "system/input_dispatch.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#if defined(USE_MOCK_DATA)
#  undef USE_DATA_FUSION
#endif
#if defined(USE_DATA_FUSION)
  #if __has_include("data_fusion.h")
    #include "data_fusion.h"
  #elif __has_include("../include/data_fusion.h")
    #include "../include/data_fusion.h"
  #elif __has_include("../../AXION/include/data_fusion.h")
    #include "../../AXION/include/data_fusion.h"
  #else
    #warning "USE_DATA_FUSION defined but data_fusion.h not found; falling back to mock data."
    #undef USE_DATA_FUSION
  #endif

  #include "system/obd.h"
  #include "system/logger.h"
#endif


static TaskHandle_t gTaskDataCore = nullptr;
static TaskHandle_t gTaskUiCore   = nullptr;

static void task_data_core(void* pvParameters);
static void task_ui_core(void* pvParameters);
static void ui_loop_iteration();


static inline void draw_debug_overlay()
{
#if defined(DEBUG_OVERLAYS)
  canvas.setFont(&fonts::Font0);
  canvas.setTextDatum(bottom_left);
  canvas.setTextColor(colGray(136));
  uint32_t fps_show = 0;
  extern uint32_t g_lastFpsValue; 
  fps_show = g_lastFpsValue;
  int32_t dt_us = 0;
#if defined(USE_DATA_FUSION)
  AxionData Ddbg; data_fusion_snapshot(Ddbg);
  if (Ddbg.timestamp_us) {
    dt_us = (int32_t)((int64_t)micros() - (int64_t)Ddbg.timestamp_us);
  }
#endif
  char buf[32];
  snprintf(buf, sizeof(buf), "FPS:%lu dt:%ldus", (unsigned long)fps_show, (long)dt_us);
  canvas.drawString(buf, 2, 63);
#endif
}




void draw_menu(uint32_t frame);
void draw_dashboard(uint32_t frame);
void draw_gforces(uint32_t frame);
void draw_compass_ui(uint32_t frame);
void draw_drift(uint32_t frame);
void draw_drag(uint32_t frame);
void draw_accel(uint32_t frame);
void draw_crawling(uint32_t frame);
void draw_lap(uint32_t frame);
void draw_diagnostics(uint32_t frame);
void draw_settings(uint32_t frame);

// Helpers Crawling (tilt normalis� + seuils utilisateur)
float  crawling_get_tilt_now();
float  crawling_get_warnTilt();
float  crawling_get_dangerTilt();
void   crawling_adjust_warn(int dir);
void   crawling_adjust_danger(int dir);
void   crawling_set_param_sel(uint8_t sel);
void   draw_crawling(uint32_t frame);
void accel_handle_serial(int c);
void drag_handle_serial(int c);
bool drift_state_active();
bool drift_state_flash_or_fire();

// Aliases pour l'�tat DRIFT (utilis�s dans loop pour la LED bicolore)
#define gDriftActive       drift_state_active()
#define gDriftFlashActive  drift_state_flash_or_fire()
#define gFireworksActive   (false)













#define PIN_CLK   PIN_OLED_SCLK
#define PIN_MOSI  PIN_OLED_MOSI
#define PIN_CS    PIN_OLED_CS


enum ModeID {
  MODE_MENU = 0,
  MODE_DASHBOARD = 1,
  MODE_GFORCES = 2,
  MODE_ACCEL = 3,
  MODE_DRAG = 4,
  MODE_LAP = 5,
  MODE_CRAWLING = 6,
  MODE_DRIFT = 7,
  MODE_COMPASS = 8,
  MODE_DIAGNOSTICS = 9,
  MODE_SETTINGS = 10,
  MODE_DYNO = 11,
  MODE_BENCH = 12,
  MODE_COUNT = 13
};

struct ModeInfo {
  const char* name;
  const char* fullName;
  const char* category;
  bool implemented;
};

ModeInfo gModes[MODE_COUNT] = {
  {"Menu",        "Main Menu",           "System",      true},
  {"Dashboard",   "Dashboard+",          "Info",        true},
  {"G-Forces",    "G-Forces+",           "Performance", true},
  {"Accel",       "Accel Test 0-100",    "Test",        true},
  {"Drag",        "Drag & Launch",       "Course",      true},
  {"Lap",         "Lap Timer",           "Circuit",     true},
  {"Crawling",    "Crawling Mode",       "Off-road",    true},
  {"Drift",       "Drift Analyzer",      "Style",       true},
  {"Compass",     "Compass",             "Navigation",  true},
  {"Diagnostics", "Diagnostics+",        "Debug",       false},  // accessible via Settings
  {"Settings",    "Settings",            "Config",      true},
  {"Dyno",        "Dynamometer",         "Puissance",   false},
  {"Bench",       "Test Bench",          "Test",        false}
};

int gCurrentMode = MODE_MENU;
int gMenuSelection = MODE_DASHBOARD;
int gSettingsSelection = 0;  // 0=Config, 1=Diag, 2=Bench, 3=Prefs
bool gSettingsInConfig = false;

// Main menu ordering (liste des modes visibles en haut niveau, hors Menu lui-même).
static const int kMainMenuOrder[] = {
  MODE_DASHBOARD,
  MODE_GFORCES,
  MODE_ACCEL,
  MODE_DRAG,
  MODE_LAP,
  MODE_CRAWLING,
  MODE_DRIFT,
  MODE_COMPASS,
  MODE_SETTINGS
};
static const int kMainMenuCount = sizeof(kMainMenuOrder) / sizeof(kMainMenuOrder[0]);

int menu_index_from_mode(int mode)
{
  for (int i = 0; i < kMainMenuCount; ++i) {
    if (kMainMenuOrder[i] == mode) return i;
  }
  return 0;
}

int menu_prev_mode(int mode)
{
  int idx = menu_index_from_mode(mode);
  idx = (idx - 1 + kMainMenuCount) % kMainMenuCount;
  return kMainMenuOrder[idx];
}

int menu_next_mode(int mode)
{
  int idx = menu_index_from_mode(mode);
  idx = (idx + 1) % kMainMenuCount;
  return kMainMenuOrder[idx];
}



static inline void led_set(bool green_on, bool red_on){
  pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_GREEN, !green_on);
  pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_RED,   !red_on);
}

LGFX_Sprite canvas;
uint16_t colGray(uint8_t g){ return canvas.color565(g,g,g); }
int16_t sinLUT[256];
void buildSinTable(){ for(int i=0;i<256;++i) sinLUT[i] = (int16_t)(sin(i * TWO_PI / 256.0) * 127.0); }
static uint32_t gFrames=0,gLastFPS=0,gFPStimer=0;
uint32_t g_lastFpsValue = 0;
static bool     gTripleBtnActive   = false;
static uint32_t gTripleBtnStartMs  = 0;

static uint8_t  s_crawlParamSel    = 0;   // mirror for Crawling param selection (Pmax/Rmax)

static inline void drawBarV(int x, int y, int w, int h, int value, uint16_t colFill, uint16_t colBack) {
  if (value < 0) value = 0;
  if (value > h) value = h;
  canvas.fillRect(x, y, w, h, colBack);
  if (value > 0) {
    canvas.fillRect(x + 1, y + (h - value), w - 2, value, colFill);
  }
  canvas.drawRect(x, y, w, h, colBack);
}






// Legacy Compass implementation (now in src/ui/ui_compass.cpp).
#if 0
static void draw_compass(uint32_t frame) {
  canvas.fillScreen(canvas.color565(0,0,0));


  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString("Compass", 2, 1);


  {
    int y = 1, s = 5, gap = 2;
    int total = s*4 + gap*3;
    int x = 256 - total - 1;
    bool gps_ok = ((frame/60) % 6) != 0;
    bool obd_ok = true;
    bool imu_ok = ((frame/90) % 7) != 0;
    bool rtc_ok = true;
    uint16_t ON = colGray(192), OFF = colGray(64), RIM = colGray(96);
    auto led = [&](int xx, bool on){ int cxr=xx+s/2, cyr=y+s/2; canvas.fillCircle(cxr,cyr,2,on?ON:OFF); canvas.drawCircle(cxr,cyr,2,RIM); };
    led(x, gps_ok); x+=s+gap; led(x, obd_ok); x+=s+gap; led(x, imu_ok); x+=s+gap; led(x, rtc_ok);
  }


  float t = frame * 0.005f;
  float heading = fmodf(t * 30.0f, 360.0f);
  float elevation = 5.0f + sinf(t * 0.8f) * 8.0f;
#ifdef USE_DATA_FUSION
  { AxionData D; data_fusion_snapshot(D); heading = D.heading_deg; elevation = D.gyro_deg[1]; if (elevation < -30.0f) elevation = -30.0f; if (elevation > 30.0f) elevation = 30.0f; }
#endif


  const int compassY = 11;
  const int compassH = 22;
  const int compassCenterX = 128;


  canvas.fillRect(0, compassY, 256, compassH, colGray(20));
  const uint16_t dotCol = colGray(32);
  for (int yy = compassY; yy < compassY + compassH; ++yy) {
    int startX = ((yy - compassY) & 1);
    for (int xx = startX; xx < 256; xx += 2) {
      canvas.drawPixel(xx, yy, dotCol);
    }
  }

  canvas.drawFastHLine(0, compassY, 256, colGray(128));


  int cardinalAngles[8] = {0, 45, 90, 135, 180, 225, 270, 315};
  for (int i = 0; i < 8; i++) {
    float angleDiff = (float)cardinalAngles[i] - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 5 && offsetX <= 251) {
        bool isCardinal = (i % 2 == 0);
        uint16_t tickCol = isCardinal ? colGray(255) : colGray(192);
        canvas.drawFastVLine(offsetX+1, compassY + 1, 8, colGray(64));
        canvas.drawFastVLine(offsetX,   compassY + 1, 8, tickCol);
      }
    }
  }


  for (int deg = 0; deg < 360; deg += 30) {
    bool skip = false;
    for (int i = 0; i < 8; i++) {
      if (deg == cardinalAngles[i]) { skip = true; break; }
    }
    if (skip) continue;

    float angleDiff = (float)deg - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 5 && offsetX <= 251) {
        canvas.drawFastVLine(offsetX+1, compassY + 1, 6, colGray(48));
        canvas.drawFastVLine(offsetX,   compassY + 1, 6, colGray(128));
      }
    }
  }


  for (int deg = 0; deg < 360; deg += 10) {
    if (deg % 30 == 0) continue;
    float angleDiff = (float)deg - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 5 && offsetX <= 251) {
        canvas.drawFastVLine(offsetX, compassY + 1, 4, colGray(96));
      }
    }
  }


  const char* cardinalLabels[8] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
  for (int i = 0; i < 8; i++) {
    float angleDiff = (float)cardinalAngles[i] - heading;
    while (angleDiff > 180.0f) angleDiff -= 360.0f;
    while (angleDiff < -180.0f) angleDiff += 360.0f;
    if (angleDiff >= -90.0f && angleDiff <= 90.0f) {
      int offsetX = compassCenterX + (int)(angleDiff * 2.0f);
      if (offsetX >= 15 && offsetX <= 241) {
        bool isCardinal = (i % 2 == 0);
        if (isCardinal) {
          canvas.setFont(&fonts::Font2);
          canvas.setTextDatum(top_center);
          canvas.setTextColor(colGray(48));
          canvas.drawString(cardinalLabels[i], offsetX+1, compassY + 11);
          canvas.setTextColor(colGray(255));
          canvas.drawString(cardinalLabels[i], offsetX,   compassY + 10);
          canvas.drawString(cardinalLabels[i], offsetX+1, compassY + 10);
          canvas.drawString(cardinalLabels[i], offsetX,   compassY + 11);
        } else {
          canvas.setFont(&fonts::Font0);
          canvas.setTextDatum(top_center);
          canvas.setTextColor(colGray(48));
          canvas.drawString(cardinalLabels[i], offsetX+1, compassY + 11);
          canvas.setTextColor(colGray(192));
          canvas.drawString(cardinalLabels[i], offsetX,   compassY + 10);
        }
      }
    }
  }


  int triY = compassY - 6;
  canvas.fillTriangle(compassCenterX, triY + 6,
                      compassCenterX - 5, triY,
                      compassCenterX + 5, triY,
                      colGray(255));
  canvas.drawTriangle(compassCenterX, triY + 6,
                      compassCenterX - 5, triY,
                      compassCenterX + 5, triY,
                      colGray(192));


  char headStr[8];
  snprintf(headStr, sizeof(headStr), "%03d", (int)heading);
  canvas.setFont(&fonts::Font2);
  canvas.setTextDatum(middle_center);
  canvas.setTextColor(colGray(64));
  canvas.drawString(headStr, 129, 45);
  canvas.setTextColor(colGray(255));
  canvas.drawString(headStr, 128, 44);
  canvas.drawString(headStr, 129, 44);
  canvas.drawString(headStr, 128, 45);
  canvas.drawString(headStr, 129, 45);
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.drawString("o", 148, 42);


  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(bottom_left);
  canvas.drawString("ELEV", 4, 54);
  canvas.setTextColor(colGray(255));
  char elevStr[8];
  snprintf(elevStr, sizeof(elevStr), "%+.1f", elevation);
  canvas.drawString(elevStr, 4, 63);
  canvas.setTextColor(colGray(160));
  canvas.drawString("o", 4 + canvas.textWidth(elevStr), 63);


  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(160));
  canvas.setTextDatum(bottom_right);
  canvas.drawString("GPS", 252, 54);
  float lat = 47.5456f + sinf(t * 0.3f) * 0.0001f;
  float lon = -64.8234f + cosf(t * 0.25f) * 0.0001f;
#ifdef USE_DATA_FUSION
  { AxionData D; data_fusion_snapshot(D); lat = D.lat; lon = D.lon; }
#endif
  canvas.setTextColor(colGray(192));
  char coordStr[24];
  snprintf(coordStr, sizeof(coordStr), "%.4fN %.4fW", lat, fabsf(lon));
  canvas.drawString(coordStr, 252, 63);
}
#endif



// Legacy Drift helpers & drawing kept here for reference.
// Active implementation lives in src/ui/ui_drift.cpp.
#if 0
static inline uint16_t TONE_BODY_HI() { return colGray(240); }
static inline uint16_t TONE_BODY()    { return colGray(200); }
static inline uint16_t TONE_SHADOW()  { return colGray(120); }
static inline uint16_t TONE_DARK()    { return colGray(60);  }


static inline void fillQuadRot(
  int cx, int cy, float ca, float sa,
  float x1,float y1, float x2,float y2, float x3,float y3, float x4,float y4,
  uint16_t col
){
  auto RX = [&](float x,float y){ return cx + (int)(x*ca - y*sa); };
  auto RY = [&](float x,float y){ return cy + (int)(x*sa + y*ca); };
  canvas.fillTriangle(RX(x1,y1),RY(x1,y1), RX(x2,y2),RY(x2,y2), RX(x3,y3),RY(x3,y3), col);
  canvas.fillTriangle(RX(x1,y1),RY(x1,y1), RX(x3,y3),RY(x3,y3), RX(x4,y4),RY(x4,y4), col);
}


static void drawCarTop4Tones(int cx, int cy, float angleDeg)
{
  float ar = angleDeg * DEG_TO_RAD;
  float ca = cosf(ar), sa = sinf(ar);
  const int halfW = 9;
  const int halfH = 19;

  const int pivotOffset = halfH - 8;
  auto RX = [&](float x,float y){
    float yShifted = y + pivotOffset;
    return cx + (int)(x*ca - yShifted*sa);
  };
  auto RY = [&](float x,float y){
    float yShifted = y + pivotOffset;
    return cy + (int)(x*sa + yShifted*ca);
  };

  uint16_t BODY   = colGray(150);
  uint16_t BODYHI = colGray(190);
  uint16_t SHADE  = colGray(90);


  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2), BODY);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2),
                      RX(-halfW+5, -halfH+2), RY(-halfW+5, -halfH+2), BODY);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(-halfW+3, -halfH+6), RY(-halfW+3, -halfH+6),
                      RX(-halfW+3, -halfH+2), RY(-halfW+3, -halfH+2), BODY);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(-halfW+3, -halfH+2), RY(-halfW+3, -halfH+2),
                      RX(-halfW+5, -halfH+2), RY(-halfW+5, -halfH+2), BODY);
  canvas.fillTriangle(RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-3, -halfH+6),  RY(halfW-3, -halfH+6),
                      RX(halfW-3, -halfH+2),  RY(halfW-3, -halfH+2), BODY);
  canvas.fillTriangle(RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-3, -halfH+2),  RY(halfW-3, -halfH+2),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2), BODY);


  canvas.fillTriangle(RX(-halfW, -halfH+6), RY(-halfW, -halfH+6),
                      RX(halfW, -halfH+6),   RY(halfW, -halfH+6),
                      RX(halfW, halfH-4),    RY(halfW, halfH-4), BODY);
  canvas.fillTriangle(RX(-halfW, -halfH+6), RY(-halfW, -halfH+6),
                      RX(halfW, halfH-4),    RY(halfW, halfH-4),
                      RX(-halfW, halfH-4),   RY(-halfW, halfH-4), BODY);


  canvas.fillTriangle(RX(-halfW+2, halfH-4), RY(-halfW+2, halfH-4),
                      RX(halfW-2, halfH-4),  RY(halfW-2, halfH-4),
                      RX(halfW-2, halfH),    RY(halfW-2, halfH), BODY);
  canvas.fillTriangle(RX(-halfW+2, halfH-4), RY(-halfW+2, halfH-4),
                      RX(halfW-2, halfH),    RY(halfW-2, halfH),
                      RX(-halfW+2, halfH),   RY(-halfW+2, halfH), BODY);


  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+8),  RY(halfW-5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2), BODYHI);
  canvas.fillTriangle(RX(-halfW+5, -halfH+8), RY(-halfW+5, -halfH+8),
                      RX(halfW-5, -halfH+2),  RY(halfW-5, -halfH+2),
                      RX(-halfW+5, -halfH+2), RY(-halfW+5, -halfH+2), BODYHI);


  canvas.fillTriangle(RX(-halfW+3, -3), RY(-halfW+3, -3),
                      RX(halfW-3, -3),  RY(halfW-3, -3),
                      RX(halfW-3, 7),   RY(halfW-3, 7), SHADE);
  canvas.fillTriangle(RX(-halfW+3, -3), RY(-halfW+3, -3),
                      RX(halfW-3, 7),   RY(halfW-3, 7),
                      RX(-halfW+3, 7),  RY(-halfW+3, 7), SHADE);


  int rx1 = RX(-halfW-1, -halfH+8);
  int ry1 = RY(-halfW-1, -halfH+8);
  canvas.fillRect(rx1-1, ry1-2, 2, 5, TONE_DARK());
  canvas.drawRect(rx1-1, ry1-2, 2, 5, colGray(160));
  int rx2 = RX(halfW+1, -halfH+8);
  int ry2 = RY(halfW+1, -halfH+8);
  canvas.fillRect(rx2-1, ry2-2, 2, 5, TONE_DARK());
  canvas.drawRect(rx2-1, ry2-2, 2, 5, colGray(160));

  float wheelBackLeftX = -halfW-1;
  float wheelBackLeftY = halfH-8;
  float wheelBackRightX = halfW+1;
  float wheelBackRightY = halfH-8;

  int wx1 = RX(wheelBackLeftX-1, wheelBackLeftY-2.5f);
  int wy1 = RY(wheelBackLeftX-1, wheelBackLeftY-2.5f);
  int wx2 = RX(wheelBackLeftX+1, wheelBackLeftY-2.5f);
  int wy2 = RY(wheelBackLeftX+1, wheelBackLeftY-2.5f);
  int wx3 = RX(wheelBackLeftX+1, wheelBackLeftY+2.5f);
  int wy3 = RY(wheelBackLeftX+1, wheelBackLeftY+2.5f);
  int wx4 = RX(wheelBackLeftX-1, wheelBackLeftY+2.5f);
  int wy4 = RY(wheelBackLeftX-1, wheelBackLeftY+2.5f);
  canvas.fillTriangle(wx1, wy1, wx2, wy2, wx3, wy3, TONE_DARK());
  canvas.fillTriangle(wx1, wy1, wx3, wy3, wx4, wy4, TONE_DARK());
  canvas.drawLine(wx1, wy1, wx2, wy2, colGray(160));
  canvas.drawLine(wx2, wy2, wx3, wy3, colGray(160));
  canvas.drawLine(wx3, wy3, wx4, wy4, colGray(160));
  canvas.drawLine(wx4, wy4, wx1, wy1, colGray(160));

  int wx5 = RX(wheelBackRightX-1, wheelBackRightY-2.5f);
  int wy5 = RY(wheelBackRightX-1, wheelBackRightY-2.5f);
  int wx6 = RX(wheelBackRightX+1, wheelBackRightY-2.5f);
  int wy6 = RY(wheelBackRightX+1, wheelBackRightY-2.5f);
  int wx7 = RX(wheelBackRightX+1, wheelBackRightY+2.5f);
  int wy7 = RY(wheelBackRightX+1, wheelBackRightY+2.5f);
  int wx8 = RX(wheelBackRightX-1, wheelBackRightY+2.5f);
  int wy8 = RY(wheelBackRightX-1, wheelBackRightY+2.5f);
  canvas.fillTriangle(wx5, wy5, wx6, wy6, wx7, wy7, TONE_DARK());
  canvas.fillTriangle(wx5, wy5, wx7, wy7, wx8, wy8, TONE_DARK());
  canvas.drawLine(wx5, wy5, wx6, wy6, colGray(160));
  canvas.drawLine(wx6, wy6, wx7, wy7, colGray(160));
  canvas.drawLine(wx7, wy7, wx8, wy8, colGray(160));
  canvas.drawLine(wx8, wy8, wx5, wy5, colGray(160));


  canvas.fillCircle(RX(-halfW+4, -halfH+4), RY(-halfW+4, -halfH+4), 1, BODYHI);
  canvas.fillCircle(RX(halfW-4, -halfH+4),  RY(halfW-4, -halfH+4),  1, BODYHI);
  canvas.drawPixel(RX(-halfW+2, halfH-1), RY(-halfW+2, halfH-1), colGray(180));
  canvas.drawPixel(RX(halfW-2, halfH-1),  RY(halfW-2, halfH-1),  colGray(180));

  canvas.drawLine(RX(-halfW, -halfH+6), RY(-halfW, -halfH+6), RX(-halfW, halfH-4), RY(-halfW, halfH-4), TONE_DARK());
  canvas.drawLine(RX(halfW, -halfH+6),  RY(halfW, -halfH+6),  RX(halfW, halfH-4),  RY(halfW, halfH-4),  TONE_DARK());
  canvas.drawLine(RX(-halfW+3, -halfH+1), RY(-halfW+3, -halfH+1), RX(halfW-3, -halfH+1), RY(halfW-3, -halfH+1), TONE_DARK());
}


#if 0
// Legacy Drift state + renderer kept here for reference.
// Active implementation now lives in src/ui/ui_drift.cpp.
#if 0
static uint32_t gDriftScore = 0;
static uint32_t gDriftCurrentScore = 0;
static float     gDriftMultiplier = 1.0f;
static float     gDriftAngle = 0.0f;
static float     gDriftDuration = 0.0f;
static uint32_t  gDriftStartMs = 0;
static bool      gDriftActive = false;
static uint32_t  gLastDriftEndMs = 0;
static int       gDriftComboCount = 0;
static uint32_t  gSessionStartMs = 0;

static bool      gDriftFlashActive = false;
static uint32_t  gDriftFlashStart  = 0;

static uint8_t tireTrail[256 * 64];
static bool    trailInit = false;

struct Fx { int x, y; };
static bool gFireworksActive  = false;
static const uint32_t gFireworksDuration = 2500;

static void draw_drift(uint32_t frame) {

  canvas.fillScreen(canvas.color565(0,0,0));
  const uint16_t dotColBg = colGray(24);
  for (int yy = 10; yy < 60; ++yy) {
    int sxL = ((yy - 10) & 1);
    for (int xx = sxL; xx < 85; xx += 2) canvas.drawPixel(xx, yy, dotColBg);
    int sxR = 175 + ((yy - 10) & 1);
    for (int xx = sxR; xx < 256; xx += 2) canvas.drawPixel(xx, yy, dotColBg);
  }


  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString("Drift", 2, 1);
  {
    int y = 1, s = 5, gap = 2;
    int total = s*4 + gap*3;
    int x = 256 - total - 1;
    bool gps_ok = ((frame/60) % 6) != 0;
    bool obd_ok = true;
    bool imu_ok = ((frame/90) % 7) != 0;
    bool rtc_ok = true;
    uint16_t ON = colGray(192), OFF = colGray(64), RIM = colGray(96);
    auto led=[&](int xx,bool on){int cxr=xx+s/2, cyr=y+s/2; canvas.fillCircle(cxr,cyr,2,on?ON:OFF); canvas.drawCircle(cxr,cyr,2,RIM);};
    led(x, gps_ok); x+=s+gap; led(x, obd_ok); x+=s+gap; led(x, imu_ok); x+=s+gap; led(x, rtc_ok);
  }

  if (gSessionStartMs == 0) gSessionStartMs = millis();


  static uint32_t t0_speed = 0; if (!t0_speed) t0_speed = millis();
  float phase2 = ((millis() - t0_speed) % 20000) / 10000.0f; 
  float tri    = (phase2 <= 1.0f) ? phase2 : (2.0f - phase2); 
  int   speedKmh = (int)(tri * 220.0f + 0.5f);
#ifdef USE_DATA_FUSION
  { AxionData D; data_fusion_snapshot(D); speedKmh = (int)(D.speed_kmh + 0.5f); }
#endif

  float t = frame * 0.02f;
  float latG = sinf(t*0.5f) * 1.5f;           
#ifdef USE_DATA_FUSION
  { AxionData D; data_fusion_snapshot(D); latG = D.accel_g[1]; if (latG < -1.5f) latG = -1.5f; if (latG > 1.5f) latG = 1.5f; }
#endif
  gDriftAngle = fabsf(latG) * 30.0f;          


  bool driftingNow = (gDriftAngle > 15.0f && speedKmh > 50);
  if (driftingNow) {
    if (!gDriftActive) {
      gDriftActive       = true;
      gDriftStartMs      = millis();
      gDriftCurrentScore = 0;
      gDriftFlashActive  = false;
      gFireworksActive   = false;
      if (gLastDriftEndMs > 0 && (millis() - gLastDriftEndMs) < 2000) gDriftComboCount++;
      else gDriftComboCount = 1;
    }
    gDriftDuration = (millis() - gDriftStartMs) / 1000.0f;
    float comboBonus    = 1.0f + (gDriftComboCount - 1) * 0.5f;
    float durationBonus = 1.0f + (gDriftDuration * 0.2f);
    gDriftMultiplier = comboBonus * durationBonus;
    if (gDriftMultiplier > 5.0f) gDriftMultiplier = 5.0f;
    uint32_t pts = (uint32_t)((gDriftAngle * speedKmh * gDriftMultiplier) / 5000.0f);
    gDriftCurrentScore += pts;
  }
  if (!driftingNow && gDriftActive) {
    gDriftActive = false;
    gDriftScore += gDriftCurrentScore;
    gLastDriftEndMs = millis();
    gDriftMultiplier = 1.0f;
    gDriftDuration   = 0.0f;
    if (gDriftCurrentScore > 100) {
      gDriftFlashActive = true;
      gDriftFlashStart  = millis();
    }
  }


  int roadX=42, roadW=54, roadY=0, roadH=64;
  int roadCenterX = roadX + roadW/2;
  canvas.drawFastVLine(roadX, roadY, roadH, colGray(96));
  canvas.drawFastVLine(roadX+roadW, roadY, roadH, colGray(96));
  static uint32_t t0_road=0; if (!t0_road) t0_road=millis();
  float phaseRoad = ((millis()-t0_road)%20000)/10000.0f;
  float triRoad   = (phaseRoad <= 1.0f) ? phaseRoad : (2.0f - phaseRoad);
  int speedRoad   = (int)(triRoad * 220.0f + 0.5f);
  int dashSpeed = (speedRoad>0) ? ((int)((speedRoad/220.0f)*14.0f) + 1) : 0;
  int dashOffset = (dashSpeed>0) ? (int)((millis() / (45 / dashSpeed)) % 12) : 0;
  for (int dy=roadY; dy<roadY+roadH; dy+=6) {
    int segY = dy + dashOffset;
    if (segY >= roadY && segY < roadY+roadH-3)
      canvas.drawFastVLine(roadCenterX, segY, 3, colGray(128));
  }


  int cx = roadCenterX, cy = 20;
  float driftDir = (latG < 0) ? -gDriftAngle : gDriftAngle;
  float carAngle = constrain(driftDir, -60.0f, 60.0f);


  if (!trailInit) { memset(tireTrail, 0, sizeof(tireTrail)); trailInit = true; }
  static uint8_t scrolledTrail[256 * 64];
  memset(scrolledTrail, 0, sizeof(scrolledTrail));

  static int roadScroll = 0;
  roadScroll = (roadScroll + dashSpeed) % 64;
  int scrollOffset = (roadScroll / 3) % 64;

  for (int y=0; y<64; y++) {
    int srcY = y - scrollOffset;
    if (srcY >= 0) memcpy(&scrolledTrail[y*256], &tireTrail[srcY*256], 256);
  }
  for (int i=0;i<256*64;i++) {
    uint8_t v = scrolledTrail[i];
    scrolledTrail[i] = (v>3) ? (uint8_t)(v-3) : 0;
  }

  if (fabsf(carAngle) > 8.0f) {
    auto worldFromLocal=[&](float x,float y,float ang,int Cx,int Cy){
      const int pivotOffset = 19 - 8;
      float ar=ang*DEG_TO_RAD, ca=cosf(ar), sa=sinf(ar);
      float ys=y + pivotOffset;
      int X = Cx + (int)(x*ca - ys*sa);
      int Y = Cy + (int)(x*sa + ys*ca);
      return std::pair<int,int>(X,Y);
    };
    const int halfW=11, halfH=19;
    const float yRearAxle = halfH - 8;
    const float tireHalfLen = 2.5f;
    const float yRearEdge = yRearAxle + tireHalfLen;
    const float xLeft  = -(halfW+1);
    const float xRight =  (halfW+1);
    auto L = worldFromLocal(xLeft,  yRearEdge, carAngle, cx, cy);
    auto R = worldFromLocal(xRight, yRearEdge, carAngle, cx, cy);
    auto stampTrail=[&](int sx,int sy,float ang){
      float ar=ang*DEG_TO_RAD, ca=cosf(ar), sa=sinf(ar);
      const int trailLen=6;
      for (int i=0;i<trailLen;++i){
        float dx = -1.0f * sa * i;
        float dy =  1.0f * ca * i;
        int bx = sx + (int)roundf(dx);
        int by = sy + (int)roundf(dy);
        for (int ox=-1; ox<=1; ++ox){
          for (int oy=-1; oy<=1; ++oy){
            int px=bx+ox, py=by+oy;
            if ((unsigned)px<256 && (unsigned)py<64){
              uint8_t val = (uint8_t)(220 - i*20);
              uint8_t& cell = scrolledTrail[py*256 + px];
              if (val > cell) cell = val;
            }
          }
        }
      }
    };
    stampTrail(L.first, L.second, carAngle);
    stampTrail(R.first, R.second, carAngle);
  }


  {
    uint8_t* buf = (uint8_t*)canvas.getBuffer();
    for (int i=0;i<256*64;i++){
      uint16_t blended = buf[i] + (scrolledTrail[i]>>1);
      buf[i] = (blended>255)?255:(uint8_t)blended;
    }
    memcpy(tireTrail, scrolledTrail, sizeof(tireTrail));
  }


  drawCarTop4Tones(cx, cy, carAngle);


  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(153));
    canvas.setTextDatum(top_left);
    canvas.drawString("ANGLE", 2, 12);
    char angleStr[8];
    snprintf(angleStr, sizeof(angleStr), "%d", (int)gDriftAngle);
    canvas.setFont(&fonts::Font2);
    canvas.setTextColor(colGray(255));
    canvas.drawString(angleStr, 2, 20);
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(136));
    int angleWidth = canvas.textWidth(angleStr, &fonts::Font2);
    canvas.drawString("o", 2 + angleWidth + 2, 22);
  }


  {
    static float lastDriftDuration = 0.0f;
    if (gDriftActive) lastDriftDuration = gDriftDuration;
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(153));
    canvas.setTextDatum(top_left);
    canvas.drawString("DUREE", 2, 40);
    canvas.setFont(&fonts::Font2);
    canvas.setTextColor(colGray(255));
    char durStr[8];
    snprintf(durStr, sizeof(durStr), "%.1f", gDriftActive ? gDriftDuration : lastDriftDuration);
    canvas.drawString(durStr, 2, 48);
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(136));
    canvas.drawString("s", 2 + canvas.textWidth(durStr, &fonts::Font2) + 2, 50);
  }


  {
    const int scoreY=0, scoreH=64;
    const uint16_t dotCol = colGray(40);
    int comboW = canvas.textWidth("COMBO");
    int tramEndX = (254 - comboW) - 2;
    if (!gFireworksActive) {
      for (int yy=scoreY; yy<scoreY+scoreH; ++yy) {
        int sx = 98 + ((yy - scoreY) & 1);
        for (int xx=sx; xx<tramEndX; xx+=2) canvas.drawPixel(xx, yy, dotCol);
      }
    }

    uint32_t now = millis();
    if (gDriftFlashActive) {
      uint32_t elapsed = now - gDriftFlashStart;
      uint16_t col = colGray(255);
      if (gDriftCurrentScore <= 100) {
        gDriftFlashActive = false;
        canvas.setTextColor(colGray(255));
      } else if (gDriftCurrentScore <= 300) {
        bool grayPhase = ((elapsed / 180) % 2) == 1;
        col = grayPhase ? colGray(96) : colGray(255);
        if (elapsed > 180 * 2 * 3) gDriftFlashActive = false;
        canvas.setTextColor(col);
      } else if (gDriftCurrentScore <= 500) {
        bool grayPhase = ((elapsed / 180) % 2) == 1;
        col = grayPhase ? colGray(96) : colGray(255);
        if (elapsed > 180 * 2 * 5) gDriftFlashActive = false;
        canvas.setTextColor(col);
      } else {
        int phase = (elapsed / 180) % 3;
        if (phase == 0)      col = colGray(96);
        else if (phase == 1) col = colGray(255);
        else                 col = colGray(0);
        if (elapsed > 180 * 3 * 5) gDriftFlashActive = false;
        canvas.setTextColor(col);
      }
    } else {
      bool pulse = gDriftActive && ((millis() / 200) & 1);
      canvas.setTextColor(pulse ? colGray(255) : colGray(200));
    }

    canvas.setFont(&Race_Sport24pt7b);
    uint32_t scoreVal = gDriftCurrentScore; if (scoreVal > 99999) scoreVal = 99999;
    int d5 = scoreVal / 10000;
    int d4 = (scoreVal / 1000) % 10;
    int d3 = (scoreVal / 100) % 10;
    int d2 = (scoreVal / 10) % 10;
    int d1 = scoreVal % 10;
    int wDigit=20, spacing=15, centerX=151;
    auto offsetIfOne=[&](int d,bool alignRight){ return (d==1)? (alignRight?18:-4) : 0; };
    int baselineRef = 47;
    int drawY = baselineRef - canvas.fontHeight();
    int numDigits = (scoreVal>=10000)?5 : (scoreVal>=1000)?4 : (scoreVal>=100)?3 : (scoreVal>=10)?2 : 1;
    int xStart = centerX - ((numDigits * (wDigit + spacing)) / 2) + (wDigit/2);
    int xPos = xStart;
    if (d5>0){ char c[2]={(char)('0'+d5),0}; canvas.drawString(c, xPos + offsetIfOne(d5,true), drawY); xPos+=wDigit+spacing; }
    if (scoreVal>=1000){ char c[2]={(char)('0'+d4),0}; canvas.drawString(c, xPos + offsetIfOne(d4,true), drawY); xPos+=wDigit+spacing; }
    if (scoreVal>=100){  char c[2]={(char)('0'+d3),0}; canvas.drawString(c, xPos + offsetIfOne(d3,true), drawY); xPos+=wDigit+spacing; }
    if (scoreVal>=10){   char c[2]={(char)('0'+d2),0}; canvas.drawString(c, xPos + offsetIfOne(d2,true), drawY); xPos+=wDigit+spacing; }
    { char c[2]={(char)('0'+d1),0}; int adj=offsetIfOne(d1,false); if(d1==1) adj+=6; canvas.drawString(c, xPos+adj, drawY); }
  }


  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray( (gDriftComboCount>1)?255:153 ));
    canvas.setTextDatum(top_right);
    canvas.drawString((gDriftComboCount>1)?"COMBO":"MULTI", 254, 12);
    canvas.setFont(&fonts::Font2);
    canvas.setTextColor(colGray(255));
    canvas.setTextDatum(top_right);
    char multStr[12];
    if (gDriftComboCount>1) snprintf(multStr, sizeof(multStr), "X%d", gDriftComboCount);
    else                    snprintf(multStr, sizeof(multStr), "X%.1f", gDriftMultiplier);
    canvas.drawString(multStr, 254, 22);
    canvas.drawString(multStr, 255, 22);
    canvas.drawString(multStr, 254, 23);
  }


  {
    int bx=144, by=45;
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(top_left);
    if (gDriftActive) {
      if (gDriftComboCount>=3) { canvas.setTextColor(colGray(255)); canvas.drawString("CHAIN!", bx, by); canvas.drawString("CHAIN!", bx+1, by); }
      else if (gDriftAngle>45.0f) { canvas.setTextColor(colGray(255)); canvas.drawString("PERFECT", bx, by); canvas.drawString("PERFECT", bx+1, by); }
      else if (gDriftDuration>3.0f){ canvas.setTextColor(colGray(255)); canvas.drawString("LONG", bx, by); canvas.drawString("LONG", bx+1, by); }
      else if (speedKmh>150)      { canvas.setTextColor(colGray(255)); canvas.drawString("SPEED", bx, by); canvas.drawString("SPEED", bx+1, by); }
    }
  }


  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_left);
    canvas.drawString("TOTAL", 98, 54);
    canvas.setTextColor(colGray(255));
    char totalStr[12]; snprintf(totalStr, sizeof(totalStr), "%lu", (unsigned long)gDriftScore);
    canvas.drawString(totalStr, 102, 63);
  }
  {
    int comboW = canvas.textWidth("COMBO");
    int tramEndX = (254 - comboW) - 2;
    uint32_t sessionMs = millis() - gSessionStartMs;
    int minutes = (sessionMs/1000)/60;
    int seconds = (sessionMs/1000)%60;
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_right);
    canvas.drawString("TIME", tramEndX, 54);
    canvas.setTextColor(colGray(255));
    char timeStr[10]; snprintf(timeStr, sizeof(timeStr), "%d:%02d", minutes, seconds);
    canvas.drawString(timeStr, tramEndX, 63);
  }
  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_right);
      canvas.drawString("km/h", 254, 54);
      canvas.setTextColor(colGray(255));
      char speedStr[8]; snprintf(speedStr, sizeof(speedStr), "%d", speedKmh);
      canvas.drawString(speedStr, 254, 63);
    }
  }
#endif
#endif
#endif


// Legacy Drag implementation (now in src/ui/ui_drag.cpp).
#if 0
static bool dragIsLaunch = false;    
static int  dragDistanceMode = 0;    
static bool dragStaging = true;      
static bool dragRunning = false;
static bool dragCompleted = false;
static uint32_t dragStartMs = 0;
static uint32_t dragStageStart = 0;
static float dragElapsed = 0.0f;
static float dragProgress = 0.0f;
static float dragBestTimes[2] = {12.42, 8.25};  


static void draw_drag(uint32_t frame) {
  canvas.fillScreen(colGray(0));


  const int CHRONO_Y_OFFSET = -3;
  const int BAR_Y_BASE      = 53;
  const int BAR_Y_OFFSET    = 7;
  const int BEST_Y_OFFSET   = -1;
  const int splitX = 74;


  if (dragRunning) {
    uint32_t elapsed = millis() - dragStartMs;
    float totalTime = (dragDistanceMode == 0) ? 12000.0f : 6000.0f;
    dragProgress = min(1.0f, (float)elapsed / totalTime);
    dragElapsed = elapsed / 1000.0f;
    if (dragProgress >= 1.0f) {
      dragRunning = false;
      dragCompleted = true;
      dragStaging = true;
    }
  }


  const uint16_t tramDot = colGray(35);
  for (int y = 0; y < 64; ++y) {
    int startX = splitX + ((y & 1) ? 0 : 1);
    for (int x = startX; x < 256; x += 2)
      canvas.drawPixel(x, y, tramDot);
  }
  canvas.drawFastVLine(splitX, 0, 64, colGray(96));


  const char* modeTitle = dragIsLaunch ? "Launch" : "Drag";
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString(modeTitle, 2, 1);


  if (!dragIsLaunch) {
    const char* distLabels[2] = {"1/4", "1/8"};
    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString(distLabels[dragDistanceMode], splitX / 2, 21);
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(180));
    canvas.drawString("mi", splitX / 2, 34);
  } else {
    canvas.setFont(&::FreeSansBoldOblique10pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString("Launch", splitX / 2, 27);
  }


  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(bottom_left);
    int bestX = splitX + 3;
    int bestY = 63 + BEST_Y_OFFSET;
    canvas.setTextColor(colGray(180));
    canvas.drawString("BEST:", bestX, bestY);
    char bestStr[16];
    snprintf(bestStr, sizeof(bestStr), "%.2fs", dragBestTimes[dragDistanceMode]);
    int labelW = canvas.textWidth("BEST:");
    canvas.setTextColor(colGray(255));
    canvas.drawString(bestStr, bestX + labelW + 5, bestY);
  }


  float chronoVal = dragElapsed;
  if (!dragRunning && !dragCompleted) chronoVal = 0.00f;
  int secondsInt = (int)chronoVal;
  int hundredths = (int)roundf((chronoVal - secondsInt) * 100.0f);
  int tensSec = secondsInt / 10;
  int unitsSec = secondsInt % 10;
  int tenths = (hundredths / 10) % 10;
  int hunds  = hundredths % 10;
  const int baseline = 27 + CHRONO_Y_OFFSET;
  const int wDigit = 20, spacing = 15, dotW = 10;
  const int centerX = splitX + (256 - splitX) / 2 - 16;
  const int totalWidth = (wDigit * 4) + (spacing * 4) + dotW;
  const int xStart = centerX - totalWidth / 2;
  canvas.setFont(&Race_Sport24pt7b);
  canvas.setTextColor(colGray(255));
  canvas.setTextDatum(middle_left);
  int x = xStart;
  char strBuf[2];
  strBuf[1] = 0;
  strBuf[0] = '0' + tensSec; canvas.drawString(strBuf, x + 6, baseline); x += wDigit + spacing;
  strBuf[0] = '0' + unitsSec; canvas.drawString(strBuf, x + 6, baseline); x += wDigit + spacing;
  canvas.setFont(&::FreeSansBoldOblique10pt7b);
  canvas.drawString(",", x + 16, baseline + 8); x += dotW + spacing;
  canvas.setFont(&Race_Sport24pt7b);
  strBuf[0] = '0' + tenths; canvas.drawString(strBuf, x, baseline); x += wDigit + spacing;
  strBuf[0] = '0' + hunds;  canvas.drawString(strBuf, x, baseline);
  canvas.setFont(&::FreeSansBoldOblique10pt7b);
  canvas.setTextColor(colGray(200));
  canvas.drawString("s", x + 15, baseline + 3);


  const int barX = splitX + 10;
  const int barY = BAR_Y_BASE - BAR_Y_OFFSET;
  const int barW = 160;
  const int barH = 5;
  const int ledCount = 8;
  const int ledSpacing = barW / ledCount;
  uint16_t colOff = colGray(32);
  uint16_t colOn  = colGray(255);
  uint16_t colMid = colGray(120);


  if (dragStaging && dragStageStart > 0) {
    uint32_t seqElapsed = millis() - dragStageStart;
    int active = seqElapsed / 250; 
    for (int i = 0; i < ledCount; i++) {
      int lx = barX + i * ledSpacing;
      uint16_t c = (i <= active) ? colMid : colOff;
      if (active >= ledCount) {
        dragStaging = false;
        dragRunning = true;
        dragStartMs = millis();
      }
      canvas.fillRect(lx, barY, ledSpacing - 2, barH, c);
    }
  }
  else if (dragRunning) {
    int lit = (int)(ledCount * dragProgress);
    for (int i = 0; i < ledCount; i++) {
      int lx = barX + i * ledSpacing;
      uint16_t c = (i <= lit) ? colOn : colOff;
      canvas.fillRect(lx, barY, ledSpacing - 2, barH, c);
    }
  }
  else if (!dragRunning && !dragCompleted) {

    float seq = fmodf((millis() / 150.0f), ledCount);
    for (int i = 0; i < ledCount; i++) {
      int lx = barX + i * ledSpacing;
      uint16_t c = (seq >= i - 0.5f && seq < i + 0.5f) ? colMid : colOff;
      canvas.fillRect(lx, barY, ledSpacing - 2, barH, c);
    }
  }
  canvas.drawRect(barX, barY, barW, barH, colGray(64));


  canvas.setFont(&fonts::Font0);
  canvas.setTextDatum(bottom_left);
  if (dragCompleted) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("FINISHED", 2, 63);
  } else if (dragRunning) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("GO!", 2, 63);
  } else if (dragStaging && dragStageStart > 0) {
    canvas.setTextColor(colGray(180));
    canvas.drawString("PRE-STAGE", 2, 63);
  } else {
    canvas.setTextColor(colGray(128));
    canvas.drawString("STAGING", 2, 63);
  }
}
#endif




// Legacy Accel implementation (now in src/ui/ui_accel.cpp).
#if 0
static bool accelIsBrake = false;   
static int accelTarget   = 100;     
static bool accelRunning = false;
static bool accelReady = false;
static bool accelCompleted = false;
static uint32_t accelStartMs = 0;
static float accelElapsed = 0.0f;
static float accelSpeedSim = 0.0f;

static float accelBestTimes[4] = {3.82, 4.11, 2.95, 3.54};


static uint32_t lastModeChange = 0;
static int accelModeChangeDir = 0; 


static void draw_accel(uint32_t frame) {
  canvas.fillScreen(colGray(0));



const int CHRONO_Y_OFFSET = -3;   
const int BAR_Y_BASE      = 53;   
const int BAR_Y_OFFSET    = 7;    
const int BEST_Y_OFFSET   = -1;   




  if (accelRunning) {
    uint32_t elapsed = millis() - accelStartMs;
    float ratio = min(1.0f, elapsed / 3000.0f);
    accelSpeedSim = ratio * accelTarget;
#ifdef USE_DATA_FUSION
    { AxionData D; data_fusion_snapshot(D); accelSpeedSim = D.speed_kmh; }
#endif
    accelElapsed = elapsed / 1000.0f;
    if (accelSpeedSim >= accelTarget) {
      accelRunning = false;
      accelCompleted = true;
    }
  } else if (!accelRunning && !accelCompleted) {
    accelSpeedSim = 0;
#ifdef USE_DATA_FUSION
    { AxionData D; data_fusion_snapshot(D); accelSpeedSim = D.speed_kmh; }
#endif
  }


  const int splitX = 74;
  const uint16_t tramDot = colGray(35);
  for (int y = 0; y < 64; ++y) {
    int startX = splitX + ((y & 1) ? 0 : 1);
    for (int x = startX; x < 256; x += 2) canvas.drawPixel(x, y, tramDot);
  }
  canvas.drawFastVLine(splitX, 0, 64, colGray(96));


const char* modeTitle = accelIsBrake ? "Brake" : "Accel";
  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(208));
  canvas.setTextDatum(top_left);
  canvas.drawString(modeTitle, 2, 1);



  static uint8_t flashLeft = 0, flashRight = 0;
  uint32_t now = millis();
  if (now - lastModeChange < 150) {
    flashLeft = (accelModeChangeDir < 0);
    flashRight = (accelModeChangeDir > 0);
  } else flashLeft = flashRight = 0;

  uint8_t arrowLeftCol  = flashLeft  ? 255 : 120;
  uint8_t arrowRightCol = flashRight ? 255 : 120;

  int arrowY = 26;
  canvas.setFont(&fonts::Font0);
  canvas.setTextDatum(middle_left);
  canvas.setTextColor(colGray(arrowLeftCol));
  canvas.drawString("<", 2, arrowY);
  canvas.setTextDatum(middle_right);
  canvas.setTextColor(colGray(arrowRightCol));
  canvas.drawString(">", splitX - 2, arrowY);


  canvas.setFont(&::FreeSansBoldOblique10pt7b);
  canvas.setTextDatum(middle_center);
  canvas.setTextColor(colGray(255));

  char modeStr[16];
  if (accelIsBrake)
    snprintf(modeStr, sizeof(modeStr), "%d-0", accelTarget);
  else
    snprintf(modeStr, sizeof(modeStr), "0-%d", accelTarget);

  canvas.drawString(modeStr, splitX / 2, 21);


  canvas.setFont(&fonts::Font0);
  canvas.setTextColor(colGray(180));
  canvas.drawString("km/h", splitX / 2, 34);




  {
    canvas.setFont(&fonts::Font0);
    canvas.setTextDatum(bottom_left);
    int bestX = splitX + 3;                  
    int bestY = 63 + BEST_Y_OFFSET;          
    canvas.setTextColor(colGray(180));
    canvas.drawString("BEST:", bestX, bestY);

    char bestStr[16];
int idx = accelIsBrake ? 1 : 0;  
if (accelBestTimes[idx] > 0.0f)
  snprintf(bestStr, sizeof(bestStr), "%.2fs", accelBestTimes[idx]);
else
  snprintf(bestStr, sizeof(bestStr), "���");


    int labelW = canvas.textWidth("BEST:");
    canvas.setTextColor(colGray(255));
    canvas.drawString(bestStr, bestX + labelW + 5, bestY);
  }





{

  float chronoVal = accelElapsed;
  if (!accelRunning && !accelCompleted) chronoVal = 0.00f;

  int secondsInt = (int)chronoVal;
  if (secondsInt > 99) secondsInt = 99;
  int tensSec = secondsInt / 10;
  int unitsSec = secondsInt % 10;
  int hundredths = (int)roundf((chronoVal - secondsInt) * 100.0f);
  if (hundredths > 99) hundredths = 99;
  int tenths = (hundredths / 10) % 10;
  int hunds  = hundredths % 10;


const int baseline = 27 + CHRONO_Y_OFFSET;


  const int wDigit   = 20;
  const int spacing  = 15;
  const int dotW     = 10;



  const int centerX = splitX + (256 - splitX) / 2 + 14 - 30; 
  const int totalWidth = (wDigit * 4) + (spacing * 4) + dotW;
  const int xStart = centerX - totalWidth / 2;


  auto adjOne = [](int d, bool alignRight)->int { return (d == 1) ? (alignRight ? 18 : -6) : 0; };


  canvas.setFont(&Race_Sport24pt7b);
  canvas.setTextColor(colGray(255));
  canvas.setTextDatum(middle_left);

  int x = xStart;


{
  char c[2] = {(char)('0' + tensSec), 0};
  int adj = adjOne(tensSec, true);
  canvas.drawString(c, x + 10 + adj + 6, baseline);   
  x += wDigit + spacing;
}


{
  char c[2] = {(char)('0' + unitsSec), 0};
  int adj = adjOne(unitsSec, true);
  canvas.drawString(c, x + 10 + adj + 6, baseline);   
  x += wDigit + spacing;
}

  {

canvas.setFont(&::FreeSansBoldOblique10pt7b);
canvas.setTextColor(colGray(255));
canvas.setTextDatum(middle_left);

const int COMMA_DX = 16;
const int COMMA_DY = 8;


canvas.drawString(",", x + COMMA_DX,     baseline + COMMA_DY);
canvas.drawString(",", x + COMMA_DX + 1, baseline + COMMA_DY);

x += dotW + spacing;

canvas.setFont(&Race_Sport24pt7b);
canvas.setTextColor(colGray(255));
canvas.setTextDatum(middle_left);


  }


  {
    char c[2] = {(char)('0' + tenths), 0};
    int adj = adjOne(tenths, true);
    canvas.drawString(c, x + adj, baseline);
    x += wDigit + spacing;
  }


  {
    char c[2] = {(char)('0' + hunds), 0};
    int adj = adjOne(hunds, false);
    if (hunds == 1) adj += 6;
    canvas.drawString(c, x + adj, baseline);
    x += wDigit;
  }



const int S_DX = 15;
canvas.setFont(&::FreeSansBoldOblique10pt7b);
canvas.setTextColor(colGray(200));
canvas.setTextDatum(top_left);
canvas.drawString("s", x + S_DX, baseline + 3);

}



int barX = splitX + 10;
int barY = BAR_Y_BASE - BAR_Y_OFFSET;  
int barW = 160;
int barH = 5;

  float ratio = accelRunning ? min(1.0f, accelSpeedSim / (float)accelTarget) : 0.0f;
  int filled = (int)(barW * ratio);
  canvas.drawRect(barX, barY, barW, barH, colGray(64));
  if (filled > 0) canvas.fillRect(barX, barY, filled, barH, colGray(255));


  canvas.setTextDatum(bottom_left);
  canvas.setFont(&::FreeSansBoldOblique10pt7b);

  if (accelCompleted) {
    canvas.setTextColor(colGray(255));
    canvas.drawString("DONE", 2, 63);
  } else if (accelRunning) {
    char speedStr[8];
    snprintf(speedStr, sizeof(speedStr), "%.0f", accelSpeedSim);
    canvas.setTextColor(colGray(255));
    canvas.drawString(speedStr, 2, 63);


    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.setTextDatum(bottom_right);
    canvas.drawString("km/h", splitX - 2, 63);
  } else {
    canvas.setTextColor(colGray(180));
    canvas.drawString("READY", 2, 63);
  }


  int y = 1, s = 5, gap = 2;
  int total = s * 4 + gap * 3;
  int x = 256 - total - 1;
  bool gps_ok = ((frame / 60) % 6) != 0;
  bool obd_ok = true;
  bool imu_ok = ((frame / 90) % 7) != 0;
  bool rtc_ok = true;
  uint16_t ON = colGray(192), OFF = colGray(64), RIM = colGray(96);
  auto led = [&](int xx, bool on) {
    int cxr = xx + s / 2, cyr = y + s / 2;
    canvas.fillCircle(cxr, cyr, 2, on ? ON : OFF);
    canvas.drawCircle(cxr, cyr, 2, RIM);
  };
  led(x, gps_ok); x += s + gap;
  led(x, obd_ok); x += s + gap;
  led(x, imu_ok); x += s + gap;
  led(x, rtc_ok);
}
#endif




// Legacy Menu implementation (now in src/ui/ui_menu.cpp).
#if 0
static void draw_menu(uint32_t frame) {
  canvas.fillScreen(colGray(0));

  const int baseW = 128;
  const int baseH = 64;
  const int centerY = 32;
  const int spacing = -70;

  static float scrollOffset = 0.0f;
  static int lastSel = gMenuSelection;
  static uint32_t zoomStart = 0;
  static bool zooming = false;


  if (gMenuSelection < 1) gMenuSelection = MODE_COUNT - 1;
  if (gMenuSelection >= MODE_COUNT) gMenuSelection = 1;

if (gMenuSelection != lastSel) {
  int delta = gMenuSelection - lastSel;   
  if (delta > (MODE_COUNT / 2)) delta -= (MODE_COUNT - 1);
  if (delta < -(MODE_COUNT / 2)) delta += (MODE_COUNT - 1);
  scrollOffset += (float)delta;           
  lastSel = gMenuSelection;
  zoomStart = millis();
  zooming = true;
}


  scrollOffset += (0.15f * (0.0f - scrollOffset));


  float zoomScale = 1.0f;
  if (zooming) {
    uint32_t elapsed = millis() - zoomStart;
    if (elapsed < 200) {
      float t = (float)elapsed / 200.0f;
      zoomScale = 1.0f + 0.1f * sinf(t * PI);
    } else zooming = false;
  }


  auto fillTrammage = [&](int x0, int y0, int w, int h, int r, uint16_t colDot) {
    int x1 = x0 + w - 1, y1 = y0 + h - 1;
    for (int yy = y0 + 1; yy < y1; ++yy) {
      int startX = ((yy & 1) ? 1 : 0) + x0 + 1;
      for (int xx = startX; xx < x1; xx += 2) {
        bool inside = true;
        if (xx < x0 + r && yy < y0 + r) { int dx=xx-(x0+r), dy=yy-(y0+r); if (dx*dx+dy*dy>r*r) inside=false; }
        if (xx > x1 - r && yy < y0 + r) { int dx=xx-(x1-r), dy=yy-(y0+r); if (dx*dx+dy*dy>r*r) inside=false; }
        if (xx < x0 + r && yy > y1 - r) { int dx=xx-(x0+r), dy=yy-(y1-r); if (dx*dx+dy*dy>r*r) inside=false; }
        if (xx > x1 - r && yy > y1 - r) { int dx=xx-(x1-r), dy=yy-(y1-r); if (dx*dx+dy*dy>r*r) inside=false; }
        if (inside) canvas.drawPixel(xx, yy, colDot);
      }
    }
  };


  auto drawTile = [&](int logicalIndex, int rel, float scale, uint8_t brightness,
                      uint16_t dotShade, int offsetAdjust, int verticalShift, int extraH) {
    int idx = logicalIndex;
    if (idx < 1) idx += (MODE_COUNT - 1);
    if (idx >= MODE_COUNT) idx -= (MODE_COUNT - 1);

    float xOffset = (rel + scrollOffset) * (baseW + spacing) * offsetAdjust / 100.0f;
    int xCenter = 128 + (int)xOffset;

    int tileW = (int)(baseW * scale);
    int tileH = (int)(baseH * scale * 0.85f) - extraH;  
    int yPos = centerY + verticalShift;
    int r = 10;

    uint16_t fillCol   = colGray(18 + (int)(scale * 10));
    uint16_t borderCol = colGray(brightness - 50);


    canvas.fillRoundRect(xCenter - tileW/2, yPos - tileH/2, tileW, tileH, r, fillCol);
    fillTrammage(xCenter - tileW/2, yPos - tileH/2, tileW, tileH, r, dotShade);
    canvas.drawRoundRect(xCenter - tileW/2, yPos - tileH/2, tileW, tileH, r, borderCol);


    canvas.setFont(&capitolcity10pt7b);

canvas.setTextColor(colGray(brightness));
const char* label = gModes[idx].name;


if (abs(rel) == 1) {
  if (rel < 0) {

    canvas.setTextDatum(middle_left);
    int leftEdge = xCenter - tileW / 2;
    canvas.drawString(label, leftEdge + 3, yPos);
  } else {

    canvas.setTextDatum(middle_right);
    int rightEdge = xCenter + tileW / 2;
    canvas.drawString(label, rightEdge - 3, yPos);
  }
} else {

  canvas.setTextDatum(middle_center);
  canvas.drawString(label, xCenter, yPos);
}
};


  drawTile(gMenuSelection - 2, -2, 0.80f, 90, colGray(32), 100, +6, 5);
  drawTile(gMenuSelection + 2, +2, 0.80f, 90, colGray(32), 100, +6, 5);


  drawTile(gMenuSelection - 1, -1, 0.93f, 150, colGray(38), 85, +3, 0);
  drawTile(gMenuSelection + 1, +1, 0.93f, 150, colGray(38), 85, +3, 0);


  {
    float scale = 1.00f * zoomScale;
    int tileW = (int)(baseW * scale);
    int tileH = baseH - 1;   
    int xCenter = 128;
    int yPos = 31;           
    int r = 12;

    uint16_t fillCol   = colGray(26);
    uint16_t borderCol = colGray(128);


    for (int s = 1; s <= 3; s++) {
      uint16_t shadowCol = colGray(16 + s * 3);
      canvas.drawRoundRect(xCenter - tileW/2, yPos - tileH/2 + s, tileW, tileH, r, shadowCol);
    }


    canvas.fillRoundRect(xCenter - tileW/2, yPos - tileH/2, tileW, tileH, r, fillCol);
    fillTrammage(xCenter - tileW/2, yPos - tileH/2, tileW, tileH, r, colGray(46));
    canvas.drawRoundRect(xCenter - tileW/2, yPos - tileH/2, tileW, tileH, r, borderCol);

    canvas.setFont(&capitolcity10pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString(gModes[gMenuSelection].name, xCenter, yPos);
  }
}
#endif


static void draw_boot_animation() {
  uint32_t start = millis();
  const uint32_t FADEIN  = 1200;   
  const uint32_t HOLD    = 800;    
  const uint32_t LOADBAR = 3000;   
  const uint32_t FADEOUT = 400;    
  const uint16_t bgDot   = colGray(24);


  while (true) {
    uint32_t t = millis() - start;
    float alpha = 0.0f;

    if (t < FADEIN) alpha = (float)t / (float)FADEIN;
    else if (t < FADEIN + HOLD) alpha = 1.0f;
    else break;

    uint8_t level = (uint8_t)(alpha * 255.0f);
    uint16_t textCol = colGray(level);

    canvas.fillScreen(colGray(0));
    for (int y = 0; y < 64; ++y) {
      int startX = (y & 1);
      for (int x = startX; x < 256; x += 2)
        canvas.drawPixel(x, y, bgDot);
    }

    canvas.setFont(&Race_Sport26pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(textCol);
    canvas.drawString("AXION", 128, 28);

    display_push((uint8_t*)canvas.getBuffer(), 256, 64);
    delay(16);
  }


  uint32_t loadStart = millis();
  const int barW = 180;
  const int barH = 5;
  const int barX = (256 - barW) / 2;
  const int barY = 63 - barH; 
  const uint16_t frameCol = colGray(64);
  const uint16_t fillCol  = colGray(255);

  while (millis() - loadStart < LOADBAR) {
    float p = (float)(millis() - loadStart) / (float)LOADBAR;
    if (p > 1.0f) p = 1.0f;
    float eased = 1.0f - powf(1.0f - p, 3.0f);

    canvas.fillScreen(colGray(0));
    for (int y = 0; y < 64; ++y) {
      int startX = (y & 1);
      for (int x = startX; x < 256; x += 2)
        canvas.drawPixel(x, y, bgDot);
    }

    canvas.setFont(&Race_Sport26pt7b);
    canvas.setTextDatum(middle_center);
    canvas.setTextColor(colGray(255));
    canvas.drawString("AXION", 128, 28);

    int filled = (int)(barW * eased);
    canvas.drawRoundRect(barX, barY, barW, barH, 2, frameCol);
    canvas.fillRoundRect(barX, barY, filled, barH, 2, fillCol);

    display_push((uint8_t*)canvas.getBuffer(), 256, 64);
    delay(16);
  }


  // Capture la derni�re frame du logo (AXION + barre compl�te)
  static uint8_t bootLogoBuf[256 * 64];
  static uint8_t bootMenuBuf[256 * 64];
  uint8_t* buf = (uint8_t*)canvas.getBuffer();
  memcpy(bootLogoBuf, buf, 256 * 64);

  // Pr�-rendre le menu dans un buffer s�par�
  draw_menu(0);
  memcpy(bootMenuBuf, buf, 256 * 64);

  // Fondu progressif du logo vers le menu
  uint32_t fadeStart = millis();
  while (true) {
    uint32_t elapsed = millis() - fadeStart;
    if (elapsed > FADEOUT) elapsed = FADEOUT;
    float f = (float)elapsed / (float)FADEOUT;  // 0..1

    for (int i = 0; i < 256 * 64; ++i) {
      uint8_t a = bootLogoBuf[i];
      uint8_t b = bootMenuBuf[i];
      buf[i] = (uint8_t)((1.0f - f) * a + f * b);
    }

    display_push(buf, 256, 64);

    if (elapsed >= FADEOUT) break;
    delay(16);
  }
}







static void transition_to_mode(int newMode) {
  static uint8_t pageOld[16384];
  static uint8_t pageNew[16384];

  memcpy(pageOld, canvas.getBuffer(), 16384);
  int oldMode = gCurrentMode;

  // Si on quitte Settings, on repasse la vue sur les tuiles
  if (oldMode == MODE_SETTINGS && newMode != MODE_SETTINGS) {
    gSettingsInConfig = false;
  }

  gCurrentMode = newMode;


  if (gCurrentMode == MODE_MENU)       draw_menu(gFrames);
  else if (gCurrentMode == MODE_DASHBOARD) draw_dashboard(gFrames);
  else if (gCurrentMode == MODE_GFORCES)   draw_gforces(gFrames);
  else if (gCurrentMode == MODE_COMPASS)   draw_compass_ui(gFrames);
  else if (gCurrentMode == MODE_DRIFT)     draw_drift(gFrames);
  else if (gCurrentMode == MODE_ACCEL)     draw_accel(gFrames);
  else if (gCurrentMode == MODE_CRAWLING)  draw_crawling(gFrames);
  else if (gCurrentMode == MODE_SETTINGS)  draw_settings(gFrames);

  else {
    canvas.fillScreen(colGray(0));
    canvas.setFont(&fonts::Font2);
    canvas.setTextColor(colGray(255));
    canvas.setTextDatum(middle_center);
    canvas.drawString("COMING SOON", 128, 24);
    canvas.setFont(&fonts::Font0);
    canvas.setTextColor(colGray(160));
    canvas.drawString(gModes[gCurrentMode].fullName, 128, 40);
  }

  memcpy(pageNew, canvas.getBuffer(), 16384);

  int direction = 1;
  if (oldMode == MODE_MENU && newMode != MODE_MENU) direction = 1;
  else if (oldMode != MODE_MENU && newMode == MODE_MENU) direction = -1;

  uint8_t* buf = (uint8_t*)canvas.getBuffer();
  for (int step = 0; step <= 12; step++) {
    int offset = (step * 256) / 12;
    for (int y = 0; y < 64; y++) {
      for (int x = 0; x < 256; x++) {
        int xOld = x + (offset * direction);
        int xNew = x - (256 - offset) * direction;

        if (xOld >= 0 && xOld < 256) {
          buf[y * 256 + x] = pageOld[y * 256 + xOld];
        } else if (xNew >= 0 && xNew < 256) {
          buf[y * 256 + x] = pageNew[y * 256 + xNew];
        } else {
          buf[y * 256 + x] = 0;
        }
      }
    }
    display_push(buf, 256, 64);
    delay(20);
  }
}




void setup(){
  Serial.begin(115200);

  delay(200);

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, 400000);
  pcf::begin(I2C_ADDR_PCF8574);


  input_init();
  display_init();
  canvas.setColorDepth(8); canvas.createSprite(256,64); canvas.setTextDatum(middle_center); canvas.setFont(&fonts::Font2);
  buildSinTable();

  draw_boot_animation();
  Serial.println("=== AXION v1.0 - Menu System ===");
  Serial.println("Controls: A=Prev, D=Next, S=Select/Back");

  // Core 0 : pipeline de données (GNSS/IMU + fusion)
  if (gTaskDataCore == nullptr) {
    xTaskCreatePinnedToCore(
      task_data_core,
      "AXION_DATA",
      8192,
      nullptr,
      3,
      &gTaskDataCore,
      0
    );
  }

  // Core 1 : UI / interaction (rendu OLED + boutons)
  if (gTaskUiCore == nullptr) {
    xTaskCreatePinnedToCore(
      task_ui_core,
      "AXION_UI",
      12288,
      nullptr,
      2,
      &gTaskUiCore,
      1
    );
  }
}

static void ui_loop_iteration() {

  while (Serial.available()) {
    int c = Serial.read();


    if (c == 'r' || c == 'R') {
      Serial.println("Returning to menu");
      transition_to_mode(MODE_MENU);
      return;  
    }


    if (gCurrentMode == MODE_MENU) {
      if (c == 'a' || c == 'A') {
        gMenuSelection = menu_prev_mode(gMenuSelection);
        Serial.printf("Menu: %s\n", gModes[gMenuSelection].name);
      } else if (c == 'd' || c == 'D') {
        gMenuSelection = menu_next_mode(gMenuSelection);
        Serial.printf("Menu: %s\n", gModes[gMenuSelection].name);
      } else if (c == 's' || c == 'S') {
        if (gModes[gMenuSelection].implemented) {
          Serial.printf("Entering: %s\n", gModes[gMenuSelection].fullName);
          transition_to_mode(gMenuSelection);
        } else {
          Serial.printf("Not implemented: %s\n", gModes[gMenuSelection].name);
        }
      }
    } else if (gCurrentMode == MODE_ACCEL) {
      accel_handle_serial(c);
    } else if (gCurrentMode == MODE_DRAG) {
      drag_handle_serial(c);
    }

}



  {
    uint8_t v = 0;
    if (pcf::read_byte(I2C_ADDR_PCF8574, v)) {
      bool left  = ((v >> PCF_BIT_BTN_LEFT)   & 1u) == 0; 
      bool right = ((v >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
      bool sel   = ((v >> PCF_BIT_BTN_SELECT) & 1u) == 0;

      bool triple = left && right && sel;
      uint32_t now = millis();

      if (triple) {
        if (!gTripleBtnActive) {
          gTripleBtnActive = true;
          gTripleBtnStartMs = now;
        } else if ((now - gTripleBtnStartMs) > 1500u) { 
          Serial.println("Triple button hold: re-init SSD1322");
          display_full_reinit();
          gTripleBtnActive = false; 
        }
      } else {
        gTripleBtnActive = false;
      }
    }
  }


  {
    static uint8_t  s_prevBtns       = 0xFF;
    static uint32_t s_selHoldStart   = 0;
    static bool     s_selLongHandled = false;
    static uint32_t s_lrHoldStart    = 0;
    static bool     s_lrLongHandled  = false;
    static uint32_t s_leftHoldStart  = 0;
    static uint32_t s_rightHoldStart = 0;
    static uint32_t s_leftLastRep    = 0;
    static uint32_t s_rightLastRep   = 0;
    static uint8_t  s_crawlParamSel  = 0;   // 0:none,1:warn,2:danger (Crawling)

    const uint32_t REPEAT_DELAY    = 800u;
    const uint32_t REPEAT_INTERVAL = 120u;

    uint8_t vBtns = 0;
    if (pcf::read_byte(I2C_ADDR_PCF8574, vBtns)) {
      bool left  = ((vBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0; 
      bool right = ((vBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
      bool sel   = ((vBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;

      bool leftPrev  = ((s_prevBtns >> PCF_BIT_BTN_LEFT)   & 1u) == 0;
      bool rightPrev = ((s_prevBtns >> PCF_BIT_BTN_RIGHT)  & 1u) == 0;
      bool selPrev   = ((s_prevBtns >> PCF_BIT_BTN_SELECT) & 1u) == 0;

      bool leftEdge     = left  && !leftPrev;   // press
      bool rightEdge    = right && !rightPrev;  // press
      bool selEdge      = sel   && !selPrev;    // press
      bool leftRelease  = !left  && leftPrev;   // release
      bool rightRelease = !right && rightPrev;  // release
      bool selRelease   = !sel   && selPrev;    // release

      bool leftRepeat  = false;
      bool rightRepeat = false;

      uint32_t now = millis();


      if (sel && !left && !right) {
        if (!selPrev) {
          s_selHoldStart   = now;
          s_selLongHandled = false;
        } else if (!s_selLongHandled && (now - s_selHoldStart) > 1200u) {
          Serial.println("BTN SELECT long -> MENU");
          transition_to_mode(MODE_MENU);
          s_selLongHandled = true;
        }
      }

      bool bothLR = left && right && !sel;
      if (bothLR) {
        if (!s_lrHoldStart) {
          s_lrHoldStart = now;
          s_lrLongHandled = false;
        } else if (!s_lrLongHandled && (now - s_lrHoldStart) > 800u) {
          if (gCurrentMode == MODE_ACCEL) {
            accel_handle_serial('w');  // toggle Accel/Brake
          } else if (gCurrentMode == MODE_DRAG) {
            drag_handle_serial('w');   // toggle Drag/Launch
          }
          s_lrLongHandled = true;
        }
      } else {
        s_lrHoldStart = 0;
        s_lrLongHandled = false;
      }

      // Auto-repeat LEFT
      if (left) {
        if (!leftPrev) {
          s_leftHoldStart = now;
          s_leftLastRep   = now;
        } else if ((now - s_leftHoldStart) >= REPEAT_DELAY &&
                   (now - s_leftLastRep)   >= REPEAT_INTERVAL) {
          leftRepeat = true;
          s_leftLastRep = now;
        }
      } else {
        s_leftHoldStart = 0;
      }

      // Auto-repeat RIGHT
      if (right) {
        if (!rightPrev) {
          s_rightHoldStart = now;
          s_rightLastRep   = now;
        } else if ((now - s_rightHoldStart) >= REPEAT_DELAY &&
                   (now - s_rightLastRep)   >= REPEAT_INTERVAL) {
          rightRepeat = true;
          s_rightLastRep = now;
        }
      } else {
        s_rightHoldStart = 0;
      }

      bool allowIndividualLR = !bothLR;

      // Short presses : déclenchés au relâchement, pas lors de l'appui.
      bool selShort   = selRelease   && !s_selLongHandled;
      bool leftShort  = leftRelease;
      bool rightShort = rightRelease;

      if (gCurrentMode == MODE_MENU) {
        if (leftShort || leftRepeat) {
          gMenuSelection = menu_prev_mode(gMenuSelection);
          Serial.printf("Menu (BTN): %s\n", gModes[gMenuSelection].name);
        } else if (rightShort || rightRepeat) {
          gMenuSelection = menu_next_mode(gMenuSelection);
          Serial.printf("Menu (BTN): %s\n", gModes[gMenuSelection].name);
        } else if (selShort) {
          if (gModes[gMenuSelection].implemented) {
            Serial.printf("Entering (BTN): %s\n", gModes[gMenuSelection].fullName);
            transition_to_mode(gMenuSelection);
          } else {
            Serial.printf("Not implemented (BTN): %s\n", gModes[gMenuSelection].name);
          }
        }
      } else if (gCurrentMode == MODE_SETTINGS) {
        if (!gSettingsInConfig) {
          if (leftShort || leftRepeat) {
            gSettingsSelection = (gSettingsSelection + 4 - 1) % 4;
          } else if (rightShort || rightRepeat) {
            gSettingsSelection = (gSettingsSelection + 1) % 4;
          } else if (selShort) {
            if (gSettingsSelection == 0) {
              gSettingsInConfig = true;  // entrer dans Config (HC-05 / SD)
            } else if (gSettingsSelection == 1) {
              transition_to_mode(MODE_DIAGNOSTICS);
            } else if (gSettingsSelection == 2) {
              transition_to_mode(MODE_BENCH);
            } else {
              // Prefs: placeholder pour futur écran
            }
          }
        } else {
          // En mode Config, les pages HC-05/SD gèrent elles-mêmes les boutons.
        }
      } else if (gCurrentMode == MODE_ACCEL) {
        if (allowIndividualLR) {
          if (leftShort || leftRepeat)   accel_handle_serial('a');
          if (rightShort || rightRepeat) accel_handle_serial('d');
        }
        if (selShort) accel_handle_serial('s');
      } else if (gCurrentMode == MODE_DRAG) {
        if (allowIndividualLR) {
          if (leftShort || leftRepeat)   drag_handle_serial('a');
          if (rightShort || rightRepeat) drag_handle_serial('d');
        }
        if (selShort) drag_handle_serial('s');
      } else if (gCurrentMode == MODE_CRAWLING) {
        // Sous-s�lection des seuils via boutons
        if (selEdge && !s_selLongHandled) {
          s_crawlParamSel = (uint8_t)((s_crawlParamSel + 1) % 3); // NONE -> WARN -> DANGER -> NONE
        }
        if (allowIndividualLR && s_crawlParamSel != 0) {
          int dir = 0;
          if (leftEdge || leftRepeat)  dir -= 1;
          if (rightEdge || rightRepeat) dir += 1;
          if (dir != 0) {
            if (s_crawlParamSel == 1)      crawling_adjust_warn(dir);
            else /* s_crawlParamSel == 2*/ crawling_adjust_danger(dir);
          }
        }
      }

      s_prevBtns = vBtns;
    }
  }

  // Synchronise la sous-s�lection Crawling (Pmax / Rmax) vers l'UI
  if (gCurrentMode == MODE_CRAWLING) {
    crawling_set_param_sel(s_crawlParamSel);
  }

  switch (gCurrentMode) {
    case MODE_MENU:       draw_menu(gFrames); break;
    case MODE_DASHBOARD:  draw_dashboard(gFrames); break;
    case MODE_GFORCES:    draw_gforces(gFrames); break;
    case MODE_LAP:        draw_lap(gFrames); break;
    case MODE_DIAGNOSTICS:draw_diagnostics(gFrames); break;
    case MODE_SETTINGS:   draw_settings(gFrames);    break;
    case MODE_COMPASS:    draw_compass_ui(gFrames); break;
    case MODE_CRAWLING:   draw_crawling(gFrames); break;
    case MODE_DRIFT:      draw_drift(gFrames); break;
    case MODE_ACCEL:      draw_accel(gFrames); break;
    case MODE_DRAG:       draw_drag(gFrames); break;  
    default:
      canvas.fillScreen(colGray(0));
      canvas.setFont(&fonts::Font2);
      canvas.setTextColor(colGray(255));
      canvas.setTextDatum(middle_center);
      canvas.drawString("COMING SOON", 128, 24);
      break;
  }


  {
    bool permitRender = true;
#if defined(USE_DATA_FUSION)
    static uint32_t last_ts_us = 0;
    AxionData Dgate; data_fusion_snapshot(Dgate);
    if (Dgate.timestamp_us) {
      permitRender = (Dgate.timestamp_us != last_ts_us);
      if (permitRender) last_ts_us = Dgate.timestamp_us;
    } else {
      static uint32_t next_ms = 0; if (!next_ms) next_ms = millis();
      if ((int32_t)(millis() - next_ms) >= 0) { permitRender = true; next_ms += 40; } else { permitRender = false; }
    }
#endif
    if (permitRender) {
      draw_debug_overlay();
      display_push((uint8_t*)canvas.getBuffer(), 256, 64);
      gFrames++;

      
      // LED bicolore
      if (gCurrentMode == MODE_DRIFT) {
        bool green = false, red = false;
        if (gDriftFlashActive || gFireworksActive) {
          green = ((millis() / 200) & 1) == 0;
        } else if (gDriftActive) {
          green = true;
        } else {
          green = true;
          red   = true;
        }
        led_set(green, red);
      } else if (gCurrentMode == MODE_DIAGNOSTICS) {
        // Si TEST ALL en cours, on laisse diagnostics_engine piloter la LED
        const DiagnosticsTestAllStatus& T = diagnostics_engine_get_test_all_status();
        if (!T.running) {
          led_set(false, false);
        }
      } else {
        // autres modes: ?teint
        led_set(false, false);
      }
    } else {
      delay(1);
    }
  }


  // LED Crawling (prioritaire sur l'�tat \"off\" des autres modes)
  if (gCurrentMode == MODE_CRAWLING) {
    float tilt   = crawling_get_tilt_now();
    float warnTh = crawling_get_warnTilt();
    float dangTh = crawling_get_dangerTilt();
    bool green = false, red = false;
    if (tilt < warnTh) {
      green = true; red = false;
    } else if (tilt < dangTh) {
      green = true; red = true;
    } else {
      green = false; red = true;
    }
    led_set(green, red);
  }

  if (millis() - gFPStimer > 1000) {
    uint32_t fps = gFrames - gLastFPS;
    gLastFPS = gFrames;
    gFPStimer = millis();
    g_lastFpsValue = fps; 

  }


  static uint32_t frameIntervalUs = 1000000 / 120;
  static uint32_t nextDeadlineUs = micros() + frameIntervalUs;
  nextDeadlineUs += frameIntervalUs;
  int32_t wait = (int32_t)(nextDeadlineUs - micros());
  if (wait > 0) delayMicroseconds((uint32_t)wait);
}

static void task_data_core(void* pvParameters)
{
  (void)pvParameters;

#if defined(USE_DATA_FUSION)
  data_fusion_init();

  // Initialisation du pipeline OBD (HC-05 -> ELM327).
  obd_init();

  const TickType_t periodTicks = pdMS_TO_TICKS(40); // ~25 Hz
  TickType_t lastWake = xTaskGetTickCount();

  for (;;) {
    // Avance la machine d'état OBD sans bloquer.
    obd_update();

    // Pipeline GNSS/IMU + fusion AxionData.
    data_fusion_update();

    // Logger 25 Hz, basé sur la trame fusionnée la plus récente.
    AxionData Dlog{};
    data_fusion_snapshot(Dlog);
    logger_update(Dlog);

    vTaskDelayUntil(&lastWake, periodTicks);
  }
#else
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
#endif
}


static void task_ui_core(void* pvParameters)
{
  (void)pvParameters;

  for (;;) {
    ui_loop_iteration();
  }
}


void loop() {
  // Tout le travail est fait par les tasks FreeRTOS.
  // On laisse la loop Arduino en veille.
  delay(1000);
}











