﻿#include <Arduino.h>
#include <math.h>

#include "logic_modes/compass_engine.h"

static float sHeadingDeg   = 0.0f;
static float sElevationDeg = 0.0f;
static float sLat          = 0.0f;
static float sLon          = 0.0f;

void compass_engine_init()
{
  sHeadingDeg   = 0.0f;
  sElevationDeg = 0.0f;
  sLat          = 0.0f;
  sLon          = 0.0f;
}

void compass_engine_update(const AxionData& D, uint32_t frame)
{
#ifdef USE_DATA_FUSION
  (void)frame;
  sHeadingDeg   = D.heading_deg;
  sElevationDeg = D.gyro_deg[1];
  if (sElevationDeg < -30.0f) sElevationDeg = -30.0f;
  if (sElevationDeg >  30.0f) sElevationDeg =  30.0f;
  sLat = D.lat;
  sLon = D.lon;
#else
  float t = frame * 0.005f;
  sHeadingDeg   = fmodf(t * 30.0f, 360.0f);
  sElevationDeg = 5.0f + sinf(t * 0.8f) * 8.0f;
  sLat          = 47.5456f  + sinf(t * 0.3f)  * 0.0001f;
  sLon          = -64.8234f + cosf(t * 0.25f) * 0.0001f;
#endif
}

float compass_engine_get_heading_deg()   { return sHeadingDeg; }
float compass_engine_get_elevation_deg() { return sElevationDeg; }
float compass_engine_get_lat()           { return sLat; }
float compass_engine_get_lon()           { return sLon; }
