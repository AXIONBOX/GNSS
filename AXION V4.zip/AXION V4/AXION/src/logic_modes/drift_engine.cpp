﻿#include <Arduino.h>

#include "logic_modes/drift_engine.h"

// Internal drift state (moved from ui_drift)

static uint32_t sDriftScore        = 0;
static uint32_t sDriftCurrentScore = 0;
static float    sDriftMultiplier   = 1.0f;
static float    sDriftAngle        = 0.0f;
static float    sDriftDuration     = 0.0f;
static uint32_t sDriftStartMs      = 0;
static bool     sDriftActive       = false;
static uint32_t sLastDriftEndMs    = 0;
static int      sDriftComboCount   = 0;
static uint32_t sSessionStartMs    = 0;

static bool     sDriftFlashActive  = false;
static uint32_t sDriftFlashStart   = 0;

static int      sSpeedKmh          = 0;
static float    sLatG              = 0.0f;

static uint32_t sT0SpeedMs         = 0;

void drift_engine_init()
{
  sDriftScore        = 0;
  sDriftCurrentScore = 0;
  sDriftMultiplier   = 1.0f;
  sDriftAngle        = 0.0f;
  sDriftDuration     = 0.0f;
  sDriftStartMs      = 0;
  sDriftActive       = false;
  sLastDriftEndMs    = 0;
  sDriftComboCount   = 0;
  sSessionStartMs    = 0;
  sDriftFlashActive  = false;
  sDriftFlashStart   = 0;
  sSpeedKmh          = 0;
  sLatG              = 0.0f;
  sT0SpeedMs         = 0;
}

void drift_engine_update(uint32_t frame)
{
  uint32_t now = millis();

  if (sSessionStartMs == 0) sSessionStartMs = now;

  // Simple simulated speed profile (triangle 0..220km/h)
  if (sT0SpeedMs == 0) sT0SpeedMs = now;
  float phase2 = ((now - sT0SpeedMs) % 20000) / 10000.0f; // 0..2
  float tri    = (phase2 <= 1.0f) ? phase2 : (2.0f - phase2);
  int   speedKmh = (int)(tri * 220.0f + 0.5f);
#ifdef USE_DATA_FUSION
  {
    AxionData D; data_fusion_snapshot(D);
    speedKmh = (int)(D.speed_kmh + 0.5f);
  }
#endif

  // Simulated lateral G (sine), optionally replaced by fused data
  float t    = frame * 0.02f;
  float latG = sinf(t * 0.5f) * 1.5f;
#ifdef USE_DATA_FUSION
  {
    AxionData D; data_fusion_snapshot(D);
    latG = D.accel_g[1];
    if (latG < -1.5f) latG = -1.5f;
    if (latG >  1.5f) latG =  1.5f;
  }
#endif

  sLatG     = latG;
  sSpeedKmh = speedKmh;
  sDriftAngle = fabsf(latG) * 30.0f;

  bool driftingNow = (sDriftAngle > 15.0f && sSpeedKmh > 50);

  if (driftingNow) {
    if (!sDriftActive) {
      sDriftActive       = true;
      sDriftStartMs      = now;
      sDriftCurrentScore = 0;
      sDriftFlashActive  = false;
      if (sLastDriftEndMs > 0 && (now - sLastDriftEndMs) < 2000) sDriftComboCount++;
      else sDriftComboCount = 1;
    }
    sDriftDuration = (now - sDriftStartMs) / 1000.0f;
    float comboBonus    = 1.0f + (sDriftComboCount - 1) * 0.5f;
    float durationBonus = 1.0f + (sDriftDuration * 0.2f);
    sDriftMultiplier = comboBonus * durationBonus;
    if (sDriftMultiplier > 5.0f) sDriftMultiplier = 5.0f;
    uint32_t pts = (uint32_t)((sDriftAngle * sSpeedKmh * sDriftMultiplier) / 5000.0f);
    sDriftCurrentScore += pts;
  }

  if (!driftingNow && sDriftActive) {
    sDriftActive     = false;
    sDriftScore     += sDriftCurrentScore;
    sLastDriftEndMs  = now;
    sDriftMultiplier = 1.0f;
    sDriftDuration   = 0.0f;
    if (sDriftCurrentScore >= 700) {
      sDriftFlashActive = true;
      sDriftFlashStart  = now;
    }
  }

  // Flash lifetime (~800ms), after which only UI fireworks continue
  if (sDriftFlashActive && (now - sDriftFlashStart) >= 800) {
    sDriftFlashActive = false;
  }
}

float    drift_engine_get_angle()          { return sDriftAngle; }
float    drift_engine_get_duration()       { return sDriftDuration; }
float    drift_engine_get_multiplier()     { return sDriftMultiplier; }
uint32_t drift_engine_get_current_score()  { return sDriftCurrentScore; }
uint32_t drift_engine_get_total_score()    { return sDriftScore; }
int      drift_engine_get_combo_count()    { return sDriftComboCount; }
int      drift_engine_get_speed_kmh()      { return sSpeedKmh; }
float    drift_engine_get_lat_g()          { return sLatG; }
uint32_t drift_engine_get_session_ms()     { return (sSessionStartMs == 0) ? 0 : (millis() - sSessionStartMs); }

bool     drift_engine_is_active()          { return sDriftActive; }
bool     drift_engine_flash_active()       { return sDriftFlashActive; }
