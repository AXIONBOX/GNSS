﻿#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>

#include "logic_modes/diagnostics_engine.h"
#include "system/pins.h"
#include "system/pcf.h"

// Diagnostics engine: passive, non-blocking observer with HC-05 + ELM327 tests.

namespace {
  DiagnosticsStatus g_status{};

  uint32_t s_lastLoopMs   = 0;
  uint32_t s_loopMinMs    = 0xFFFFFFFFu;
  uint32_t s_loopMaxMs    = 0;

  uint32_t s_lastDumpMs   = 0;

  HardwareSerial BT(1);

  enum class Hc05Phase : uint8_t {
    NotStarted = 0,
    RaiseKeyAndWait,
    PrepareBaud,
    SendAT,
    WaitAT,
    SendSet115200,
    WaitSet115200,
    SendATVerify115200,
    WaitATVerify115200,
    SendName,
    WaitName,
    SendAddr,
    WaitAddr,
    SendVersion,
    WaitVersion,
    Done,
    Failed
  };

  Hc05Phase  s_hc05Phase         = Hc05Phase::NotStarted;
  uint32_t   s_hc05PhaseDeadline = 0;
  uint32_t   s_hc05Baud          = 0;
  int        s_hc05BaudIndex     = 0;
  const uint32_t kHc05Bauds[3]   = {9600, 38400, 115200};
  uint32_t   s_hc05KeyChangeMs   = 0;

  char   s_hc05Buf[128];
  size_t s_hc05Len = 0;

  enum class ElmPhase : uint8_t {
    Idle = 0,
    WaitAfterKeyLow,
    WaitATZ,
    WaitATI,
    WaitATSP0,
    WaitATDP,
    Wait0100,
    Wait010C,
    Wait010D,
    Done,
    Failed
  };

  ElmPhase  s_elmPhase         = ElmPhase::Idle;
  uint32_t  s_elmPhaseDeadline = 0;
  uint32_t  s_elmKeyLowMs      = 0;

  char   s_elmBuf[192];
  size_t s_elmLen = 0;

  bool     s_rtcPresent      = false;
  bool     s_rtcEn32k        = false;
  bool     s_rtcSqw          = false;

    DiagnosticsTestAllStatus s_testAll{};
  bool s_testBuzzerDone  = false;
  bool s_testLedDone     = false;
  bool s_btnRightSeen    = false;
  bool s_btnSelectSeen   = false;
  bool s_btnLeftSeen     = false;

  enum class TestAllPhase : uint8_t {
    Idle = 0,
    Start,
    BuzzerOn,
    BuzzerOffWait,
    LedGreen,
    LedRed,
    Buttons,
    Done
  };

  TestAllPhase s_testPhase         = TestAllPhase::Idle;
  uint32_t     s_testPhaseDeadline = 0;
  bool         s_ledBaselineKnown  = false;
  bool         s_ledBaselineGreen  = true;
  bool         s_ledBaselineRed    = true;

  // SD / filesystem probing
  bool         s_sdSpiInited       = false;
  bool         s_sdMounted         = false;
  uint32_t     s_sdNextProbeMs     = 0;
}

extern uint32_t g_lastFpsValue;

static void diagnostics_update_test_all();
static void diagnostics_update_sd_fs(uint32_t nowMs);

static void hc05_buf_clear()

{
  s_hc05Len = 0;
  s_hc05Buf[0] = '\0';
}

static void hc05_buf_collect()
{
  while (BT.available() && s_hc05Len < sizeof(s_hc05Buf) - 1) {
    int c = BT.read();
    if (c < 0) break;
    s_hc05Buf[s_hc05Len++] = (char)c;
  }
  s_hc05Buf[s_hc05Len] = '\0';
}

static bool hc05_buf_contains(const char* token)
{
  return strstr(s_hc05Buf, token) != nullptr;
}

// Helpers ELM ----------------------------------------------------------------

static void elm_buf_clear()
{
  s_elmLen = 0;
  s_elmBuf[0] = '\0';
}

static void elm_buf_collect()
{
  while (BT.available() && s_elmLen < sizeof(s_elmBuf) - 1) {
    int c = BT.read();
    if (c < 0) break;
    s_elmBuf[s_elmLen++] = (char)c;
  }
  s_elmBuf[s_elmLen] = '\0';
}

static bool elm_buf_contains(const char* token)
{
  return strstr(s_elmBuf, token) != nullptr;
}

static uint32_t parse_hex_u32_from_tokens(const char* line)
{
  const char* p = strstr(line, "41 00");
  if (!p) return 0;
  uint32_t result = 0;
  int bytesParsed = 0;
  p = strchr(p, ' ');
  if (!p) return 0;
  ++p;
  p = strchr(p, ' ');
  if (!p) return 0;
  ++p;
  while (*p && bytesParsed < 4) {
    while (*p == ' ') ++p;
    if (!isxdigit((unsigned char)p[0])) break;
    char bstr[3] = {0,0,0};
    bstr[0] = p[0];
    if (isxdigit((unsigned char)p[1])) {
      bstr[1] = p[1];
      p += 2;
    } else {
      ++p;
    }
    uint32_t val = (uint32_t)strtoul(bstr, nullptr, 16);
    result = (result << 8) | (val & 0xFFu);
    ++bytesParsed;
  }
  return (bytesParsed == 4) ? result : 0;
}

static bool parse_obd_pid_010C(const char* line, float& rpmOut)
{
  const char* p = strstr(line, "41 0C");
  if (!p) return false;
  int A = 0, B = 0;
  if (sscanf(p, "41 0C %x %x", &A, &B) == 2) {
    rpmOut = ((float)(A * 256 + B)) / 4.0f;
    return true;
  }
  return false;
}

static bool parse_obd_pid_010D(const char* line, float& speedOut)
{
  const char* p = strstr(line, "41 0D");
  if (!p) return false;
  int A = 0;
  if (sscanf(p, "41 0D %x", &A) == 1) {
    speedOut = (float)A;
    return true;
  }
  return false;
}

static bool rtc_read_reg(uint8_t addr, uint8_t reg, uint8_t& value)
{
  Wire.beginTransmission(addr);
  Wire.write(reg);
  if (Wire.endTransmission() != 0) return false;
  if (Wire.requestFrom((int)addr, 1) != 1) return false;
  value = (uint8_t)Wire.read();
  return true;
}

static void diagnostics_update_rtc()
{
  if (s_rtcPresent || s_rtcEn32k || s_rtcSqw) {
    // Already probed once; keep result.
    return;
  }

  const uint8_t addr = 0x68; // typical DS3231 I2C address
  uint8_t status = 0;
  uint8_t control = 0;
  if (!rtc_read_reg(addr, 0x0F, status) || !rtc_read_reg(addr, 0x0E, control)) {
    g_status.rtc_ok = false;
    return;
  }

  s_rtcPresent = true;

  // DS3231: OSF bit7 (0 = oscillator running), EN32kHz bit3 in status
  bool oscRunning = (status & 0x80u) == 0;
  s_rtcEn32k      = (status & 0x08u) != 0;

  // DS3231: INTCN bit2 (0 = square-wave on SQW), BBSQW bit6 can also enable battery-backed SQW
  bool intcn  = (control & 0x04u) != 0;
  bool bbsqw  = (control & 0x40u) != 0;
  s_rtcSqw    = (!intcn) || bbsqw;

  // For diagnostics, consider the RTC OK as soon as it
  // responds on I2C (present). The oscillator status bit
  // is not enforced here to avoid spurious FAIL when the
  // module simply lost power once.
  (void)oscRunning;
  g_status.rtc_ok = s_rtcPresent;
}

// SD / filesystem ------------------------------------------------------------

static bool sd_remove_recursive(const char* path)
{
  File f = SD.open(path);
  if (!f) {
    return !SD.exists(path);
  }

  if (!f.isDirectory()) {
    f.close();
    return SD.remove(path);
  }

  // Directory: remove children first
  File child = f.openNextFile();
  while (child) {
    const char* name = child.name();
    char subPath[128];
    size_t baseLen = strlen(path);
    size_t nameLen = strlen(name);
    if (baseLen + 1 + nameLen >= sizeof(subPath)) {
      child.close();
      f.close();
      return false;
    }
    strcpy(subPath, path);
    if (!(baseLen == 1 && path[0] == '/')) {
      subPath[baseLen] = '/';
      subPath[baseLen + 1] = '\0';
    }
    strcat(subPath, name);

    bool ok = false;
    if (child.isDirectory()) {
      ok = sd_remove_recursive(subPath);
    } else {
      ok = SD.remove(subPath);
    }
    child.close();
    if (!ok) {
      f.close();
      return false;
    }
    child = f.openNextFile();
  }
  f.close();

  // Do not try to remove root.
  if (strcmp(path, "/") == 0) {
    return true;
  }
  return SD.rmdir(path);
}

static void diagnostics_update_sd_fs(uint32_t nowMs)
{
  // Throttle SD probing to at most ~1 Hz.
  if ((int32_t)(nowMs - s_sdNextProbeMs) < 0) {
    return;
  }
  s_sdNextProbeMs = nowMs + 1000;

  g_status.sd_present     = false;
  g_status.sd_ok          = false;
  g_status.fs_ok          = false;
  g_status.sd_total_bytes = 0;
  g_status.sd_used_bytes  = 0;

  if (!s_sdSpiInited) {
    SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
    s_sdSpiInited = true;
  }

  if (!SD.begin(PIN_SD_CS)) {
    s_sdMounted = false;
    return;
  }

  s_sdMounted = true;

  uint8_t cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    return;
  }

  g_status.sd_present = true;
  g_status.sd_ok      = true;

  // Basic FS stats (Espressif SD wrapper exposes these).
  uint64_t total = SD.totalBytes();
  uint64_t used  = SD.usedBytes();
  g_status.sd_total_bytes = total;
  g_status.sd_used_bytes  = used;

  // AXION filesystem considered "OK" if /AXION exists and is a directory.
  if (SD.exists("/AXION")) {
    File d = SD.open("/AXION");
    if (d && d.isDirectory()) {
      g_status.fs_ok = true;
    }
    if (d) d.close();
  }
}

// State machines -------------------------------------------------------------

static void diagnostics_update_hc05(uint32_t nowMs)
{
  if (g_status.hc05_ok && s_hc05Phase >= Hc05Phase::Done) {
    return;
  }

  switch (s_hc05Phase) {
    case Hc05Phase::NotStarted: {
      pinMode(PIN_BT_KEY, OUTPUT);
      digitalWrite(PIN_BT_KEY, HIGH);
      s_hc05KeyChangeMs = nowMs;
      s_hc05BaudIndex   = 0;
      s_hc05Baud        = 0;
      hc05_buf_clear();
      s_hc05Phase = Hc05Phase::RaiseKeyAndWait;
      break;
    }
    case Hc05Phase::RaiseKeyAndWait: {
      if (nowMs - s_hc05KeyChangeMs >= 200) {
        s_hc05Phase = Hc05Phase::PrepareBaud;
      }
      break;
    }
    case Hc05Phase::PrepareBaud: {
      if (s_hc05BaudIndex >= 3) {
        s_hc05Phase = Hc05Phase::Failed;
        break;
      }
      s_hc05Baud = kHc05Bauds[s_hc05BaudIndex];
      BT.end();
      BT.begin(s_hc05Baud, SERIAL_8N1, PIN_BT_RX, PIN_BT_TX);
      while (BT.available()) BT.read();
      hc05_buf_clear();
      s_hc05Phase = Hc05Phase::SendAT;
      break;
    }
    case Hc05Phase::SendAT: {
      BT.print("AT\r\n");
      hc05_buf_clear();
      s_hc05PhaseDeadline = nowMs + 500;
      s_hc05Phase = Hc05Phase::WaitAT;
      break;
    }
    case Hc05Phase::WaitAT: {
      hc05_buf_collect();
      if (hc05_buf_contains("OK")) {
        g_status.hc05_ok = true;
        g_status.hc05_baud_detected = s_hc05Baud;
        if (s_hc05Baud != 115200) {
          s_hc05Phase = Hc05Phase::SendSet115200;
        } else {
          s_hc05Phase = Hc05Phase::SendName;
        }
      } else if ((int32_t)(nowMs - s_hc05PhaseDeadline) >= 0) {
        ++s_hc05BaudIndex;
        s_hc05Phase = Hc05Phase::PrepareBaud;
      }
      break;
    }
    case Hc05Phase::SendSet115200: {
      hc05_buf_clear();
      BT.print("AT+UART=115200,0,0\r\n");
      s_hc05PhaseDeadline = nowMs + 800;
      s_hc05Phase = Hc05Phase::WaitSet115200;
      break;
    }
    case Hc05Phase::WaitSet115200: {
      hc05_buf_collect();
      if (hc05_buf_contains("OK")) {
        BT.end();
        BT.begin(115200, SERIAL_8N1, PIN_BT_RX, PIN_BT_TX);
        while (BT.available()) BT.read();
        s_hc05Baud = 115200;
        g_status.hc05_baud_detected = 115200;
        hc05_buf_clear();
        s_hc05Phase = Hc05Phase::SendATVerify115200;
      } else if ((int32_t)(nowMs - s_hc05PhaseDeadline) >= 0) {
        s_hc05Phase = Hc05Phase::Failed;
      }
      break;
    }
    case Hc05Phase::SendATVerify115200: {
      BT.print("AT\r\n");
      hc05_buf_clear();
      s_hc05PhaseDeadline = nowMs + 500;
      s_hc05Phase = Hc05Phase::WaitATVerify115200;
      break;
    }
    case Hc05Phase::WaitATVerify115200: {
      hc05_buf_collect();
      if (hc05_buf_contains("OK")) {
        s_hc05Phase = Hc05Phase::SendName;
      } else if ((int32_t)(nowMs - s_hc05PhaseDeadline) >= 0) {
        s_hc05Phase = Hc05Phase::Failed;
      }
      break;
    }
    case Hc05Phase::SendName: {
      hc05_buf_clear();
      BT.print("AT+NAME=AXION_HC-05\r\nAT+NAME?\r\n");
      {
        const char* newName = "AXION_HC-05";
        size_t n = 0;
        while (newName[n] && n < sizeof(g_status.hc05_name) - 1) {
          g_status.hc05_name[n] = newName[n];
          ++n;
        }
        g_status.hc05_name[n] = '\0';
      }
      s_hc05PhaseDeadline = nowMs + 800;
      s_hc05Phase = Hc05Phase::WaitName;
      break;
    }
    case Hc05Phase::WaitName: {
      hc05_buf_collect();
      if (hc05_buf_contains("OK") || hc05_buf_contains("+NAME") || hc05_buf_contains("NAME:")) {
        const char* p = strstr(s_hc05Buf, "NAME");
        if (!p) p = strstr(s_hc05Buf, "+NAME");
        if (!p) p = strstr(s_hc05Buf, "NAME:");
        if (p) {
          const char* colon = strchr(p, ':');
          if (colon) {
            colon++;
            while (*colon == ' ' || *colon == '"') ++colon;
            size_t n = 0;
            while (*colon && *colon != '\r' && *colon != '\n' && *colon != '"' &&
                   n < sizeof(g_status.hc05_name) - 1) {
              g_status.hc05_name[n++] = *colon++;
            }
            g_status.hc05_name[n] = '\0';
          }
        }
        s_hc05Phase = Hc05Phase::SendAddr;
      } else if ((int32_t)(nowMs - s_hc05PhaseDeadline) >= 0) {
        s_hc05Phase = Hc05Phase::SendAddr;
      }
      break;
    }
    case Hc05Phase::SendAddr: {
      hc05_buf_clear();
      BT.print("AT+ADDR?\r\n");
      s_hc05PhaseDeadline = nowMs + 800;
      s_hc05Phase = Hc05Phase::WaitAddr;
      break;
    }
    case Hc05Phase::WaitAddr: {
      hc05_buf_collect();
      if (hc05_buf_contains("OK") || hc05_buf_contains("+ADDR") || hc05_buf_contains("ADDR:")) {
        const char* p = strstr(s_hc05Buf, "ADDR");
        if (!p) p = strstr(s_hc05Buf, "+ADDR");
        if (!p) p = strstr(s_hc05Buf, "ADDR:");
        if (p) {
          const char* colon = strchr(p, ':');
          if (colon) {
            colon++;
            while (*colon == ' ' || *colon == '"') ++colon;
            size_t n = 0;
            while (*colon && *colon != '\r' && *colon != '\n' && *colon != '"' &&
                   n < sizeof(g_status.hc05_addr) - 1) {
              g_status.hc05_addr[n++] = *colon++;
            }
            g_status.hc05_addr[n] = '\0';
          }
        }
        s_hc05Phase = Hc05Phase::SendVersion;
      } else if ((int32_t)(nowMs - s_hc05PhaseDeadline) >= 0) {
        s_hc05Phase = Hc05Phase::SendVersion;
      }
      break;
    }
    case Hc05Phase::SendVersion: {
      hc05_buf_clear();
      BT.print("AT+VERSION?\r\n");
      s_hc05PhaseDeadline = nowMs + 800;
      s_hc05Phase = Hc05Phase::WaitVersion;
      break;
    }
    case Hc05Phase::WaitVersion: {
      hc05_buf_collect();
      if (hc05_buf_contains("OK") || hc05_buf_contains("+VERSION") || hc05_buf_contains("VERSION:")) {
        const char* p = strstr(s_hc05Buf, "VERSION");
        if (!p) p = strstr(s_hc05Buf, "+VERSION");
        if (!p) p = strstr(s_hc05Buf, "VERSION:");
        if (p) {
          const char* colon = strchr(p, ':');
          if (colon) {
            colon++;
            while (*colon == ' ' || *colon == '"') ++colon;
            size_t n = 0;
            while (*colon && *colon != '\r' && *colon != '\n' && *colon != '"' &&
                   n < sizeof(g_status.hc05_version) - 1) {
              g_status.hc05_version[n++] = *colon++;
            }
            g_status.hc05_version[n] = '\0';
          }
        }
        s_hc05Phase = Hc05Phase::Done;
      } else if ((int32_t)(nowMs - s_hc05PhaseDeadline) >= 0) {
        s_hc05Phase = Hc05Phase::Done;
      }
      break;
    }
    case Hc05Phase::Done:
    case Hc05Phase::Failed:
      break;
  }
}

static void diagnostics_update_elm(uint32_t nowMs)
{
  if (!g_status.hc05_ok || s_hc05Phase < Hc05Phase::Done) {
    return;
  }

  switch (s_elmPhase) {
    case ElmPhase::Idle: {
      digitalWrite(PIN_BT_KEY, LOW);
      s_elmKeyLowMs = nowMs;
      if (g_status.hc05_baud_detected != 115200) {
        BT.end();
        BT.begin(115200, SERIAL_8N1, PIN_BT_RX, PIN_BT_TX);
      }
      while (BT.available()) BT.read();
      elm_buf_clear();
      s_elmPhase = ElmPhase::WaitAfterKeyLow;
      break;
    }
    case ElmPhase::WaitAfterKeyLow: {
      if (nowMs - s_elmKeyLowMs >= 200) {
        elm_buf_clear();
        BT.print("ATZ\r\n");
        s_elmPhaseDeadline = nowMs + 1500;
        s_elmPhase = ElmPhase::WaitATZ;
      }
      break;
    }
    case ElmPhase::WaitATZ: {
      elm_buf_collect();
      if (elm_buf_contains(">") || elm_buf_contains("ELM")) {
        g_status.elm_ok = true;
        elm_buf_clear();
        BT.print("ATI\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::WaitATI;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        s_elmPhase = ElmPhase::Failed;
      }
      break;
    }
    case ElmPhase::WaitATI: {
      elm_buf_collect();
      if (elm_buf_contains("ELM")) {
        const char* p = strstr(s_elmBuf, "ELM");
        if (p) {
          size_t n = 0;
          while (*p && *p != '\r' && *p != '\n' && n < sizeof(g_status.elm_version) - 1) {
            g_status.elm_version[n++] = *p++;
          }
          g_status.elm_version[n] = '\0';
        }
        elm_buf_clear();
        BT.print("ATSP0\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::WaitATSP0;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        elm_buf_clear();
        BT.print("ATSP0\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::WaitATSP0;
      }
      break;
    }
    case ElmPhase::WaitATSP0: {
      elm_buf_collect();
      if (elm_buf_contains("OK") || elm_buf_contains(">")) {
        elm_buf_clear();
        BT.print("ATDP\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::WaitATDP;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        elm_buf_clear();
        BT.print("ATDP\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::WaitATDP;
      }
      break;
    }
    case ElmPhase::WaitATDP: {
      elm_buf_collect();
      if (elm_buf_contains(">")) {
        const char* p = s_elmBuf;
        const char* eol = strchr(p, '\n');
        if (eol && *eol) p = eol + 1;
        while (*p == '\r' || *p == '\n') ++p;
        size_t n = 0;
        while (*p && *p != '\r' && *p != '\n' && n < sizeof(g_status.elm_protocol) - 1) {
          g_status.elm_protocol[n++] = *p++;
        }
        g_status.elm_protocol[n] = '\0';
        elm_buf_clear();
        BT.print("0100\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::Wait0100;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        elm_buf_clear();
        BT.print("0100\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::Wait0100;
      }
      break;
    }
    case ElmPhase::Wait0100: {
      elm_buf_collect();
      if (elm_buf_contains("41 00")) {
        g_status.elm_pids_0100 = parse_hex_u32_from_tokens(s_elmBuf);
        elm_buf_clear();
        BT.print("010C\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::Wait010C;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        elm_buf_clear();
        BT.print("010C\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::Wait010C;
      }
      break;
    }
    case ElmPhase::Wait010C: {
      elm_buf_collect();
      if (elm_buf_contains("41 0C")) {
        float rpm = 0.0f;
        if (parse_obd_pid_010C(s_elmBuf, rpm)) {
          g_status.elm_rpm = rpm;
          g_status.elm_vehicle_present = true;
        }
        elm_buf_clear();
        BT.print("010D\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::Wait010D;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        elm_buf_clear();
        BT.print("010D\r\n");
        s_elmPhaseDeadline = nowMs + 800;
        s_elmPhase = ElmPhase::Wait010D;
      }
      break;
    }
    case ElmPhase::Wait010D: {
      elm_buf_collect();
      if (elm_buf_contains("41 0D")) {
        float spd = 0.0f;
        if (parse_obd_pid_010D(s_elmBuf, spd)) {
          g_status.elm_speed_kmh = spd;
          g_status.elm_vehicle_present = true;
        }
        s_elmPhase = ElmPhase::Done;
      } else if ((int32_t)(nowMs - s_elmPhaseDeadline) >= 0) {
        s_elmPhase = ElmPhase::Done;
      }
      break;
    }
    case ElmPhase::Done:
    case ElmPhase::Failed:
      break;
  }
}

// Public API -----------------------------------------------------------------

void diagnostics_engine_init()
{
  g_status = DiagnosticsStatus{};
  g_status.oled_ok = true;
  s_lastLoopMs   = millis();
  s_loopMinMs    = 0xFFFFFFFFu;
  s_loopMaxMs    = 0;
  s_lastDumpMs   = millis();

  s_hc05Phase = Hc05Phase::NotStarted;
  s_elmPhase  = ElmPhase::Idle;

  BT.end();
}

void diagnostics_engine_update(const AxionData& D, uint32_t /*frame*/)
{
  uint32_t nowMs = millis();

  g_status.data = D;

  g_status.dt_data_ms = -1.0f;
  if (D.timestamp_us != 0) {
    uint32_t nowUs = micros();
    uint32_t dtUs  = (uint32_t)((int32_t)(nowUs - D.timestamp_us));
    g_status.dt_data_ms = dtUs * 1e-3f;
  }

  // GNSS : test = fix 2D/3D avec HDOP correct et au moins quelques satellites.
  bool gnssGoodNow = (D.sats >= 4 && D.hdop > 0.0f && D.hdop < 3.0f && D.fix_quality >= 1);
  g_status.gnss_ok     = gnssGoodNow;
  if (gnssGoodNow) {
    g_status.gnss_tested = true;
  }

  // IMU : test = avoir observé un mouvement significatif (accel ou gyro).
  float accMag  = fabsf(D.accel_g[0]) + fabsf(D.accel_g[1]) + fabsf(D.accel_g[2]);
  float gyroMag = fabsf(D.gyro_deg[0]) + fabsf(D.gyro_deg[1]) + fabsf(D.gyro_deg[2]);
  bool imuActiveNow = (accMag > 0.01f || gyroMag > 0.01f);
  g_status.imu_ok     = imuActiveNow;
  if (imuActiveNow) {
    g_status.imu_tested = true;
  }

  diagnostics_update_rtc();

  uint8_t pcfVal = 0xFF;
  bool pcfReadOk = pcf::read_byte(I2C_ADDR_PCF8574, pcfVal);
  g_status.pcf_ok  = pcfReadOk;
  g_status.pcf_raw = pcfReadOk ? pcfVal : 0xFF;

  g_status.fps       = g_lastFpsValue;
  g_status.free_heap = (uint32_t)ESP.getFreeHeap();

  uint32_t dtLoop = nowMs - s_lastLoopMs;
  s_lastLoopMs = nowMs;
  if (dtLoop < s_loopMinMs) s_loopMinMs = dtLoop;
  if (dtLoop > s_loopMaxMs) s_loopMaxMs = dtLoop;

  diagnostics_update_sd_fs(nowMs);
  diagnostics_update_hc05(nowMs);
  diagnostics_update_elm(nowMs);
  diagnostics_update_test_all();

  if ((int32_t)(nowMs - s_lastDumpMs) >= 0) {
    s_lastDumpMs = nowMs + 1000;

    Serial.println();
    Serial.println(F("=== AXION Diagnostics ==="));

    Serial.print(F("Summary: "));
    Serial.print(F("GNSS=")); Serial.print(g_status.gnss_ok ? F("OK") : F("FAIL"));
    Serial.print(F(" IMU="));  Serial.print(g_status.imu_ok  ? F("OK") : F("NA"));
    Serial.print(F(" RTC="));  Serial.print(g_status.rtc_ok  ? F("OK") : F("FAIL"));
    Serial.print(F(" SD="));   Serial.print(g_status.sd_ok   ? F("OK") : F("NA"));
    Serial.print(F(" PCF="));  Serial.print(g_status.pcf_ok  ? F("OK") : F("FAIL"));
    Serial.print(F(" OLED=")); Serial.print(g_status.oled_ok ? F("OK") : F("FAIL"));
    Serial.print(F(" FS="));   Serial.print(g_status.fs_ok   ? F("OK") : F("NA"));
    Serial.print(F(" HC05=")); Serial.print(g_status.hc05_ok ? F("OK") : F("FAIL"));
    Serial.print(F(" ELM="));  Serial.println(g_status.elm_ok ? F("OK") : F("FAIL"));

    Serial.print(F("HC-05: baud="));
    Serial.print(g_status.hc05_baud_detected);
    Serial.print(F(" name=\"")); Serial.print(g_status.hc05_name); Serial.print('"');
    Serial.print(F(" addr=\"")); Serial.print(g_status.hc05_addr); Serial.print('"');
    Serial.print(F(" ver=\""));  Serial.print(g_status.hc05_version); Serial.println('"');

    Serial.print(F("GNSS: sats=")); Serial.print(D.sats);
    Serial.print(F(" hdop="));      Serial.print(D.hdop, 2);
    Serial.print(F(" fix="));       Serial.print(D.fix_quality);
    Serial.print(F(" lat="));       Serial.print(D.lat, 6);
    Serial.print(F(" lon="));       Serial.print(D.lon, 6);
    Serial.print(F(" spd="));       Serial.print(D.speed_kmh, 1);
    Serial.print(F(" hdg="));       Serial.println(D.heading_deg, 1);

    Serial.print(F("IMU: acc[g]="));
    Serial.print(D.accel_g[0], 3); Serial.print(' ');
    Serial.print(D.accel_g[1], 3); Serial.print(' ');
    Serial.print(D.accel_g[2], 3); Serial.print(F("  gyro[deg/s]="));
    Serial.print(D.gyro_deg[0], 1); Serial.print(' ');
    Serial.print(D.gyro_deg[1], 1); Serial.print(' ');
    Serial.println(D.gyro_deg[2], 1);

    Serial.print(F("ELM327: "));
    Serial.print(F("ver=\""));   Serial.print(g_status.elm_version);   Serial.print('"');
    Serial.print(F(" proto=\""));Serial.print(g_status.elm_protocol);  Serial.print('"');
    Serial.print(F(" pids0100=0x")); Serial.print(g_status.elm_pids_0100, HEX);
    Serial.print(F(" rpm="));   Serial.print(g_status.elm_rpm, 1);
    Serial.print(F(" speed=")); Serial.print(g_status.elm_speed_kmh, 1);
    Serial.print(F(" vehicle_present="));
    Serial.println(g_status.elm_vehicle_present ? F("YES") : F("NO"));

    Serial.print(F("Timing: dt_data="));
    Serial.print(g_status.dt_data_ms, 1);
    Serial.print(F("ms fps="));
    Serial.print(g_status.fps);
    Serial.print(F(" loop_min/max(ms)="));
    Serial.print(s_loopMinMs);
    Serial.print('/');
    Serial.println(s_loopMaxMs);

    Serial.print(F("Heap: "));
    Serial.print(g_status.free_heap);
    Serial.println(F(" bytes free"));

    Serial.print(F("PCF: raw=0x"));
    if (g_status.pcf_raw < 16) Serial.print('0');
    Serial.println(g_status.pcf_raw, HEX);
  }
}

const DiagnosticsStatus& diagnostics_engine_get_status()
{
  return g_status;
}

static void diagnostics_update_test_all()
{
  if (!s_testAll.running || s_testAll.done) {
    return;
  }

  uint32_t nowMs = millis();

  // Résumé "profond" pendant le test
  s_testAll.rtc_ok  = g_status.rtc_ok;
  s_testAll.gnss_ok = g_status.gnss_ok;
  s_testAll.imu_ok  = g_status.imu_ok;
  s_testAll.pcf_ok  = g_status.pcf_ok;

  // HC-05: 115200 + nom AXION_HC-05
  bool nameOk = (strncmp(g_status.hc05_name, "AXION_HC-05", 11) == 0);
  s_testAll.hc05_ok = g_status.hc05_ok &&
                      (g_status.hc05_baud_detected == 115200) &&
                      nameOk;

  // ELM: OK + véhicule présent
  s_testAll.elm_ok = g_status.elm_ok && g_status.elm_vehicle_present;

  switch (s_testPhase) {
    case TestAllPhase::Idle:
    case TestAllPhase::Start: {
      // Snapshot état LED pour restauration
      uint8_t v = 0xFF;
      if (pcf::read_byte(I2C_ADDR_PCF8574, v)) {
        s_ledBaselineKnown = true;
        s_ledBaselineGreen = ((v >> PCF_BIT_LED_GREEN) & 1u) != 0;
        s_ledBaselineRed   = ((v >> PCF_BIT_LED_RED)   & 1u) != 0;
      } else {
        s_ledBaselineKnown = false;
        s_ledBaselineGreen = true;
        s_ledBaselineRed   = true;
      }

      // Démarre un petit beep (LEDC canal 0)
      ledcSetup(0, 2000, 10);
      ledcAttachPin(PIN_BUZZER, 0);
      ledcWriteTone(0, 880);
      s_testPhase         = TestAllPhase::BuzzerOn;
      s_testPhaseDeadline = nowMs + 300; // 300 ms
      break;
    }

    case TestAllPhase::BuzzerOn:
      if ((int32_t)(nowMs - s_testPhaseDeadline) >= 0) {
        // Stop buzzer proprement
        ledcWriteTone(0, 0);
        ledcWrite(0, 0);
        ledcDetachPin(PIN_BUZZER);
        pinMode(PIN_BUZZER, INPUT);
        s_testAll.buzzer_ok = true;

        s_testPhase         = TestAllPhase::BuzzerOffWait;
        s_testPhaseDeadline = nowMs + 80;
      }
      break;

    case TestAllPhase::BuzzerOffWait:
      if ((int32_t)(nowMs - s_testPhaseDeadline) >= 0) {
        // LED verte ON (active LOW)
        pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_GREEN, false);
        pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_RED,   true);
        s_testPhase         = TestAllPhase::LedGreen;
        s_testPhaseDeadline = nowMs + 300;
      }
      break;

    case TestAllPhase::LedGreen:
      if ((int32_t)(nowMs - s_testPhaseDeadline) >= 0) {
        // LED rouge ON
        pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_GREEN, true);
        pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_RED,   false);
        s_testPhase         = TestAllPhase::LedRed;
        s_testPhaseDeadline = nowMs + 300;
      }
      break;

    case TestAllPhase::LedRed:
      if ((int32_t)(nowMs - s_testPhaseDeadline) >= 0) {
        // Restaure l’état LED
        pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_GREEN,
                     s_ledBaselineKnown ? s_ledBaselineGreen : true);
        pcf::set_bit(I2C_ADDR_PCF8574, PCF_BIT_LED_RED,
                     s_ledBaselineKnown ? s_ledBaselineRed   : true);
        s_testAll.led_ok = true;

        // Buttons: auto-pass in full diagnostics.
        // If the user managed to launch the test,
        // the buttons are already known to work.
        s_testAll.buttons_ok = true;
        s_testAll.done       = true;
        s_testAll.running    = false;
        s_testPhase          = TestAllPhase::Done;
      }
      break;

    case TestAllPhase::Buttons: {
      uint8_t v = g_status.pcf_raw;
      if (((v >> PCF_BIT_BTN_LEFT)   & 1u) == 0) s_btnLeftSeen   = true;
      if (((v >> PCF_BIT_BTN_RIGHT)  & 1u) == 0) s_btnRightSeen  = true;
      if (((v >> PCF_BIT_BTN_SELECT) & 1u) == 0) s_btnSelectSeen = true;

      bool allSeen = s_btnLeftSeen && s_btnRightSeen && s_btnSelectSeen;
      bool timeout = (int32_t)(nowMs - s_testPhaseDeadline) >= 0;

      if (allSeen || timeout) {
        s_testAll.buttons_ok = allSeen;
        s_testAll.done       = true;
        s_testAll.running    = false;
        s_testPhase          = TestAllPhase::Done;
      }
      break;
    }

    case TestAllPhase::Done:
      // rien
      break;
  }
}

bool diagnostics_engine_sd_prepare(bool wipeAxionFolder)
{
  // Ensure SPI bus is configured for SD.
  if (!s_sdSpiInited) {
    SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
    s_sdSpiInited = true;
  }

  if (!SD.begin(PIN_SD_CS)) {
    s_sdMounted          = false;
    g_status.sd_present  = false;
    g_status.sd_ok       = false;
    g_status.fs_ok       = false;
    g_status.sd_total_bytes = 0;
    g_status.sd_used_bytes  = 0;
    return false;
  }

  s_sdMounted = true;

  uint8_t cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    g_status.sd_present  = false;
    g_status.sd_ok       = false;
    g_status.fs_ok       = false;
    g_status.sd_total_bytes = 0;
    g_status.sd_used_bytes  = 0;
    return false;
  }

  g_status.sd_present = true;
  g_status.sd_ok      = true;

  bool success = true;

  if (wipeAxionFolder && SD.exists("/AXION")) {
    if (!sd_remove_recursive("/AXION")) {
      success = false;
    }
  }

  if (success && !SD.exists("/AXION")) {
    if (!SD.mkdir("/AXION")) {
      success = false;
    }
  }

  if (success) {
    File f = SD.open("/AXION/AXION_OK.TXT", FILE_WRITE);
    if (f) {
      f.println("AXION SD READY");
      f.close();
    } else {
      success = false;
    }
  }

  uint64_t total = SD.totalBytes();
  uint64_t used  = SD.usedBytes();
  g_status.sd_total_bytes = total;
  g_status.sd_used_bytes  = used;

  g_status.fs_ok = success;

  return success;
}

void diagnostics_engine_start_test_all()
{
  s_testAll = DiagnosticsTestAllStatus{};
  s_testAll.running    = true;
  s_testAll.done       = false;
  s_testAll.started_ms = millis();

  s_testBuzzerDone = false;
  s_testLedDone    = false;
  s_btnLeftSeen    = false;
  s_btnRightSeen   = false;
  s_btnSelectSeen  = false;

  s_testPhase         = TestAllPhase::Start;
  s_testPhaseDeadline = s_testAll.started_ms;
}

const DiagnosticsTestAllStatus& diagnostics_engine_get_test_all_status()
{
  return s_testAll;
}

