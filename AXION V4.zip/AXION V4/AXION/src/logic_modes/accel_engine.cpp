﻿#include <Arduino.h>

#include "logic_modes/accel_engine.h"

// État interne (repris de ui_accel.cpp, corrigé pour 0→V et V→0)
static bool     s_accelIsBrake      = false;   // false = Accel (0->V), true = Brake (V->0)
static int      s_accelTarget       = 100;
static bool     s_accelRunning      = false;
static bool     s_accelCompleted    = false;
static bool     s_accelArmed        = false;   // armé, en attente du trigger
static uint32_t s_accelStartMs      = 0;
static float    s_accelElapsed      = 0.0f;
static float    s_accelSpeedKmh     = 0.0f;
static float    s_accelBestTimes[4] = {3.82f, 4.11f, 2.95f, 3.54f};
static uint32_t s_lastModeChangeMs  = 0;
static int      s_accelModeChangeDir = 0;

// Spécifique Brake: suivi de la phase au-dessus de la cible
static bool     s_brakeAboveTarget  = false;
static float    s_prevSpeedKmh      = 0.0f;

void accel_engine_init()
{
  s_accelIsBrake      = false;
  s_accelTarget       = 100;
  s_accelRunning      = false;
  s_accelCompleted    = false;
  s_accelArmed        = false;
  s_accelStartMs      = 0;
  s_accelElapsed      = 0.0f;
  s_accelSpeedKmh     = 0.0f;
  s_lastModeChangeMs  = 0;
  s_accelModeChangeDir = 0;
  s_brakeAboveTarget  = false;
  s_prevSpeedKmh      = 0.0f;
}

void accel_engine_handle_serial(int c)
{
  if (c == 's' || c == 'S') {
    if (!s_accelRunning && !s_accelCompleted) {
      // Arme un nouveau run, déclenchement automatique selon le mode
      s_accelArmed        = true;
      s_accelRunning      = false;
      s_accelCompleted    = false;
      s_accelStartMs      = 0;
      s_accelElapsed      = 0.0f;
      s_brakeAboveTarget  = false;
      s_prevSpeedKmh      = 0.0f;
      Serial.printf("%s run armed (target %dkm/h)\n",
                    s_accelIsBrake ? "Brake" : "Accel", s_accelTarget);
    } else if (s_accelCompleted) {
      // Reset après un run terminé
      s_accelRunning      = false;
      s_accelCompleted    = false;
      s_accelArmed        = false;
      s_accelElapsed      = 0.0f;
      s_brakeAboveTarget  = false;
      s_prevSpeedKmh      = 0.0f;
      Serial.println("Run reset");
    }
  } else if (c == 'a' || c == 'A') {
    s_accelTarget -= 10;
    if (s_accelTarget < 50) s_accelTarget = 50;
    s_lastModeChangeMs   = millis();
    s_accelModeChangeDir = -1;
    Serial.printf("Target: %dkm/h\n", s_accelTarget);
  } else if (c == 'd' || c == 'D') {
    s_accelTarget += 10;
    if (s_accelTarget > 300) s_accelTarget = 300;
    s_lastModeChangeMs   = millis();
    s_accelModeChangeDir = +1;
    Serial.printf("Target: %dkm/h\n", s_accelTarget);
  } else if (c == 'w' || c == 'W') {
    // Toggle entre Accel et Brake
    s_accelIsBrake       = !s_accelIsBrake;
    s_accelRunning       = false;
    s_accelCompleted     = false;
    s_accelArmed         = false;
    s_accelElapsed       = 0.0f;
    s_brakeAboveTarget   = false;
    s_prevSpeedKmh       = 0.0f;
    s_lastModeChangeMs   = millis();
    s_accelModeChangeDir = 0;
    Serial.printf("Switched to %s mode\n",
                  s_accelIsBrake ? "Brake" : "Accel");
  }
}

void accel_engine_update(const AxionData& D, uint32_t nowMs)
{
  float speed = D.speed_kmh;
  if (speed < 0.0f) speed = 0.0f;
  s_accelSpeedKmh = speed;

  const float kStartThreshold = 1.0f;   // seuil ~"0 km/h"
  const float kStopThreshold  = 1.0f;   // seuil d'arrêt pour Brake
  const float kDropThreshold  = 5.0f;   // baisse brutale pour démarrer Brake

  if (!s_accelIsBrake) {
    // Mode Accel : 0 -> target

    if (s_accelArmed && !s_accelRunning) {
      // On démarre le chrono quand on quitte (presque) 0 km/h
      if (speed >= kStartThreshold) {
        s_accelRunning   = true;
        s_accelArmed     = false;
        s_accelStartMs   = nowMs;
        s_accelElapsed   = 0.0f;
        Serial.println("Accel timing started");
      }
    }

    if (s_accelRunning) {
      s_accelElapsed = (nowMs - s_accelStartMs) / 1000.0f;
      if (speed >= (float)s_accelTarget) {
        s_accelRunning   = false;
        s_accelCompleted = true;
        Serial.println("Accel timing stopped");
      }
    }

  } else {
    // Mode Brake : target -> 0

    if (s_accelArmed && !s_accelRunning) {
      // On attend d'abord d'avoir atteint la vitesse cible
      if (!s_brakeAboveTarget && speed >= (float)s_accelTarget) {
        s_brakeAboveTarget = true;
      }

      // Une fois au-dessus de la cible, on déclenche sur une grosse baisse
      if (s_brakeAboveTarget) {
        float delta = s_prevSpeedKmh - speed;
        if (delta > kDropThreshold) {
          s_accelRunning   = true;
          s_accelArmed     = false;
          s_accelStartMs   = nowMs;
          s_accelElapsed   = 0.0f;
          Serial.println("Brake timing started");
        }
      }
    }

    if (s_accelRunning) {
      s_accelElapsed = (nowMs - s_accelStartMs) / 1000.0f;
      if (speed <= kStopThreshold) {
        s_accelRunning   = false;
        s_accelCompleted = true;
        Serial.println("Brake timing stopped");
      }
    }
  }

  // Suivi de la vitesse précédente (utile pour détecter la baisse brusque en Brake)
  s_prevSpeedKmh = speed;
}

bool  accel_engine_is_brake()              { return s_accelIsBrake; }
int   accel_engine_get_target()            { return s_accelTarget; }
bool  accel_engine_is_running()            { return s_accelRunning; }
bool  accel_engine_is_completed()          { return s_accelCompleted; }
float accel_engine_get_elapsed()           { return s_accelElapsed; }
float accel_engine_get_speed_kmh()         { return s_accelSpeedKmh; }
float accel_engine_get_best_time_for_index(int idx)
{
  if (idx < 0 || idx >= 4) return 0.0f;
  return s_accelBestTimes[idx];
}
uint32_t accel_engine_get_last_mode_change_ms() { return s_lastModeChangeMs; }
int   accel_engine_get_mode_change_dir()        { return s_accelModeChangeDir; }
