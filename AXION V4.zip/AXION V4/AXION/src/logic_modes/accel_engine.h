﻿#pragma once

#include "data_fusion.h"

// Accel Engine – logique 0-X km/h / Brake 0-X km/h
// Sépare l'état du mode Accel de l'UI.

void accel_engine_init();
void accel_engine_handle_serial(int c);
void accel_engine_update(const AxionData& D, uint32_t nowMs);

bool  accel_engine_is_brake();
int   accel_engine_get_target();
bool  accel_engine_is_running();
bool  accel_engine_is_completed();
float accel_engine_get_elapsed();
float accel_engine_get_speed_kmh();
float accel_engine_get_best_time_for_index(int idx); // 0..3
uint32_t accel_engine_get_last_mode_change_ms();
int   accel_engine_get_mode_change_dir();

