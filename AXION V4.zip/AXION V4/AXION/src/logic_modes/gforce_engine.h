﻿#pragma once

#include "data_fusion.h"

// G-Force Engine - logique de calcul des G et maxima

void gforce_engine_init();
void gforce_engine_update(const AxionData& D, uint32_t frame);

float gforce_engine_get_ax();
float gforce_engine_get_ay();

float gforce_engine_get_max_accel(); // max +Ay
float gforce_engine_get_max_brake(); // max -Ay
float gforce_engine_get_max_lat();   // max |Ax|
