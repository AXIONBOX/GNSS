﻿#pragma once

#include "data_fusion.h"

// Compass Engine - heading / elevation / coords

void compass_engine_init();
void compass_engine_update(const AxionData& D, uint32_t frame);

float compass_engine_get_heading_deg();
float compass_engine_get_elevation_deg();
float compass_engine_get_lat();
float compass_engine_get_lon();
