﻿#pragma once

#include "data_fusion.h"

// Dashboard Engine - logical aggregation of speed / RPM / throttle / temps

void dashboard_engine_init();
void dashboard_engine_update(const AxionData& D, uint32_t frame);

float dashboard_engine_get_throttle();    // 0..100 %
float dashboard_engine_get_lat_g();       // -1.5..+1.5 G
int   dashboard_engine_get_engine_temp_c();
int   dashboard_engine_get_speed_kmh();
int   dashboard_engine_get_rpm();
