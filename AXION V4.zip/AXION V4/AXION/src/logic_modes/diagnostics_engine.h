#pragma once

#include "data_fusion.h"

struct DiagnosticsStatus {
  // Summary
  bool gnss_ok        = false;
  bool imu_ok         = false;
  bool gnss_tested    = false;  // true si un fix GNSS correct a déjà été observé
  bool imu_tested     = false;  // true si un mouvement IMU significatif a déjà été observé
  bool rtc_ok         = false;
  bool sd_ok          = false;
  bool sd_present     = false;
  bool pcf_ok         = false;
  bool oled_ok        = true;
  bool fs_ok          = false;
  bool hc05_ok        = false;
  bool elm_ok         = false;

  // AxionData snapshot
  AxionData data{};
  float     dt_data_ms   = -1.0f;

  // Stats
  uint32_t fps           = 0;
  uint32_t free_heap     = 0;
  uint64_t sd_total_bytes = 0;
  uint64_t sd_used_bytes  = 0;

  // PCF
  uint8_t  pcf_raw       = 0xFF;

  // HC-05 info
  uint32_t hc05_baud_detected = 0;      // 0 if unknown, else 9600/38400/115200
  char     hc05_name[32]      = {0};
  char     hc05_addr[24]      = {0};
  char     hc05_version[24]   = {0};

  // ELM327 info
  bool     elm_vehicle_present = false;
  char     elm_version[32]     = {0};
  char     elm_protocol[24]    = {0};
  uint32_t elm_pids_0100       = 0;     // bitmask for 0100
  float    elm_rpm             = 0.0f;
  float    elm_speed_kmh       = 0.0f;
};

struct DiagnosticsTestAllStatus {
  bool     running     = false;
  bool     done        = false;

  bool     rtc_ok      = false;
  bool     gnss_ok     = false;
  bool     imu_ok      = false;
  bool     pcf_ok      = false;
  bool     hc05_ok     = false;
  bool     elm_ok      = false;

  bool     buzzer_ok   = false;
  bool     led_ok      = false;
  bool     buttons_ok  = false;

  uint32_t started_ms  = 0;
};

void diagnostics_engine_init();
void diagnostics_engine_update(const AxionData& D, uint32_t frame);

void diagnostics_engine_start_test_all();

// SD / filesystem helpers
// Prepare /AXION folder on SD card. If wipeAxionFolder is true,
// the /AXION directory is cleared before recreation (does NOT
// low-level format the whole card).
bool diagnostics_engine_sd_prepare(bool wipeAxionFolder);

const DiagnosticsStatus&        diagnostics_engine_get_status();
const DiagnosticsTestAllStatus& diagnostics_engine_get_test_all_status();
