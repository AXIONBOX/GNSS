﻿#include <Arduino.h>
#include <math.h>

#include "logic_modes/gforce_engine.h"

static float s_ax = 0.0f;
static float s_ay = 0.0f;
static float s_maxAccel = 0.0f;
static float s_maxBrake = 0.0f;
static float s_maxLat   = 0.0f;

void gforce_engine_init()
{
  s_ax = 0.0f;
  s_ay = 0.0f;
  s_maxAccel = 0.0f;
  s_maxBrake = 0.0f;
  s_maxLat   = 0.0f;
}

void gforce_engine_update(const AxionData& D, uint32_t frame)
{
  float ax = 0.0f;
  float ay = 0.0f;

#ifdef USE_DATA_FUSION
  (void)frame;
  ax = D.accel_g[1];
  ay = D.accel_g[0];
#else
  float t = frame * 0.02f;
  ax = 1.2f * sinf(t * 0.5f);
  ay = 1.2f * cosf(t * 0.6f + 0.5f);
#endif

  const float limit = 1.25f;
  if (ax < -limit) ax = -limit;
  if (ax >  limit) ax =  limit;
  if (ay < -limit) ay = -limit;
  if (ay >  limit) ay =  limit;

  s_ax = ax;
  s_ay = ay;

  if (ay > s_maxAccel) s_maxAccel = ay;
  if (-ay > s_maxBrake) s_maxBrake = -ay;
  float absAx = fabsf(ax);
  if (absAx > s_maxLat) s_maxLat = absAx;
}

float gforce_engine_get_ax()        { return s_ax; }
float gforce_engine_get_ay()        { return s_ay; }
float gforce_engine_get_max_accel() { return s_maxAccel; }
float gforce_engine_get_max_brake() { return s_maxBrake; }
float gforce_engine_get_max_lat()   { return s_maxLat; }
