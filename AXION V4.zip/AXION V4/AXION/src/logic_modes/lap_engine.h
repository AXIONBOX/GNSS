﻿#pragma once

#include "data_fusion.h"

// Lap Engine V11 – wrapper autour du coeur Lap V11
// Fournit une interface propre pour les pages UI et le mode manager.

// Initialisation / reset complet du moteur Lap.
void lap_engine_init();

// Mise à jour du moteur Lap avec les données fusionnées courantes.
void lap_engine_update(const AxionData& D);

// Getters temps (en secondes).
float lap_engine_get_current_time();
float lap_engine_get_last_time();
float lap_engine_get_best_time();
float lap_engine_get_delta_vs_best();

// État de la piste / session.
bool lap_engine_track_detected();
bool lap_engine_is_running();
bool lap_engine_is_suspended();

// Accès géométrie de piste pour la mini‑carte.
int  lap_engine_get_track_count();
bool lap_engine_get_track_point(int idx, float& x, float& y);
bool lap_engine_get_sf_line(float& ax, float& ay, float& nx, float& ny);
bool lap_engine_get_current_xy(float& x, float& y);
