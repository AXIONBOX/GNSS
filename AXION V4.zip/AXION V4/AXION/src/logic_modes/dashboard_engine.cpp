﻿#include <Arduino.h>
#include <math.h>

#include "logic_modes/dashboard_engine.h"

static float    sThrottle    = 0.0f;
static float    sLatG        = 0.0f;
static int      sEngineTempC = 0;
static int      sSpeedKmh    = 0;
static int      sRpm         = 0;

static uint32_t sT0SpeedMs   = 0;

void dashboard_engine_init()
{
  sThrottle    = 0.0f;
  sLatG        = 0.0f;
  sEngineTempC = 0;
  sSpeedKmh    = 0;
  sRpm         = 0;
  sT0SpeedMs   = 0;
}

void dashboard_engine_update(const AxionData& D, uint32_t frame)
{
  (void)frame;

#ifdef USE_DATA_FUSION
  // Real data path (when fusion is wired): use values from AxionData.
  float throttle = D.throttle;
  if (throttle < 0.0f)  throttle = 0.0f;
  if (throttle > 100.0f) throttle = 100.0f;
  sThrottle = throttle;

  float lat = D.accel_g[1];
  if (lat < -1.5f) lat = -1.5f;
  if (lat >  1.5f) lat =  1.5f;
  sLatG = lat;

  sEngineTempC = (int)(D.coolant_temp_c + 0.5f);

  int speedInt = (int)(D.speed_kmh + 0.5f);
  if (speedInt < 0) speedInt = 0;
  if (speedInt > 999) speedInt = 999;
  sSpeedKmh = speedInt;

  int rpm = (int)(D.rpm + 0.5f);
  if (rpm < 0) rpm = 0;
  if (rpm > 8000) rpm = 8000;
  sRpm = rpm;
#else
  // Bench simulation (reuse original shapes, but with sinf instead of LUT)
  if (sT0SpeedMs == 0) sT0SpeedMs = millis();
  uint32_t now = millis();

  float phase2 = ((now - sT0SpeedMs) % 20000) / 10000.0f;
  float tri    = (phase2 <= 1.0f) ? phase2 : (2.0f - phase2);

  sSpeedKmh    = (int)(tri * 220.0f + 0.5f);
  if (sSpeedKmh < 0) sSpeedKmh = 0;
  if (sSpeedKmh > 220) sSpeedKmh = 220;

  sRpm         = (int)(tri * 8000.0f + 0.5f);
  if (sRpm < 0) sRpm = 0;
  if (sRpm > 8000) sRpm = 8000;

  sThrottle    = 65.0f + sinf((float)frame * 0.02f) * 10.0f;
  if (sThrottle < 0.0f)  sThrottle = 0.0f;
  if (sThrottle > 100.0f) sThrottle = 100.0f;

  sLatG        = sinf(frame * 0.06f) * 1.5f;
  if (sLatG < -1.5f) sLatG = -1.5f;
  if (sLatG >  1.5f) sLatG =  1.5f;

  sEngineTempC = 87 + (int)(sinf(frame * 0.04f) * 4.0f);
#endif
}

float dashboard_engine_get_throttle()    { return sThrottle; }
float dashboard_engine_get_lat_g()       { return sLatG; }
int   dashboard_engine_get_engine_temp_c(){ return sEngineTempC; }
int   dashboard_engine_get_speed_kmh()   { return sSpeedKmh; }
int   dashboard_engine_get_rpm()         { return sRpm; }
