﻿#pragma once

#include "data_fusion.h"

// Crawling Engine - logique de tilt / seuils / parametes

void crawling_engine_init();
void crawling_engine_update(const AxionData& D, uint32_t frame);

// Exports utilises par main.cpp pour LED + parametres
float  crawling_get_tilt_now();      // tilt normalise (0..>1)
float  crawling_get_warnTilt();      // seuil jaune
float  crawling_get_dangerTilt();    // seuil rouge
void   crawling_adjust_warn(int dir);   // ajuste Pmax
void   crawling_adjust_danger(int dir); // ajuste Rmax
void   crawling_set_param_sel(uint8_t sel); // 0:none,1:Pmax,2:Rmax

// Getters supplementaires pour l'UI
float   crawling_engine_get_pitch_deg();
float   crawling_engine_get_roll_deg();
float   crawling_engine_get_speed_kmh();
float   crawling_engine_get_alt_m();
float   crawling_engine_get_pitch_max();
float   crawling_engine_get_roll_max();
uint8_t crawling_engine_get_param_sel();
