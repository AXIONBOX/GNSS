﻿#include <Arduino.h>
#include <math.h>

#include "logic_modes/crawling_engine.h"

// Internal state, reprised from ui_crawling.cpp
static float   sCrawlPitchMax   = 30.0f;   // user pitch max (deg)
static float   sCrawlRollMax    = 30.0f;   // user roll max  (deg)
static float   sCrawlTiltNorm   = 0.0f;    // max( |pitch|/Pmax, |roll|/Rmax )
static uint8_t sCrawlParamSel   = 0;       // 0:none, 1:Pmax, 2:Rmax
static float   sLastPitchDeg    = 0.0f;
static float   sLastRollDeg     = 0.0f;

static float   sPitchDeg        = 0.0f;
static float   sRollDeg         = 0.0f;
static float   sSpeedKmh        = 0.0f;
static float   sAltM            = 0.0f;

void crawling_engine_init()
{
  sCrawlPitchMax = 30.0f;
  sCrawlRollMax  = 30.0f;
  sCrawlTiltNorm = 0.0f;
  sCrawlParamSel = 0;
  sLastPitchDeg  = 0.0f;
  sLastRollDeg   = 0.0f;
  sPitchDeg      = 0.0f;
  sRollDeg       = 0.0f;
  sSpeedKmh      = 0.0f;
  sAltM          = 0.0f;
}

void crawling_engine_update(const AxionData& D, uint32_t frame)
{
#ifdef USE_DATA_FUSION
  // Quand la fusion fournira pitch/roll rels, on viendra les utiliser ici.
  (void)frame;
  sPitchDeg = 0.0f;
  sRollDeg  = 0.0f;
  sSpeedKmh = D.speed_kmh;
  sAltM     = D.alt;
#else
  // Simulation identique  l'ancienne ui_crawling (bench)
  float t = frame * 0.03f;
  sPitchDeg = sinf(t*0.45f) * 26.0f;          // -26..+26 deg
  sRollDeg  = sinf(t*0.37f + 1.3f) * 28.0f;   // -28..+28 deg
  sSpeedKmh = fabsf(sinf(t*0.25f)) * 8.0f;    // 0..8 km/h
  sAltM     = 150.0f + sinf(t*0.12f) * 6.0f;  // 144..156 m
#endif

  sLastPitchDeg = sPitchDeg;
  sLastRollDeg  = sRollDeg;

  float nPitch = (sCrawlPitchMax > 1.0f) ? fabsf(sPitchDeg) / sCrawlPitchMax : 0.0f;
  float nRoll  = (sCrawlRollMax  > 1.0f) ? fabsf(sRollDeg)  / sCrawlRollMax  : 0.0f;
  sCrawlTiltNorm = max(nPitch, nRoll);
}

// Exports for main.cpp (LED + param selection)
float  crawling_get_tilt_now()   { return sCrawlTiltNorm; }
float  crawling_get_warnTilt()   { return 0.8f; }  // 80% of margin -> yellow
float  crawling_get_dangerTilt() { return 1.0f; }  // >=100% -> red

void crawling_adjust_warn(int dir)   // interpreted as Pmax adjust
{
  float step = 1.0f;
  sCrawlPitchMax += dir * step;
  if (sCrawlPitchMax < 5.0f)  sCrawlPitchMax = 5.0f;
  if (sCrawlPitchMax > 70.0f) sCrawlPitchMax = 70.0f;
}

void crawling_adjust_danger(int dir) // interpreted as Rmax adjust
{
  float step = 1.0f;
  sCrawlRollMax += dir * step;
  if (sCrawlRollMax < 5.0f)  sCrawlRollMax = 5.0f;
  if (sCrawlRollMax > 70.0f) sCrawlRollMax = 70.0f;
}

void crawling_set_param_sel(uint8_t sel)
{
  static uint8_t prev = 0;
  if (sel != prev) {
    // When entering edit mode, capture current angle as starting max
    if (sel == 1) {
      float v = fabsf(sLastPitchDeg);
      if (v < 5.0f) v = 5.0f;
      if (v > 70.0f) v = 70.0f;
      sCrawlPitchMax = v;
    } else if (sel == 2) {
      float v = fabsf(sLastRollDeg);
      if (v < 5.0f) v = 5.0f;
      if (v > 70.0f) v = 70.0f;
      sCrawlRollMax = v;
    }
    prev = sel;
  }
  sCrawlParamSel = sel;
}

// UI helpers
float   crawling_engine_get_pitch_deg() { return sPitchDeg; }
float   crawling_engine_get_roll_deg()  { return sRollDeg; }
float   crawling_engine_get_speed_kmh() { return sSpeedKmh; }
float   crawling_engine_get_alt_m()     { return sAltM; }
float   crawling_engine_get_pitch_max() { return sCrawlPitchMax; }
float   crawling_engine_get_roll_max()  { return sCrawlRollMax; }
uint8_t crawling_engine_get_param_sel() { return sCrawlParamSel; }
