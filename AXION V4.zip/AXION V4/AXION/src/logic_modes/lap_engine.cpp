﻿#include "logic_modes/lap_engine.h"
#include "lap_v11.h"

// Lap Engine V11 – simple wrapper autour du module Lap V11

void lap_engine_init()
{
  lap_reset();
}

void lap_engine_update(const AxionData& D)
{
  lap_update(D);
}

float lap_engine_get_current_time()  { return lap_get_current_time(); }
float lap_engine_get_last_time()     { return lap_get_last_time(); }
float lap_engine_get_best_time()     { return lap_get_best_time(); }
float lap_engine_get_delta_vs_best() { return lap_get_delta_vs_best(); }

bool lap_engine_track_detected()     { return lap_track_detected(); }
bool lap_engine_is_running()         { return lap_is_running(); }
bool lap_engine_is_suspended()       { return lap_is_suspended(); }

int  lap_engine_get_track_count()                      { return lap_get_track_count(); }
bool lap_engine_get_track_point(int idx, float& x, float& y)
{ return lap_get_track_point(idx, x, y); }

bool lap_engine_get_sf_line(float& ax, float& ay, float& nx, float& ny)
{ return lap_get_sf_line(ax, ay, nx, ny); }

bool lap_engine_get_current_xy(float& x, float& y)
{ return lap_get_current_xy(x, y); }
