﻿#pragma once

#include <stdint.h>
#include "data_fusion.h"

// Drift Engine - core drift detection and scoring logic

void drift_engine_init();
// `frame` is the global frame counter (around 60 fps)
void drift_engine_update(uint32_t frame);

// State accessors
float    drift_engine_get_angle();          // drift angle in degrees (>0)
float    drift_engine_get_duration();       // current drift duration in seconds
float    drift_engine_get_multiplier();     // current score multiplier
uint32_t drift_engine_get_current_score();  // score of current drift chain
uint32_t drift_engine_get_total_score();    // accumulated session score
int      drift_engine_get_combo_count();    // combo count (1,2,3,...)
int      drift_engine_get_speed_kmh();      // simulated / fused speed (km/h)
float    drift_engine_get_lat_g();          // lateral G (signed)
uint32_t drift_engine_get_session_ms();     // session elapsed time in ms

bool     drift_engine_is_active();          // currently drifting?
bool     drift_engine_flash_active();       // flash window active for LED / UI
