﻿#pragma once

#include "data_fusion.h"

// Drag Engine – logique Drag / Launch 1/4 / 1/8 mile
// Sépare l'état du mode Drag de l'UI.

void drag_engine_init();
void drag_engine_handle_serial(int c);
void drag_engine_update(uint32_t nowMs);

bool  drag_engine_is_launch();
int   drag_engine_get_distance_mode(); // 0 = 1/4, 1 = 1/8
bool  drag_engine_is_staging();
bool  drag_engine_is_running();
bool  drag_engine_is_completed();
float drag_engine_get_elapsed();
float drag_engine_get_progress();
float drag_engine_get_best_time_for_mode(int idx);  // index 0..1
float drag_engine_get_best_time_for_current();
uint32_t drag_engine_get_stage_start_ms();

