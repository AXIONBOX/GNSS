﻿#include <Arduino.h>

#include "logic_modes/drag_engine.h"

// Internal state for Drag / Launch mode
static bool     s_dragIsLaunch     = false;    // false = Drag, true = Launch
static int      s_dragDistanceMode = 0;       // 0 = 1/4 mile, 1 = 1/8 mile
static bool     s_dragStaging      = true;    // pre-stage sequence active
static bool     s_dragRunning      = false;
static bool     s_dragCompleted    = false;
static uint32_t s_dragStartMs      = 0;
static uint32_t s_dragStageStart   = 0;
static float    s_dragElapsed      = 0.0f;
static float    s_dragProgress     = 0.0f;
static float    s_dragBestTimes[2] = {12.42f, 8.25f};  // [0] = 1/4, [1] = 1/8

void drag_engine_init()
{
  s_dragIsLaunch     = false;
  s_dragDistanceMode = 0;
  s_dragStaging      = true;
  s_dragRunning      = false;
  s_dragCompleted    = false;
  s_dragStartMs      = 0;
  s_dragStageStart   = 0;
  s_dragElapsed      = 0.0f;
  s_dragProgress     = 0.0f;
}

void drag_engine_handle_serial(int c)
{
  if (c == 's' || c == 'S') {
    if (!s_dragRunning && !s_dragCompleted && s_dragStaging) {
      // Start pre-stage sequence
      s_dragStageStart = millis();
      Serial.println("Pre-stage sequence started");
    } else if (s_dragCompleted) {
      // Reset run
      s_dragRunning   = false;
      s_dragCompleted = false;
      s_dragStaging   = true;
      s_dragElapsed   = 0.0f;
      s_dragProgress  = 0.0f;
      Serial.println("Reset");
    }
  } else if (c == 'a' || c == 'A') {
    if (!s_dragIsLaunch) {
      s_dragDistanceMode = (s_dragDistanceMode + 1) % 2;
      Serial.printf("Distance: %s mile\n",
                    s_dragDistanceMode == 0 ? "1/4" : "1/8");
    }
  } else if (c == 'd' || c == 'D') {
    if (!s_dragIsLaunch) {
      s_dragDistanceMode = (s_dragDistanceMode + 1) % 2;
      Serial.printf("Distance: %s mile\n",
                    s_dragDistanceMode == 0 ? "1/4" : "1/8");
    }
  } else if (c == 'w' || c == 'W') {
    s_dragIsLaunch = !s_dragIsLaunch;
    Serial.printf("Switched to %s mode\n",
                  s_dragIsLaunch ? "Launch" : "Drag");
  }
}

void drag_engine_update(uint32_t nowMs)
{
  // Handle pre-stage sequence -> running transition
  if (s_dragStaging && s_dragStageStart > 0 && !s_dragRunning) {
    uint32_t seqElapsed = nowMs - s_dragStageStart;
    const int ledCount  = 8;
    int active          = (int)(seqElapsed / 250);  // 250 ms per LED
    if (active >= ledCount) {
      s_dragStaging   = false;
      s_dragRunning   = true;
      s_dragCompleted = false;
      s_dragStartMs   = nowMs;
    }
  }

  // Update elapsed time and progress while running
  if (s_dragRunning) {
    uint32_t elapsed   = nowMs - s_dragStartMs;
    float    totalTime = (s_dragDistanceMode == 0) ? 12000.0f : 6000.0f;
    s_dragProgress     = min(1.0f, (float)elapsed / totalTime);
    s_dragElapsed      = elapsed * 1e-3f;
    if (s_dragProgress >= 1.0f) {
      s_dragRunning   = false;
      s_dragCompleted = true;
      s_dragStaging   = true;
    }
  }
}

bool  drag_engine_is_launch()                 { return s_dragIsLaunch; }
int   drag_engine_get_distance_mode()         { return s_dragDistanceMode; }
bool  drag_engine_is_staging()                { return s_dragStaging; }
bool  drag_engine_is_running()                { return s_dragRunning; }
bool  drag_engine_is_completed()              { return s_dragCompleted; }
float drag_engine_get_elapsed()               { return s_dragElapsed; }
float drag_engine_get_progress()              { return s_dragProgress; }
float drag_engine_get_best_time_for_mode(int idx)
{
  if (idx < 0 || idx >= 2) return 0.0f;
  return s_dragBestTimes[idx];
}
float drag_engine_get_best_time_for_current()
{
  return s_dragBestTimes[s_dragDistanceMode];
}
uint32_t drag_engine_get_stage_start_ms()     { return s_dragStageStart; }
