#pragma once

#include <Arduino.h>
#include "data_fusion.h"  // for AxionData

// Lap V11 – Automatic Lap Manager (Option C)
// - Pure GNSS+IMU (AxionData)
// - Automatic loop / track detection
// - Virtual start/finish line and lap timing

// Update state machine with latest fused data (call at ~20–25 Hz).
void lap_update(const AxionData& D);

// Reset all state (track + laps).
void lap_reset();

// ---- Lap timing getters (seconds) ----
float lap_get_current_time();   // current lap, 0 if not running
float lap_get_last_time();      // last completed lap, 0 if none
float lap_get_best_time();      // best lap, 0 if none
float lap_get_delta_vs_best();  // last - best (0 if none or first)

// ---- Track / state getters ----
bool lap_track_detected();      // true once loop closure / S/F locked
bool lap_is_running();          // true while inside a lap
bool lap_is_suspended();        // true if timing paused due to poor GNSS / leaving track

// ---- Track geometry accessors (for visualization) ----
// Number of stored track points (0 if no track built yet).
int  lap_get_track_count();
// Read XY of a track point in meters (local frame). Returns false if idx out of range.
bool lap_get_track_point(int idx, float& x, float& y);
// Get start/finish line anchor and normal in XY (meters). Returns false if not yet defined.
bool lap_get_sf_line(float& ax, float& ay, float& nx, float& ny);
// Get current XY position of the car (local frame). Returns false if not initialised.
bool lap_get_current_xy(float& x, float& y);

