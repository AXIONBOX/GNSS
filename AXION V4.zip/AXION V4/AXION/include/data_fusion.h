#pragma once

#include <stdint.h>


// AxionData - fused GNSS + IMU (+ éventuels signaux moteur/OBD)

struct AxionData {
  // GNSS
  float   lat         = 0.0f;
  float   lon         = 0.0f;
  float   alt         = 0.0f;
  uint8_t sats        = 0;
  float   hdop        = 0.0f;
  uint8_t fix_quality = 0;

  // Cinématique
  float speed_kmh   = 0.0f;
  float accel_g[3]  = {0.0f, 0.0f, 0.0f};
  float gyro_deg[3] = {0.0f, 0.0f, 0.0f};
  float heading_deg = 0.0f;
  float rpm         = 0.0f;

  // Signaux moteur (utilisés par dashboard_engine quand USE_DATA_FUSION est actif)
  float throttle        = 0.0f;
  float coolant_temp_c  = 0.0f;

  // Validité des sous-systèmes (GNSS / IMU / OBD).
  bool   gnss_valid     = false;
  bool   imu_valid      = false;
  bool   obd_valid      = false;

  // Timestamp (us) dans la timebase commune
  uint32_t timestamp_us = 0;
};

// Initialisation de la pipeline de fusion (timebase + GNSS + IMU).
void data_fusion_init();

// Pompage des données brutes GNSS/IMU et construction périodique (25 Hz)
// d'un AxionData cohérent (appel fréquent depuis loop ou data_source_update).
void data_fusion_update();

// Snapshot atomique de la dernière trame fusionnée.
void data_fusion_snapshot(AxionData& out);

