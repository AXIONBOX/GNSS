#pragma once

// Centralise la configuration d'accès aux données fusionnées (AxionData)
// pour CORE_Project, en restant autonome par rapport à AXION.

#if defined(USE_MOCK_DATA)
#  undef USE_DATA_FUSION
#endif

#if defined(USE_DATA_FUSION)
  #if __has_include("data_fusion.h")
    #include "data_fusion.h"
  #elif __has_include("../include/data_fusion.h")
    #include "../include/data_fusion.h"
  #else
    #warning "USE_DATA_FUSION defined mais data_fusion.h introuvable; fallback mock."
    #undef USE_DATA_FUSION
  #endif
#endif

